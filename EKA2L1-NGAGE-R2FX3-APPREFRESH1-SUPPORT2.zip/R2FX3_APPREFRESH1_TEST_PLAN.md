# R2FX3 APPREFRESH1 — Runtime Test Plan

## Gate A — N-Gage Apps button
1. Boot N-Gage and confirm Bomberman, FIFA 2005, Asphalt 2 and SanGo are visible.
2. Tap `Ứng dụng` once.
3. PASS: visible refresh feedback appears and the same four apps return without a crash.
4. Tap `Ứng dụng` 5 times with normal spacing.
5. PASS: no crash, freeze, duplicate rows or missing apps.

## Gate B — profile isolation
1. Switch N-Gage -> RM-409.
2. Tap `Ứng dụng`.
3. PASS: only RM-409 apps are shown; no N-Gage game leaks into the list.
4. Switch back to N-Gage and refresh again.
5. PASS: the N-Gage list returns intact.

## Gate C — lifecycle regression
1. Launch Asphalt 2 -> `...` -> Exit Game.
2. Refresh Apps.
3. Launch Bomberman -> `...` -> Exit Game.
4. Refresh Apps.
5. N-Gage -> RM-409 -> N-Gage.
6. PASS: no host crash and CRASHFIX1 behavior remains intact.

## Gate D — persistence
Force-close EKA2L1, reopen and refresh Apps once. Profiles and game lists must persist.

## Evidence
Send one screen recording and both EKA2L1 logs. Stop immediately on the first crash.
