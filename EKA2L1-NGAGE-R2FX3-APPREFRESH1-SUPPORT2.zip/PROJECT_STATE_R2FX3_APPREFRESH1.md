# EKA2L1 iOS N-Gage Classic — R2FX3 APPREFRESH1 / UI POLISH

Date: 2026-09-05

## Frozen baseline
- R2A FINAL1 — FROZEN/PASS
- R2B DEVICEPROFILES R1 — FROZEN/PASS
- R2B MULTIFIRMWARE R2 — FROZEN/PASS
- R2FX1 CLEANUP — FROZEN/PASS
- R2FX2 COMPATIBILITY R1 — FROZEN/PASS
- R2FX2 R2 CRASHFIX1 SUPPORT1 — FROZEN/PASS

## R2FX3 target
The Apps/Ứng dụng toolbar button is wired to `onShowApps`, but the frozen binary shows that `onShowApps` only tail-calls `showAppsScreen`. If the app list does not change, the user gets no visible response and the button appears dead.

APPREFRESH1:
1. preserves `showAppsScreen` as the single profile-aware app-list implementation;
2. gives immediate status feedback (`Refreshing apps…`);
3. briefly disables toolbar interaction to debounce repeated taps;
4. refreshes on the UIKit main queue;
5. reports the visible app count after refresh;
6. refuses refresh while a guest game is running rather than crossing lifecycle state;
7. adds Vietnamese UI strings;
8. does not change emulator core, device storage, game imports, ordinal/HLE behavior, or CRASHFIX1 lifecycle serialization.

## Build convention
- workflow_dispatch only (manual build)
- YML under 500 KB
- support/patch/data in one companion ZIP
