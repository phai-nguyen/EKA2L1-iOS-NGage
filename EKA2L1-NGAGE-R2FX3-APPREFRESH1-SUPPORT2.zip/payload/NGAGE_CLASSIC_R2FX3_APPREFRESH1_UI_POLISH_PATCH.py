from pathlib import Path

root = Path('upstream')
rv = root / 'src/emu/ios/app/RootViewController.mm'
loc = root / 'src/emu/ios/app/EKALocalization.mm'
for p in (rv, loc):
    if not p.is_file():
        raise SystemExit(f'R2FX3 APPREFRESH1: missing {p}')

r = rv.read_text(encoding='utf-8')
l = loc.read_text(encoding='utf-8')
MARK = 'NGAGE CLASSIC R2FX3 APPREFRESH1:'
if MARK in r:
    raise SystemExit('R2FX3 APPREFRESH1 already installed')
if 'NGAGE CLASSIC R2FX2 R2 CRASHFIX1:' not in r:
    raise SystemExit('R2FX3 APPREFRESH1 requires frozen R2FX2 R2 CRASHFIX1 baseline')

# Small lexical method finder: robust to formatting/comments in Objective-C++.
def method_span(text: str, sig: str):
    start = text.find(sig)
    if start < 0:
        raise SystemExit(f'R2FX3 APPREFRESH1 missing method: {sig}')
    brace = text.find('{', start)
    if brace < 0:
        raise SystemExit(f'R2FX3 APPREFRESH1 missing opening brace: {sig}')
    i = brace
    depth = 0
    state = 'code'
    while i < len(text):
        ch = text[i]
        nx = text[i+1] if i + 1 < len(text) else ''
        if state == 'code':
            if ch == '/' and nx == '/': state = 'line'; i += 2; continue
            if ch == '/' and nx == '*': state = 'block'; i += 2; continue
            if ch == '"': state = 'string'; i += 1; continue
            if ch == "'": state = 'char'; i += 1; continue
            if ch == '{': depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0: return start, i + 1, brace
            i += 1
        elif state == 'line':
            if ch == '\n': state = 'code'
            i += 1
        elif state == 'block':
            if ch == '*' and nx == '/': state = 'code'; i += 2
            else: i += 1
        else:
            quote = '"' if state == 'string' else "'"
            if ch == '\\': i += 2
            elif ch == quote: state = 'code'; i += 1
            else: i += 1
    raise SystemExit(f'R2FX3 APPREFRESH1 unterminated method: {sig}')

# Prove the toolbar's fourth action is actually wired to onShowApps before replacing it.
ts, te, _ = method_span(r, '- (void)setupToolbar')
toolbar = r[ts:te]
if 'onShowApps' not in toolbar:
    raise SystemExit('R2FX3 APPREFRESH1: Apps toolbar selector is not wired to onShowApps')

s, e, _ = method_span(r, '- (void)onShowApps')
old = r[s:e]
if 'showAppsScreen' not in old:
    raise SystemExit('R2FX3 APPREFRESH1: unexpected onShowApps baseline')

new = r'''- (void)onShowApps {
    // NGAGE CLASSIC R2FX3 APPREFRESH1: make the Apps toolbar action visibly refresh.
    // The old handler synchronously called showAppsScreen; when the list was unchanged,
    // the user saw no UI reaction and the button appeared dead.
    if (![NSThread isMainThread]) {
        NSLog(@"NGAGE CLASSIC R2FX3 APPREFRESH1: marshal-main");
        dispatch_async(dispatch_get_main_queue(), ^{ [self onShowApps]; });
        return;
    }

    if ([self gameRunning]) {
        NSLog(@"NGAGE CLASSIC R2FX3 APPREFRESH1: ignored while game is running");
        [self showAlert:EKAL(@"Apps refresh unavailable")
                message:EKAL(@"Exit the current game before refreshing apps.")];
        return;
    }

    NSLog(@"NGAGE CLASSIC R2FX3 APPREFRESH1: refresh-request");
    [self setToolbarBusy:YES];
    self.statusLabel.text = EKAL(@"Refreshing apps…");
    self.statusLabel.hidden = NO;

    // Defer one short main-loop turn so the feedback becomes visible before get_apps()
    // and table rebuilding run. Keep the existing showAppsScreen implementation as the
    // single source of truth for profile-aware filtering, hidden apps and icon loading.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(80 * NSEC_PER_MSEC)),
                   dispatch_get_main_queue(), ^{
        [self showAppsScreen];
        [self setToolbarBusy:NO];

        NSUInteger count = self.apps.count;
        NSLog(@"NGAGE CLASSIC R2FX3 APPREFRESH1: refresh-complete visible=%lu",
              (unsigned long)count);
        if (count > 0) {
            self.statusLabel.text = [NSString stringWithFormat:EKAL(@"Apps refreshed: %lu"),
                                     (unsigned long)count];
            self.statusLabel.hidden = NO;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(900 * NSEC_PER_MSEC)),
                           dispatch_get_main_queue(), ^{
                if (![self gameRunning] && self.apps.count > 0) {
                    self.statusLabel.hidden = YES;
                }
            });
        }
        // count==0 deliberately keeps showAppsScreen's existing empty-state guidance.
    });
}'''
r = r[:s] + new + r[e:]

# Vietnamese UI strings: insert into the first localization table only.
loc_anchor = '        table = @{\n'
if l.count(loc_anchor) < 1:
    raise SystemExit('R2FX3 APPREFRESH1: localization table anchor missing')
rows = r'''            @"Refreshing apps…" : @"Đang làm mới ứng dụng…",
            @"Apps refreshed: %lu" : @"Đã làm mới ứng dụng: %lu",
            @"Apps refresh unavailable" : @"Không thể làm mới ứng dụng",
            @"Exit the current game before refreshing apps." : @"Hãy thoát trò chơi hiện tại trước khi làm mới ứng dụng.",
'''
l = l.replace(loc_anchor, loc_anchor + rows, 1)

rv.write_text(r, encoding='utf-8')
loc.write_text(l, encoding='utf-8')

# Audits.
r2 = rv.read_text(encoding='utf-8')
l2 = loc.read_text(encoding='utf-8')
for token in (
    MARK,
    'refresh-request',
    'refresh-complete visible=%lu',
    'Refreshing apps…',
    'Apps refreshed: %lu',
    '[self setToolbarBusy:YES]',
    '[self setToolbarBusy:NO]',
    '[self showAppsScreen]',
    '80 * NSEC_PER_MSEC',
):
    if token not in r2:
        raise SystemExit('R2FX3 APPREFRESH1 root audit missing: ' + token)
for token in (
    '@"Refreshing apps…" : @"Đang làm mới ứng dụng…"',
    '@"Apps refreshed: %lu" : @"Đã làm mới ứng dụng: %lu"',
    '@"Apps refresh unavailable" : @"Không thể làm mới ứng dụng"',
):
    if token not in l2:
        raise SystemExit('R2FX3 APPREFRESH1 localization audit missing: ' + token)

ns, ne, _ = method_span(r2, '- (void)onShowApps')
body = r2[ns:ne]
if body.count('[self showAppsScreen]') != 1:
    raise SystemExit('R2FX3 APPREFRESH1: onShowApps must have exactly one refresh call')
if body.count('dispatch_after(') != 2:
    raise SystemExit('R2FX3 APPREFRESH1: expected refresh defer + feedback hide timers')

print('NGAGE CLASSIC R2FX3 APPREFRESH1 UI POLISH patch: PASS')
print('Apps toolbar handler wiring audited: PASS')
print('Visible refresh feedback + debounce: PASS')
print('Existing profile-aware showAppsScreen reused: PASS')
print('Game-running guard: PASS')
print('Vietnamese localization: PASS')
