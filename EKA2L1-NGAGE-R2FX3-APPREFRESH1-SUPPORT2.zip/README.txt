EKA2L1 N-Gage R2FX3 APPREFRESH1 SUPPORT2

One companion package for the manual-only GitHub workflow.
Contains the frozen SUPPORT1 payload plus R2FX3 APPREFRESH1/UI POLISH patch, project state, test plan and SHA256SUMS.

Repository root filename required by workflow:
EKA2L1-NGAGE-R2FX3-APPREFRESH1-SUPPORT2.zip
