N-Gage Classic R2A CLASSICIMPORT FIX1

Build/link corrections:
- Preserve launcher::get_current_device().
- Preserve launcher::does_rom_need_rpkg().
- Link EKA2L1's existing miniz target into eka2l1_ios_bridge.

Functional behavior is unchanged from R2A:
NEM-4 installs a user-selected .n-gage package directly through the Classic
game-card installer. No game is bundled and no DRM/license logic is modified.
