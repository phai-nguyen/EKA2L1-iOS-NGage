EKA2L1 iOS - N-Gage Classic R2A CLASSICIMPORT

R2A changes only the N-Gage Classic import path.
For current firmware NEM-4, a user-selected .n-gage package is safely extracted
to a temporary folder and installed through EKA2L1's existing Classic game-card
installer. The game is not bundled in the firmware or IPA.

Other firmware keeps the legacy E:\\n-gage file-drop path.

No DRM or license checks are changed.

R2B DEVICEPROFILES will separately implement per-firmware C:/E:/Z:/ROM storage
and multiple firmware versions for the same product code.
