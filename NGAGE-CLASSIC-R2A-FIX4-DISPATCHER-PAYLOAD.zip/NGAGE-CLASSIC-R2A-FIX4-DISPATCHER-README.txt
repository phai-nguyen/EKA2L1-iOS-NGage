EKA2L1 iOS - N-Gage Classic R2A FIX4 DISPATCHER

Based on the successful FIX3 BUILD-FIX1 runtime.

FIX4 changes:
1. Canonicalizes Classic archive directory casing before the core card installer.
   Example supported: FIFA 2005/SYSTEM/Apps/... -> canonical system/apps/...
2. ZIP/RAR dispatcher after extraction:
   - System/Apps -> Classic game-card install.
   - Exactly one compatible Symbian 6.1 SIS -> automatic SIS install.
   - Multiple compatible SIS -> iOS chooser lets the user select the package.
   - Only SISX/EKA2 -> rejected as incompatible with NEM-4.
   - No supported content -> precise error.
3. Keeps FIX3 N-Gage 2.0 MIME detection and UnRAR integration.
4. Does not modify the deferred graphics-command-list exit issue.
5. No games are bundled. No DRM/license checks are modified.
