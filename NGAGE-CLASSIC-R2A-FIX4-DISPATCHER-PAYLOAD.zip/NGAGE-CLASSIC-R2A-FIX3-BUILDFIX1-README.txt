EKA2L1 iOS - N-Gage Classic R2A FIX3 MULTIIMPORT BUILD-FIX1

Build fix:
UnRAR's dll.hpp relies on Unix platform typedefs (HANDLE/PASCAL/CALLBACK/UINT/LPARAM).
On Apple, UnRAR's raros.hpp defines _UNIX from __APPLE__. FIX3 included dll.hpp
directly, so Clang produced a cascade of compile errors. BUILD-FIX1 now follows
UnRAR's own include order:
  #include <raros.hpp>
  #include <dll.hpp>

No importer behavior changes. RAR/ZIP/Classic .n-gage support and N-Gage 2.0
compatibility detection remain as in FIX3. No game is bundled and no DRM/license
logic is modified.
