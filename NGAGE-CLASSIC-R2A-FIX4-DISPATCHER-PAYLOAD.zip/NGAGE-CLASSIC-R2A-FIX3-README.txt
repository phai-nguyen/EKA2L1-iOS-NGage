EKA2L1 iOS - N-Gage Classic R2A FIX3 MULTIIMPORT

Baseline:
- R2A FIX1 CLASSICIMPORT
- Bundled Nokia N-Gage NEM-4 V4.03 firmware remains unchanged.

FIX3 importer:
- Classic .n-gage ZIP/game-card packages: direct install to current NEM-4 E:.
- .zip archives containing System/Apps: direct Classic install.
- .rar archives containing System/Apps: direct Classic install.
- Automatically finds System/Apps through up to two outer wrapper folders.
- N-Gage 2.0 MIME .n-gage packages are detected and rejected on NEM-4 with
  a compatibility message instead of a misleading extraction error.
- Symbian OS 9.x/EKA2 SISX (UID1 0x10201A7A) is rejected on NEM-4.
- Password/encrypted RAR is not supported.
- Archive paths, traversal components and RAR redirections are rejected.
- No game is bundled in the IPA/firmware.
- No DRM/license checks are modified.

RAR decoder source:
https://github.com/aawc/unrar
Pinned commit: 97e1780310edeba849be719bbee9dbbead6de324
This mirror states it is a copy of portable UnRAR source from RARLAB.
The workflow verifies the exact commit before compilation.
UnRAR is used only for read/decompression.
