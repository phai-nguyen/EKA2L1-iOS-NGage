from pathlib import Path
import re

root = Path('upstream')
launcher = root / 'src/emu/ios/src/launcher.cpp'
rootvc = root / 'src/emu/ios/app/RootViewController.mm'
loc = root / 'src/emu/ios/app/EKALocalization.mm'
cmake = root / 'src/emu/ios/CMakeLists.txt'
unrar_dir = root / 'src/external/ngage_unrar'

for p in (launcher, rootvc, loc, cmake):
    if not p.is_file():
        raise SystemExit(f'FIX3: missing source file: {p}')
for name in ('dll.hpp', 'dll.cpp', 'unpack.cpp', 'extract.cpp', 'makefile', 'license.txt'):
    if not (unrar_dir / name).is_file():
        raise SystemExit(f'FIX3: pinned UnRAR source missing: {name}')

lt = launcher.read_text(encoding='utf-8')
rt = rootvc.read_text(encoding='utf-8')
lc = loc.read_text(encoding='utf-8')
ct = cmake.read_text(encoding='utf-8')

MARK = 'NGAGE CLASSIC R2A FIX3 MULTIIMPORT:'
if MARK in lt:
    raise SystemExit('FIX3 already installed')
if 'NGAGE CLASSIC R2A FIX1 CLASSICIMPORT:' not in lt:
    raise SystemExit('FIX3 requires R2A FIX1 baseline')

# -------------------------------------------------------------------------
# launcher.cpp: add RAR DLL API + standard helpers.
# -------------------------------------------------------------------------
inc_anchor = '#include <miniz.h>\n\n#include <algorithm>\n#include <cstring>'
if lt.count(inc_anchor) != 1:
    raise SystemExit('FIX3: launcher include anchor invalid')
lt = lt.replace(
    inc_anchor,
    '#include <miniz.h>\n#include <dll.hpp>\n\n#include <algorithm>\n#include <array>\n#include <cstring>\n#include <filesystem>\n#include <fstream>\n#include <vector>',
    1,
)

# -------------------------------------------------------------------------
# iOS CMake: compile pinned UnRAR source as a static decompression-only lib.
# Source is fetched by the workflow at a fixed upstream mirror commit.
# -------------------------------------------------------------------------
bridge_anchor = 'add_library(eka2l1_ios_bridge STATIC\n'
if ct.count(bridge_anchor) != 1:
    raise SystemExit('FIX3: bridge CMake anchor invalid')

unrar_sources = [
    'rar.cpp','strlist.cpp','strfn.cpp','pathfn.cpp','smallfn.cpp','global.cpp',
    'file.cpp','filefn.cpp','filcreat.cpp','archive.cpp','arcread.cpp','unicode.cpp',
    'system.cpp','crypt.cpp','crc.cpp','rawread.cpp','encname.cpp','resource.cpp',
    'match.cpp','timefn.cpp','rdwrfn.cpp','consio.cpp','options.cpp','errhnd.cpp',
    'rarvm.cpp','secpassword.cpp','rijndael.cpp','getbits.cpp','sha1.cpp','sha256.cpp',
    'blake2s.cpp','hash.cpp','extinfo.cpp','extract.cpp','volume.cpp','list.cpp',
    'find.cpp','unpack.cpp','headers.cpp','threadpool.cpp','rs16.cpp','cmddata.cpp',
    'ui.cpp','largepage.cpp','filestr.cpp','scantree.cpp','dll.cpp','qopen.cpp'
]
for src in unrar_sources:
    if not (unrar_dir / src).is_file():
        raise SystemExit(f'FIX3: UnRAR source list mismatch: {src}')

cmake_block = '''# NGAGE CLASSIC R2A FIX3: read-only RAR extraction for user-selected Classic game archives.\n# The source is the portable UnRAR library. RARDLL builds only the decompression API;\n# it must not be used to recreate the proprietary RAR compression algorithm.\nset(NGAGE_UNRAR_DIR "${PROJECT_SOURCE_DIR}/src/external/ngage_unrar")\nadd_library(ngage_unrar STATIC\n'''
for src in unrar_sources:
    cmake_block += f'    "${{NGAGE_UNRAR_DIR}}/{src}"\n'
cmake_block += ''')\ntarget_include_directories(ngage_unrar PUBLIC "${NGAGE_UNRAR_DIR}")\ntarget_compile_definitions(ngage_unrar PRIVATE RARDLL _FILE_OFFSET_BITS=64 _LARGEFILE_SOURCE RAR_SMP)\ntarget_compile_options(ngage_unrar PRIVATE -Wno-logical-op-parentheses -Wno-switch -Wno-dangling-else)\n\n'''
ct = ct.replace(bridge_anchor, cmake_block + bridge_anchor, 1)

link_anchor = '    lunasvg\n    miniz\n    sqlite3'
if ct.count(link_anchor) != 1:
    raise SystemExit('FIX3: bridge link anchor invalid')
ct = ct.replace(link_anchor, '    lunasvg\n    miniz\n    ngage_unrar\n    sqlite3', 1)

# -------------------------------------------------------------------------
# Replace FIX1 importer while preserving all following launcher methods.
# Return codes used by UIKit:
#   100     success
#   101-104 existing Classic game-card validation errors
#   105     unsafe archive path/redirection
#   106     N-Gage 2.0 MIME/SISX package on NEM-4
#   107     unsupported/unknown archive type
#   108     password/encrypted RAR
#   109     extraction/read error
# -------------------------------------------------------------------------
start = lt.find('    int launcher::install_ngage_file(const std::string &src_path, std::string &out_name) {')
end = lt.find('\n    std::uint32_t launcher::get_current_device()', start)
if start < 0 or end < 0:
    raise SystemExit('FIX3: exact install_ngage_file boundary not found')

new_func = r'''    int launcher::install_ngage_file(const std::string &src_path, std::string &out_name) {
        device *current_device = sys->get_device_manager()->get_current();
        const bool ngage_classic = current_device &&
            common::compare_ignore_case(current_device->firmware_code.c_str(), "NEM-4") == 0;

        const std::string extension = common::lowercase_string(std::filesystem::path(src_path).extension().string());
        const bool explicit_classic_archive = (extension == ".zip") || (extension == ".rar");

        if (ngage_classic) {
            // Identify the container before attempting decompression. N-Gage 2.0 .n-gage
            // packages are MIME multipart containers holding EKA2/Symbian 9.x SISX files;
            // they are not N-Gage Classic game-card ZIPs.
            std::array<char, 4096> probe{};
            std::size_t probe_size = 0;
            {
                std::ifstream in(src_path, std::ios::binary);
                if (!in) {
                    LOG_ERROR(FRONTEND_CMDLINE,
                        "NGAGE CLASSIC R2A FIX3 MULTIIMPORT: cannot read '{}'", src_path);
                    return 109;
                }
                in.read(probe.data(), static_cast<std::streamsize>(probe.size()));
                probe_size = static_cast<std::size_t>(in.gcount());
            }

            const std::string probe_text(probe.data(), probe_size);
            const bool ngage2_mime =
                (probe_text.find("Ngage-Install-File") != std::string::npos) ||
                ((probe_text.find("Content-Type: multipart/mixed") != std::string::npos) &&
                 (probe_text.find("application/sis") != std::string::npos));
            if (ngage2_mime) {
                LOG_INFO(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FIX3 MULTIIMPORT: rejected N-Gage 2.0 MIME package '{}'", src_path);
                return 106;
            }

            const bool zip_signature = probe_size >= 4 &&
                static_cast<unsigned char>(probe[0]) == 0x50 &&
                static_cast<unsigned char>(probe[1]) == 0x4b &&
                ((static_cast<unsigned char>(probe[2]) == 0x03 && static_cast<unsigned char>(probe[3]) == 0x04) ||
                 (static_cast<unsigned char>(probe[2]) == 0x05 && static_cast<unsigned char>(probe[3]) == 0x06) ||
                 (static_cast<unsigned char>(probe[2]) == 0x07 && static_cast<unsigned char>(probe[3]) == 0x08));
            const bool rar_signature = probe_size >= 7 &&
                probe[0] == 'R' && probe[1] == 'a' && probe[2] == 'r' && probe[3] == '!' &&
                static_cast<unsigned char>(probe[4]) == 0x1a && static_cast<unsigned char>(probe[5]) == 0x07 &&
                (static_cast<unsigned char>(probe[6]) == 0x00 || static_cast<unsigned char>(probe[6]) == 0x01);

            if (!zip_signature && !rar_signature) {
                LOG_ERROR(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FIX3 MULTIIMPORT: unsupported archive/container '{}'", src_path);
                return 107;
            }

            const std::string temp_root = eka2l1::add_path(conf->storage, "imports/ngage-classic-r2a-fix3/");
            common::delete_folder(temp_root);
            common::create_directories(temp_root);

            auto safe_relative_path = [](std::string rel) -> bool {
                std::replace(rel.begin(), rel.end(), '\\', '/');
                if (rel.empty() || rel.front() == '/' || rel.find(':') != std::string::npos) {
                    return false;
                }
                std::filesystem::path p(rel);
                for (const auto &part : p) {
                    if (part == "..") {
                        return false;
                    }
                }
                return true;
            };

            int extract_error = 0;
            if (zip_signature) {
                mz_zip_archive zip;
                std::memset(&zip, 0, sizeof(zip));
                if (!mz_zip_reader_init_file(&zip, src_path.c_str(), 0)) {
                    extract_error = 109;
                } else {
                    const mz_uint count = mz_zip_reader_get_num_files(&zip);
                    for (mz_uint i = 0; i < count; ++i) {
                        mz_zip_archive_file_stat st;
                        if (!mz_zip_reader_file_stat(&zip, i, &st) || !st.m_filename) {
                            extract_error = 109;
                            break;
                        }
                        std::string rel = st.m_filename;
                        if (!safe_relative_path(rel)) {
                            LOG_ERROR(FRONTEND_CMDLINE,
                                "NGAGE CLASSIC R2A FIX3 MULTIIMPORT: rejected unsafe ZIP path '{}'", rel);
                            extract_error = 105;
                            break;
                        }
                        std::replace(rel.begin(), rel.end(), '\\', '/');
                        const std::string dest = eka2l1::add_path(temp_root, rel);
                        if (mz_zip_reader_is_file_a_directory(&zip, i)) {
                            common::create_directories(dest);
                        } else {
                            common::create_directories(eka2l1::file_directory(dest));
                            if (!mz_zip_reader_extract_to_file(&zip, i, dest.c_str(), 0)) {
                                extract_error = 109;
                                break;
                            }
                        }
                    }
                    mz_zip_reader_end(&zip);
                }
            } else {
                RAROpenArchiveDataEx open_data{};
                open_data.ArcName = const_cast<char *>(src_path.c_str());
                open_data.OpenMode = RAR_OM_EXTRACT;
                HANDLE rar = RAROpenArchiveEx(&open_data);
                if (!rar || open_data.OpenResult != ERAR_SUCCESS) {
                    if (rar) {
                        RARCloseArchive(rar);
                    }
                    extract_error = (open_data.OpenResult == ERAR_MISSING_PASSWORD ||
                                     open_data.OpenResult == ERAR_BAD_PASSWORD) ? 108 : 109;
                } else {
                    while (extract_error == 0) {
                        RARHeaderDataEx header{};
                        const int header_result = RARReadHeaderEx(rar, &header);
                        if (header_result == ERAR_END_ARCHIVE) {
                            break;
                        }
                        if (header_result != ERAR_SUCCESS) {
                            extract_error = (header_result == ERAR_MISSING_PASSWORD ||
                                             header_result == ERAR_BAD_PASSWORD) ? 108 : 109;
                            break;
                        }

                        std::string rel = header.FileName;
                        if (!safe_relative_path(rel) || header.RedirType != 0) {
                            LOG_ERROR(FRONTEND_CMDLINE,
                                "NGAGE CLASSIC R2A FIX3 MULTIIMPORT: rejected unsafe RAR entry '{}' redir={}",
                                rel, header.RedirType);
                            extract_error = 105;
                            break;
                        }
                        if ((header.Flags & RHDF_ENCRYPTED) != 0) {
                            extract_error = 108;
                            break;
                        }
                        // Keep archive memory usage bounded on iPhone. Normal Classic game
                        // archives use tiny dictionaries compared with this ceiling.
                        if (header.DictSize > (256u * 1024u * 1024u)) {
                            extract_error = 109;
                            break;
                        }

                        std::vector<char> destination(temp_root.begin(), temp_root.end());
                        destination.push_back('\0');
                        const int process_result = RARProcessFile(
                            rar, RAR_EXTRACT, destination.data(), nullptr);
                        if (process_result != ERAR_SUCCESS) {
                            extract_error = (process_result == ERAR_MISSING_PASSWORD ||
                                             process_result == ERAR_BAD_PASSWORD) ? 108 : 109;
                            break;
                        }
                    }
                    RARCloseArchive(rar);
                }
            }

            if (extract_error != 0) {
                common::delete_folder(temp_root);
                LOG_ERROR(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FIX3 MULTIIMPORT: extraction failed code={} package='{}'",
                    extract_error, src_path);
                return extract_error;
            }

            // Accept both true card roots (System/... at archive root) and common
            // scene releases wrapped in one or two outer folders, e.g.
            // "Asphalt Urban GT 2/System/Apps/...".
            auto contains_system_apps = [](const std::filesystem::path &candidate) -> bool {
                std::error_code ec;
                for (const auto &entry : std::filesystem::directory_iterator(candidate,
                        std::filesystem::directory_options::skip_permission_denied, ec)) {
                    if (ec) {
                        return false;
                    }
                    if (!entry.is_directory(ec)) {
                        continue;
                    }
                    const std::string name = entry.path().filename().string();
                    if (common::compare_ignore_case(name.c_str(), "system") != 0) {
                        continue;
                    }
                    for (const auto &sub : std::filesystem::directory_iterator(entry.path(),
                            std::filesystem::directory_options::skip_permission_denied, ec)) {
                        if (ec) {
                            return false;
                        }
                        if (sub.is_directory(ec)) {
                            const std::string subname = sub.path().filename().string();
                            if (common::compare_ignore_case(subname.c_str(), "apps") == 0) {
                                return true;
                            }
                        }
                    }
                }
                return false;
            };

            std::filesystem::path game_root(temp_root);
            bool root_found = contains_system_apps(game_root);
            std::error_code scan_ec;
            if (!root_found) {
                for (const auto &level1 : std::filesystem::directory_iterator(game_root,
                        std::filesystem::directory_options::skip_permission_denied, scan_ec)) {
                    if (scan_ec) break;
                    if (!level1.is_directory(scan_ec)) continue;
                    if (contains_system_apps(level1.path())) {
                        game_root = level1.path();
                        root_found = true;
                        break;
                    }
                    for (const auto &level2 : std::filesystem::directory_iterator(level1.path(),
                            std::filesystem::directory_options::skip_permission_denied, scan_ec)) {
                        if (scan_ec) break;
                        if (!level2.is_directory(scan_ec)) continue;
                        if (contains_system_apps(level2.path())) {
                            game_root = level2.path();
                            root_found = true;
                            break;
                        }
                    }
                    if (root_found) break;
                }
            }

            const int classic_result = root_found
                ? install_ngage_game(game_root.string(), out_name)
                : static_cast<int>(ngage_game_card_no_game_data_folder);
            common::delete_folder(temp_root);

            LOG_INFO(FRONTEND_CMDLINE,
                "NGAGE CLASSIC R2A FIX3 MULTIIMPORT: direct install result={} game='{}' package='{}' type={}",
                classic_result, out_name, src_path, rar_signature ? "RAR" : "ZIP");
            return 100 + classic_result;
        }

        // ZIP/RAR System-tree archives are a Classic-specific convenience. Never
        // drop them into a Symbian 9.x N-Gage 2.0 E:\\n-gage directory.
        if (explicit_classic_archive) {
            return 107;
        }

        // Preserve the existing N-Gage 2.0 path for genuine .n-gage MIME packages.
        io_system *io = sys->get_io_system();
        auto drive_entry = io->get_drive_entry(drive_e);
        if (!drive_entry) {
            return -1;
        }

        std::string current_dir;
        common::get_current_directory(current_dir);
        const std::string e_root = eka2l1::absolute_path(drive_entry->real_path, current_dir);
        const std::string ngage_dir = eka2l1::add_path(e_root, "n-gage");
        eka2l1::common::create_directories(ngage_dir);

        const std::string base = eka2l1::filename(src_path);
        if (base.empty()) {
            return -2;
        }
        const std::string dest_name = common::is_platform_case_sensitive()
            ? common::lowercase_string(base) : base;
        if (dest_name != base) {
            common::remove(eka2l1::add_path(ngage_dir, base));
        }
        const std::string dest = eka2l1::add_path(ngage_dir, dest_name);
        if (!eka2l1::common::copy_file(src_path, dest, true)) {
            return -2;
        }
        out_name = base;
        LOG_INFO(FRONTEND_CMDLINE, "Copied N-Gage package '{}' to '{}'", src_path, dest);
        return 0;
    }
'''
lt = lt[:start] + new_func + lt[end:]

# -------------------------------------------------------------------------
# UIKit: accept ZIP/RAR, reject EKA2 SISX on NEM-4 with a precise message,
# and render new importer return codes.
# -------------------------------------------------------------------------
helper_anchor = '''static BOOL EKAIsSisPackagePath(NSString *path) {
    NSString *ext = path.pathExtension.lowercaseString;
    return [ext isEqualToString:@"sis"] || [ext isEqualToString:@"sisx"];
}
'''
if rt.count(helper_anchor) != 1:
    raise SystemExit('FIX3: UIKit helper anchor invalid')
helper_extra = r'''
static BOOL EKAIsClassicArchivePath(NSString *path) {
    NSString *ext = path.pathExtension.lowercaseString;
    return [ext isEqualToString:@"zip"] || [ext isEqualToString:@"rar"];
}

static BOOL EKAIsCurrentDeviceNEM4(void) {
    int index = eka2l1::ios::bridge::get_current_device();
    if (index < 0) return NO;
    std::vector<eka2l1::ios::bridge::device_entry> devices = eka2l1::ios::bridge::get_devices();
    return static_cast<std::size_t>(index) < devices.size() && devices[index].firmware == "NEM-4";
}

static BOOL EKAIsEKA2SisxPackage(NSString *path) {
    NSFileHandle *handle = [NSFileHandle fileHandleForReadingAtPath:path];
    if (!handle) return NO;
    NSData *prefix = [handle readDataOfLength:4];
    [handle closeFile];
    if (prefix.length != 4) return NO;
    const uint8_t *b = static_cast<const uint8_t *>(prefix.bytes);
    uint32_t uid1 = static_cast<uint32_t>(b[0]) |
                    (static_cast<uint32_t>(b[1]) << 8) |
                    (static_cast<uint32_t>(b[2]) << 16) |
                    (static_cast<uint32_t>(b[3]) << 24);
    return uid1 == 0x10201A7A;
}
'''
rt = rt.replace(helper_anchor, helper_anchor + helper_extra, 1)

# Generic imported-file dispatch.
rt = rt.replace(
    '    if (EKAIsNGagePackagePath(path)) {',
    '    if (EKAIsNGagePackagePath(path) || EKAIsClassicArchivePath(path)) {',
    1,
)

sis_anchor = '''    if (EKAIsSisPackagePath(path)) {
        if (!eka2l1::ios::bridge::has_device()) {'''
if rt.count(sis_anchor) != 1:
    raise SystemExit('FIX3: SIS dispatch anchor invalid')
rt = rt.replace(
    sis_anchor,
    '''    if (EKAIsSisPackagePath(path)) {
        if (!eka2l1::ios::bridge::has_device()) {''',
    1,
)
# Insert compatibility gate immediately after the no-device block.
no_device_sis = '''            [self showAlert:EKAL(@"No device") message:EKAL(@"Install a Symbian device first, then install the package.")];
            return;
        }

        std::string packagePath = [path UTF8String];'''
if rt.count(no_device_sis) != 1:
    raise SystemExit('FIX3: SIS compatibility insertion anchor invalid')
rt = rt.replace(
    no_device_sis,
    '''            [self showAlert:EKAL(@"No device") message:EKAL(@"Install a Symbian device first, then install the package.")];
            return;
        }
        if (EKAIsCurrentDeviceNEM4() && EKAIsEKA2SisxPackage(path)) {
            [self showAlert:EKAL(@"Not compatible with N-Gage Classic")
                    message:EKAL(@"This SIS/SISX package targets Symbian OS 9.x (EKA2). The current N-Gage NEM-4 firmware uses Symbian OS 6.1 (EKA1).")];
            return;
        }

        std::string packagePath = [path UTF8String];''',
    1,
)

rt = rt.replace(
    'EKAL(@"Choose a SIS, SISX, or .n-gage file.")',
    'EKAL(@"Choose a SIS, SISX, .n-gage, ZIP, or RAR file.")',
)
rt = rt.replace(
    'EKAL(@"Install .n-gage File")',
    'EKAL(@"Install N-Gage Game File…")',
    1,
)
rt = rt.replace(
    '[self beginProgress:EKAL(@"Adding .n-gage file…")];',
    '[self beginProgress:EKAL(@"Importing N-Gage game…")];',
    1,
)

# Replace FIX1 result block with FIX3-specific diagnostics.
old_result = r'''            if (result == 100) {
                [self endProgress];
                [self showAppsScreen];
                [self showAlert:EKAL(@"N-Gage game installed")
                        message:[NSString stringWithFormat:EKAL(@"Installed %@ directly into the current N-Gage firmware. It now appears in the apps list."), fileName]];
            } else if ((result >= 101) && (result <= 105)) {
                [self endProgress];
                [self showAppsScreen];
                NSString *msg = (result == 105)
                    ? EKAL(@"The .n-gage archive could not be extracted safely.")
                    : [self ngageErrorMessage:(result - 100)];
                [self showAlert:EKAL(@"Install failed") message:msg];
            } else if (result == 0) {'''
new_result = r'''            if (result == 100) {
                [self endProgress];
                [self showAppsScreen];
                [self showAlert:EKAL(@"N-Gage game installed")
                        message:[NSString stringWithFormat:EKAL(@"Installed %@ directly into the current N-Gage firmware. It now appears in the apps list."), fileName]];
            } else if ((result >= 101) && (result <= 109)) {
                [self endProgress];
                [self showAppsScreen];
                NSString *msg = nil;
                if (result >= 101 && result <= 104) {
                    msg = [self ngageErrorMessage:(result - 100)];
                } else if (result == 105) {
                    msg = EKAL(@"The selected archive contains an unsafe path or link and was not extracted.");
                } else if (result == 106) {
                    msg = EKAL(@"This is an N-Gage 2.0 package for Symbian OS 9.x. It cannot be installed on N-Gage Classic NEM-4 / Symbian OS 6.1.");
                } else if (result == 107) {
                    msg = EKAL(@"This file is not a supported N-Gage Classic game archive. Use a Classic .n-gage ZIP, ZIP/RAR System folder, or compatible SIS package.");
                } else if (result == 108) {
                    msg = EKAL(@"Password-protected or encrypted RAR archives are not supported.");
                } else {
                    msg = EKAL(@"The N-Gage game archive could not be extracted.");
                }
                [self showAlert:(result == 106 ? EKAL(@"Not compatible with N-Gage Classic") : EKAL(@"Install failed")) message:msg];
            } else if (result == 0) {'''
if rt.count(old_result) != 1:
    raise SystemExit('FIX3: FIX1 result block not found')
rt = rt.replace(old_result, new_result, 1)

# Picker validation for the N-Gage file action.
picker_check = '''        if (!EKAIsNGagePackagePath(local)) {
            [self showAlert:EKAL(@"Unsupported file") message:EKAL(@"Choose a .n-gage file.")];
            return;
        }'''
if rt.count(picker_check) != 1:
    raise SystemExit('FIX3: N-Gage picker validation anchor invalid')
rt = rt.replace(
    picker_check,
    '''        if (!EKAIsNGagePackagePath(local) && !EKAIsClassicArchivePath(local)) {
            [self showAlert:EKAL(@"Unsupported file") message:EKAL(@"Choose a .n-gage, ZIP, or RAR file.")];
            return;
        }''',
    1,
)

# -------------------------------------------------------------------------
# Vietnamese localization additions. Insert before the dictionary close using
# an existing unique entry as an anchor. Do not replace older translations;
# keeping them is harmless for legacy paths.
# -------------------------------------------------------------------------
loc_anchor = '        @"Install .n-gage File" : @"Cài tệp .n-gage",'
if lc.count(loc_anchor) != 1:
    raise SystemExit('FIX3: localization anchor invalid')
loc_extra = r'''
        @"Install N-Gage Game File…" : @"Cài tệp trò chơi N-Gage…",
        @"Importing N-Gage game…" : @"Đang nhập trò chơi N-Gage…",
        @"Choose a SIS, SISX, .n-gage, ZIP, or RAR file." : @"Chọn tệp SIS, SISX, .n-gage, ZIP hoặc RAR.",
        @"Choose a .n-gage, ZIP, or RAR file." : @"Chọn tệp .n-gage, ZIP hoặc RAR.",
        @"Not compatible with N-Gage Classic" : @"Không tương thích với N-Gage Classic",
        @"This is an N-Gage 2.0 package for Symbian OS 9.x. It cannot be installed on N-Gage Classic NEM-4 / Symbian OS 6.1." : @"Đây là gói N-Gage 2.0 dành cho Symbian OS 9.x. Không thể cài gói này trên N-Gage Classic NEM-4 / Symbian OS 6.1.",
        @"This SIS/SISX package targets Symbian OS 9.x (EKA2). The current N-Gage NEM-4 firmware uses Symbian OS 6.1 (EKA1)." : @"Gói SIS/SISX này dành cho Symbian OS 9.x (EKA2). Firmware N-Gage NEM-4 hiện tại sử dụng Symbian OS 6.1 (EKA1).",
        @"The selected archive contains an unsafe path or link and was not extracted." : @"Tệp nén có đường dẫn hoặc liên kết không an toàn nên đã bị từ chối giải nén.",
        @"This file is not a supported N-Gage Classic game archive. Use a Classic .n-gage ZIP, ZIP/RAR System folder, or compatible SIS package." : @"Tệp này không phải gói trò chơi N-Gage Classic được hỗ trợ. Hãy dùng .n-gage Classic dạng ZIP, ZIP/RAR chứa thư mục System hoặc gói SIS tương thích.",
        @"Password-protected or encrypted RAR archives are not supported." : @"Chưa hỗ trợ tệp RAR được đặt mật khẩu hoặc mã hóa.",
        @"The N-Gage game archive could not be extracted." : @"Không thể giải nén gói trò chơi N-Gage.",'''
lc = lc.replace(loc_anchor, loc_anchor + loc_extra, 1)

# -------------------------------------------------------------------------
# Strict regression/source guards.
# -------------------------------------------------------------------------
for token in (
    'NGAGE CLASSIC R2A FIX3 MULTIIMPORT:',
    'RAROpenArchiveEx',
    'RARReadHeaderEx',
    'RARProcessFile',
    'Ngage-Install-File',
    'contains_system_apps',
    'return 106;',
    'return 100 + classic_result;',
):
    if token not in lt:
        raise SystemExit('FIX3 launcher audit missing: ' + token)

for token in (
    'EKAIsClassicArchivePath',
    'EKAIsEKA2SisxPackage',
    'Install N-Gage Game File…',
    'result <= 109',
    'Not compatible with N-Gage Classic',
):
    if token not in rt:
        raise SystemExit('FIX3 UIKit audit missing: ' + token)

if lt.count('std::uint32_t launcher::get_current_device()') != 1:
    raise SystemExit('FIX3: get_current_device regression')
if lt.count('bool launcher::does_rom_need_rpkg(const std::string &rom_path)') != 1:
    raise SystemExit('FIX3: does_rom_need_rpkg regression')
if ct.count('add_library(ngage_unrar STATIC') != 1 or '\n    ngage_unrar\n' not in ct:
    raise SystemExit('FIX3: UnRAR CMake integration missing')
if '\n    miniz\n' not in ct:
    raise SystemExit('FIX3: miniz regression')

launcher.write_text(lt, encoding='utf-8')
rootvc.write_text(rt, encoding='utf-8')
loc.write_text(lc, encoding='utf-8')
cmake.write_text(ct, encoding='utf-8')

print('NGAGE CLASSIC R2A FIX3 MULTIIMPORT patch: PASS')
print('Classic .n-gage ZIP: PASS')
print('ZIP System-tree import: PASS')
print('RAR System-tree importer source: PASS')
print('N-Gage 2.0 MIME rejection on NEM-4: PASS')
print('Symbian 9.x SISX rejection on NEM-4: PASS')
print('launcher helper preservation: PASS')
