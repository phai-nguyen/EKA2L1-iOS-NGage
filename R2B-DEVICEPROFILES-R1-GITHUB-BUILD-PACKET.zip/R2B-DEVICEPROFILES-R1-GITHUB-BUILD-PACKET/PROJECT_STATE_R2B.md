# EKA2L1 iOS — N-Gage Classic R2B DEVICEPROFILES

Checkpoint date: 2026-09-03

## Frozen baseline

R2A FINAL1 is now FROZEN/PASS.

Runtime matrix reported PASS on iPhone:
- Fresh N-Gage NEM-4 V4.03
- Asphalt Urban GT 2 RAR
- FIFA 2005 RAR
- Bomberman RAR (nested System/Apps)

Validated FINAL1 IPA SHA-256:
`ba6db483d3b7ed0056bcf013dbcbec1bf0421594cfe6abc446a260a041201c69`

Do not modify the R2A FINAL1 importer unless a DEVICEPROFILES regression proves it necessary.
Do not mix V24 AUDIOGATE or N-Gage 2.0 17452 DIAG into this branch.

## Current branch

R2B DEVICEPROFILES R1 — PROFILE STORAGE FOUNDATION

R1 intentionally separates storage virtualization from the later duplicate-product-code install change.

### Implemented in R1

- Adds persistent `profile_id` and `rom_fingerprint` device metadata.
- ROM fingerprint is FNV-1a 64 and is used only as a stable namespace fingerprint, not as a cryptographic hash.
- Existing FINAL1 `devices.yml` is migrated compatibly and keeps `firmcode` as the Nokia product code.
- Global registry map keys become profile IDs while `firmcode` remains explicit metadata.
- On first R2B boot, legacy FINAL1 data is copied non-destructively into:

  `firmware-profiles/<profile-id>/`

- Active C:, E:, Z: and ROM paths are selected from the active profile.
- Legacy FINAL1 storage is retained as rollback/fallback during R2B validation.
- Freshly installed ROMs have their profile identity refreshed after the installer finishes writing `SYM.ROM`.
- R2A FINAL1 and BOOTREADY1 markers are guarded against regression.

For bundled NEM-4 V4.03 (`SYM.ROM` SHA-256 `afc1cc8b...39574ef`), the expected R1 profile ID is:

`nem-4__a31e6f81e38803d8`

Expected host layout:

```text
firmware-profiles/
└── nem-4__a31e6f81e38803d8/
    ├── devices.yml
    ├── .r2b-deviceprofiles-r1
    ├── roms/
    │   └── nem-4/SYM.ROM
    └── drives/
        ├── c/
        ├── e/
        └── z/
            └── nem-4/...
```

### Deliberately deferred to R2B R2

- Remove the current duplicate-device guard keyed by `firmware_code`.
- Allow two firmware revisions with the same product code (for example RM-596 v0225 and RM-596 v111) to coexist.
- Install new firmware directly into an isolated profile staging root rather than using the legacy install root.
- Add robust firmware-version metadata/display for general devices.
- Final profile name format will evolve toward `product__version__fingerprint` while preserving R1 migrations.

## R2B R1 test gate

1. Build the R2B R1 workflow.
2. Inspect the unsigned IPA before install.
3. Upgrade over the existing FINAL1 data first; confirm N-Gage and existing games/saves still work.
4. Confirm log contains `NGAGE CLASSIC R2B DEVICEPROFILES R1:` and expected profile ID.
5. Install one new Classic game and confirm it remains after reboot.
6. If another existing Symbian device is available, switch between devices and confirm C:/E: content does not change across profiles after each profile has been initialized.
7. Re-run Asphalt/FIFA/Bomberman importer smoke tests to prove FINAL1 was not regressed.
8. Only after R1 PASS, proceed to R2B R2 duplicate-product/multi-firmware coexistence.

## Deferred graphics issue

`Corrupted graphics command list! Emulation halt.` during EKA1 teardown/exit remains deferred from R2A. It is not an R2B blocker unless it prevents profile switching/storage recovery.
