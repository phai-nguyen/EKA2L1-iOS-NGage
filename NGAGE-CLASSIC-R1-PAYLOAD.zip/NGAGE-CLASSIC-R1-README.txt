EKA2L1 iOS — N-Gage Classic R1 BUNDLED NEM-4
==============================================

Mục tiêu
-------
Tích hợp firmware Nokia N-Gage Classic NEM-4 V4.03 trực tiếp vào IPA EKA2L1 iOS
và thêm menu "Thêm chế độ" -> "N-Gage".

Baseline
--------
- Nhánh độc lập N-Gage Classic.
- Baseline chung: V23 VI FIXED2.
- Không áp dụng V24 AUDIOGATE / V24 AUDIORETRY.

Hai file dùng để build
----------------------
1. .github/workflows/build-ios-ngage-classic-r1-bundled-NEM4-VI.yml
2. NGAGE-CLASSIC-R1-PAYLOAD.zip đặt tại THƯ MỤC GỐC của repository.

Workflow giải nén payload, kiểm SHA-256 của payload/ROM/patch, chép ROM vào source:
  upstream/src/emu/ios/ngage/SYM.ROM

Sau build, ROM nằm trực tiếp trong ứng dụng:
  EKA2L1.app/assets/ngage/SYM.ROM

Firmware
--------
File: SYM.ROM
Kích thước: 18,612,224 bytes
SHA-256: afc1cc8b693f2b68d23ca203aa4d4eb4266baad4ab718f013a33b915d39574ef
Thiết bị: Nokia N-Gage Classic / NEM-4
Firmware: V4.03 / 26-11-2003
OS: Symbian OS 6.1 / Series 60 1.2

Giao diện
---------
Khi chưa cài thiết bị:
  Thêm chế độ
    -> N-Gage
    -> Thiết bị Symbian…

Chọn N-Gage sẽ dùng firmware đã nhúng, không mở trình chọn ROM/RPKG. Nếu NEM-4 đã
được cài trước đó, ứng dụng tái sử dụng thiết bị đó thay vì tạo bản trùng và đặt
tên hiển thị là "N-Gage".

Trong menu Thiết bị, mục thêm thiết bị mới trở thành "Thêm chế độ…".

Phạm vi
-------
Patch chỉ tích hợp firmware và luồng frontend/device install. Không sửa game.lic,
nokia.dat, game executable, DRM hoặc kết quả kiểm tra bản quyền.

Artifact dự kiến
----------------
IPA: EKA2L1-iOS-NGage-Classic-R1-NEM4-unsigned.ipa
Artifact: EKA2L1-iOS-NGage-Classic-R1-NEM4-IPA

Lưu ý repository public
-----------------------
Payload này chứa nguyên file SYM.ROM. Nếu commit NGAGE-CLASSIC-R1-PAYLOAD.zip vào
repository public, firmware trong payload cũng có thể được tải công khai. Nếu bạn
không muốn điều đó, dùng repository private cho nhánh/payload này.
