R2FX2 R2 CRASHFIX1 SUPPORT1

This companion ZIP contains all non-workflow build data for the SUPPORT1 manual workflow:
- payload/SYM.ROM (frozen NEM-4 ROM)
- R1/R2A patch scripts
- CRASHFIX1 source patch audit copy
- all historical inline Python helpers and binary/base64 blobs externalized from the YML
- SHA256SUMS.txt

Place this ZIP at the repository root. The workflow is workflow_dispatch-only.
