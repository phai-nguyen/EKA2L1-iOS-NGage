from pathlib import Path
text = Path('upstream/src/emu/kernel/src/msgqueue.cpp').read_text()
s = text.index('bool msg_queue::send(')
p = text.index('msgs_.push(new_data);', s)
w = text.index('V18 MSGQ40 WAKE-BEFORE:', s)
v = text.index('V17 MSGQ ORDER:', s)
assert p < w < v, (p, w, v)
print('V18/V17 msg_queue ordering proof: PASS')
