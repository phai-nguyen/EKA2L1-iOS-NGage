import base64, gzip, hashlib, pathlib, subprocess

data = (
    'H4sIAAHhlGoC/+1bWXPbRhJ+168YK1UuMgQP8BYlcS3bUoq1lp2Sj0r2YVFDYEiiBAIIDh3r6L9v9wyOAQhQPOQkTqQHkcQ0pnv6'
    '/HowMMzZjNTrczMgtOl7epMtw6bPvBtTZ37TtHUrNFh6gYaG6TSXy1lTd5ZLx24syHSn2w5M22B3RJ91Bka/1WjQqdHuDVSitlr9'
    'bvegXq/vKM9BrVbbVaZXr0hdPVL6pAb/B+TVqwNyQH5wPTpfUuLYOoPftR+imciJ7geGwWZjoMlcM+1gjHfadMl8l+qMsGvattTR'
    'iLmOTr5yPn3OZ9DifMpJSfwH845GIUzdaWsBmYazGfM03/wf0zyGC2CgT6NSJbpj+8GxuO/hGAXGb80mecfmVL8nb9nNRye0DeJ6'
    'zt09AZ7XdM5I6DODTOG3x+of75dTk9r/7RDdMpkd+I2DSAQv1AMCKtMMdqP5OI3Gp9F8FgSmPfdliZHOD2jACP+vHZctZnHL5wtN'
    'A2hQN8OBooJyhkdKr7+LdgLHZppjaxaz58GinLGgm80eJXQp6CelqsdUzWaWznZmGrsBlUWLKSWET+bNYEVakakSAzTPbJsSm93W'
    'qacvzIDpQegxyYbCeg3yacFIcOuQgJoWuXU8wyfUY8mEYFUfpAK2JABKVW3Xp/dgmNj6zhTDAjxg5jlLcnVZ7x31yU2r3Wu0WoMG'
    '+TdjLtxo+smEFOYnhumD0cEjzl5PSHDvgqEdCOCumNsS/ha5EPHYkgJ7P3RdxwuY0RBzbeBT2k0bTF0rd6vaBm5VQjNzQk/TdZkA'
    '59epS6emZQYm8wn88NcTOPasnMWS3mk3jrVCEI+vG8N756C2UoK1gxabBZrLPB0MAFYupfPM+WIjwpnHftMwZtYSgB8WaqPfBQoj'
    '9GhgOna5vlaCt7Zp8NY2Ct4SqnzolpDJgVuLArcWuzKsTNeoD7EUVDA1O7PKOseuktNTjBeFHEbJ+fLyIp+gMbaWoR/g9PdITTC6'
    '/MPq8Y5cIZwEY7UNjHmCeZyt2l7LFswA0z/OWMmpOdJAS0nVnUqUJSWCR0YXrb3FSc2ZGKNIlJSsSIwuF2OlRrqe6XhmUFwcM2GT'
    'UB6XErCZPFhSWtMisk6MXD4tk6S2TpLtszFWICwxW8TNiuTCRu1svMRUeZdtbxooRQoSnPpygJTx6Ut8hBmYHS7Tioar9jTH1R3A'
    'hzl4hASmbQYtckogCArHOjDWUQ6MtUAdL6SAFm5t6K5bBIMLCSMw3hkarNebNhrtblufTjuPgPHiqUrgdzExgr1OC4Ew/B9ywC1B'
    'aQ7Lm5Yzbyw4nk6HHBdrCLXGhXA8e80DkxbC8dgYwjEEcCb6gnrkR7C39vb8i/bx/OrL+ZX2/uzyHKxw+AKuY57kJj0UWLUzRPG7'
    'sIhCIF/EhN25Xi46kOHrzxcXwOzj5D/n2uXZL+gSd91Wq3W80wxvzy/OPr/7xGdRxSwJevuidkZ5kAk1EjFdAg1L+oTbhWkBXrQM'
    '5iXTxRAPpkgLlMCkFr13woCDUWIaQGXq1AIo6TnhfFFYmWE+hKhcppgpXLAJNQDU5moCBfnS3NyQA12oJ3aUE2wYRqN19WAMKYoa'
    'msgI8kAlcmJIgq6ugf5B/QH5UQ/ulMhpTITWxl1VTqtihAvBu7SArwbyH/4Cq8Dt9fGcBRr15uESV2TQgPLRCs6VpEf8M2ekIt8+'
    'PiVRAnt8XZjNMpKl0tEwcCKxyiXClgAm93XPdAPHO9mI4zheg8wUV/FCsFsRCP88Bt2NLXRmh5YFxsvN8CArhafaR4WJ+pCvD8cF'
    'GkjjKLKRyDmxjRIcsdGaV8BNjmO2AGU4CRBEDj/bIBE0eWCPpO4IwjoWXvOOm/1wdWZYwZItdfe+8lKsVyEvhaYbN9QKWaWqyGvL'
    'TxBpXtwqjWX0HRE9mZtkfOQhiwbI1HGgkYV6y/aJSCUfjxv4y8sUbXw34QxJ8+cIYCXZs+7Y1r28IYCtN2Rqvs2DRCJtRxk9dEFe'
    'mH9lXk7JPYcIKFN3bm3cKTCZZUCWv3RQ3Uts6qkdWOB417hbkHoCEfl9ZWIa8LbCxDCkBsQa8RdQq69BCGJie4e1pLFtuCO4Fapd'
    'iXjUupT3oIZ9i6SnEIDerFqY4JJUC7zjuHwsw/0ZeUrKJkJkJY2KTfIIV6oIXq7NwJF0mWh6K6VGZWOT3PQUjCOuSSooyVJlGGOl'
    'pciAi9zYn4YvtklHhU3St4EVRaz+eDyx2r1Dgg2tYCWtiMuNhB6WLGSqj4u66cwt0EtnyLO9tUQqmmuJdqXblhYs7nnqMr7q0/n6'
    'TfKRITX/ySMKTXp0UZGcOKH16dK1mObB+qpyv4zWlsbICbTe0NdkaKT1rXRUk/eiYWsfqcoAGs5eVynt2MSMN45p5Pt46JJ8iHZQ'
    'idjWBdWVx291Zcdnq34k/pY+RsC/06dEYO18TJ2WdkE8HyE9ydrkhYyXMpbgcoLhwWQBi3IJ8zwpE1ejHhrAr9oBm/Q7+LnWKFyV'
    'Ecf6ON5cJ4igUbR6hvnTlIJ2Wgjiqi2rrRSlCo0V3ryBjmzHZjHlw0Yu+eyOT+SOak8BZFrrDIb4uYU7Rq4oDKH90/0R+GyDdtBg'
    '9cfcswBZwaW0SJ8+SWFTq/l97J1EWYP5uC3UAveVp9jDhdtD4cJQ7NTeuo3JjDl5kwICgOyiC3BuWEWWqMjf3n34SZu8v/hQwd3S'
    'yRsotZcXZ5/fKtlIPvwCmR1Gjnrk56vJh6vJp1/PXk9GAtAEp18fkg128Z3N8JPDHPhymJttHbpVqwpfRArJkt+Ar5R4H0anfnCS'
    'gR5jvtQIa33TqPj+M7W6ZaZWv02m7uH5mVpX7e+F5dAk+CT92SB7G2TAwXW3M9jLIN+7MZ4Sx5Dffycv/ADuX2p7GGbY4xC721O3'
    'hNj8iAlfgO54BlzThDCVqhirVP/pOCc+pfPssU/psd1W5LEDdYemcJ3XJvb6x3uua9F7bUotauvPfePexa/bVoXH4vnVzmOgO/XX'
    '/Dk9kJ5figyTORWU3LRyaA/XzK9Jtz23n38TB/9roDsED4DueuoadJfspN8E2tKfa7+FLOTOec08m6vjBL8xC5YcD48rq6rizpHv'
    'z9pV2Wn2shlv8r4Xy2WEbSyor8Vq2NmWvVaf23LQfrbld2/Lbg9t2VfVvbou+VD7MxrYN1n2el2OBvrt1pb4lb9wAEKjNvD7M07F'
    'Uo5vWZjz5yK+t18OIr/sgl8OH0v9/N2Whvy6Gd8bzu2gJkldnA2BVGLRpVspeAarFB11VfJPcIufFuPbJVVRLXbffH7z4f3F5Cd5'
    '3xmfJmtL6l+ftu6+jn554G+x4ACzdQdbx/i6vqA2FDsfx4RcO+xMC4VyngrntHZDWlDHgmhVZeW8BQzHcmlKgbnSY+nRewHYldfH'
    '4tmMA/0Dz/ZCkNx03yqa53+LaP6LVJnhkTKEYO5vXWTQ1qgR8fLaH1lf6hs7Ve60k3Qo1LkG2XepT5lTT+uCtV3d/1wmZqdPV2dv'
    'ztenp1yKOns9UdX2iIh3RuLswxc7hazFn4/F2euwYCq+KgDk9fEstHWMGiXV2r+ISkakpZD1a8+dtCu2mDRp3njAo8Rrt0wUyQuj'
    'mmm7YSQkvmwKsCh+lZr3o7X+UWfvp0DRk3sPq9dzbtozN/UHvC0Z4COH4eO5Cd9Rp+CwC37meGZ6fvyeOxf+Ho8ET3HAspiR3mY4'
    'msfQRWKsAPlqyjRBVpHTTVr8AuoFlZL8wgf5ycWInrx8ue7W7R9/vzv7dfJ+8mkUs1oLQjYCHbHMaXBLKCNLyl/RxTfUUE/wMWVe'
    'RQYgqXtJh+1iIOKJJ+M7opBavhFGmVdyZqTq5MSjJBC/ZBoWOy7AXIUeOWc286hVfE45k+LI9ljn/zlyKeM8QwAA'
)
raw = gzip.decompress(base64.b64decode(data))
expected = '39821be7a510faaadcfb60a5d577e3d14949cc1792e14549f587e495d6e71532'
actual = hashlib.sha256(raw).hexdigest()
if actual != expected:
    raise SystemExit(f'V13 patch SHA256 mismatch: {actual} != {expected}')

patch = pathlib.Path('v12-to-v13.patch')
patch.write_bytes(raw)
subprocess.run(['git', '-C', 'upstream', 'apply', '--check', str(patch.resolve())], check=True)
subprocess.run(['git', '-C', 'upstream', 'apply', str(patch.resolve())], check=True)
print('Installed V13 MMF95 112-byte proxy + 16-byte priority ABI fix')
