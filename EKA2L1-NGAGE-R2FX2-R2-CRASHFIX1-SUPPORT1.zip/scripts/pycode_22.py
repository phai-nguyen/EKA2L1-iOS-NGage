from pathlib import Path
s = Path("upstream/src/emu/ios/src/launcher.cpp").read_text(encoding="utf-8")
a = s.find("#include <raros.hpp>")
b = s.find("#include <dll.hpp>")
if a < 0 or b < 0 or a > b:
    raise SystemExit("BUILD-FIX1 guard failed: raros.hpp must precede dll.hpp")
print("UnRAR Apple include-order guard: PASS")
