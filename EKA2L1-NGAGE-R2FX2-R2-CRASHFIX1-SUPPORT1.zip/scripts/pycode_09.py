import base64, gzip, hashlib, pathlib, subprocess
data = (
    'H4sIAA6AlWoC/+1YWW/jNhB+z69g9iGVIyu2Et/ZGns0WyzaRdE0XaBPhI6RzY2ukpSTdJH/3qEk25ItWc7VLYrqwYSo4XCub/jRLvM8YhgzJo'
    'nVEdzpQJB0BPAFc0B0WOj4iQvrCStxWdQJAq/jwuJkTuyHrzlgoQu3xHOtrmsPT07Gjme7YBKz2x30egeGYTzGkgNd1x9lzZs3xBgN2+Yp0bMB'
    'J0IrABFbDhC4tk59k3w9IMvnGngI/mQyt0LXB+JGVICkduJ5wNVAcZ7OcIqDTHhIF5afgNY6X2tYRMzdWCcjagP1mO+DWy2b2AFbibuWtFC/A2'
    'yRqjY2xTnEEa/Vvpc4BLFkmby+lLejyG9Wv5d4QX3ZWRain0JysAIq5zxKZnN8tWRVDIEDxlsldKncmSfhdUkyNSJGEywONbLleAjABMICQqlM'
    'DcSM/pkAptCJQiEJuuJMJlg+FMuHiihB4fQ7ZRICcqR+t2LwLCrLvgsZxamfG54yoQoj4i4LZ3kYtRbJNvp64O5Eu5oow8OJ4ypQVQrmuHaG3f'
    'GZ3Udcn/UHJtgNuK5WVQPmamGF4DNz1DbPiJ6OozoMr2NVfDod8hNATOQcZbHUbJ+JObg50okxxfwJwaKQ+JFzTTC2wE+qVWVxFtKdTJQsnSUW'
    'd1+n70Ei4XZK0hlNJdpy0CVBU7lixRSfDEHgI845WvQ9kTyB8+q9mUc03xIrnLWKXWvb0CD2QQKNfetOyyoQOI84xeoD7vnRTatmn3sCvgBUbt'
    'Qp379DbK0suNqopdo6zHKlYVk7zgOo1wXwcGWBCl+tnT//8iO9unz7/kL77eLy88f3F/TTpw9vf/+hXb9EPa8+mwOCkuM++fXy4uryjwl5l/p2'
    'Fb2DD6ljJG0TJMU/8RLfP1eW8zviYwvkr+qCd189nTu9cqoiaPft7bkQ940lT9tLiq5ejq7+2f/oegi6slb8D+Gr6sR+BMCqTub/BsIuMs/+lR'
    'DrD82Ug/ZH5h4k1JG3xnRZZaXyCqMQlplbZSplDCuCgacpJjtH3WTyDORkmcgUUC+7T7mWYCHXmlJMGtu52chnnjDPQpQVklUq67JeY6ps11Ib'
    '2kSwvyDytN0Gt4pVlO/4LEpXtpLGxCom3dVy8oSvsUMx1tgnJTnGAlLRSi8/2NyHePnpq6Gh7u4fUlhN/WWvqtlDycq6sg5yrEbsc9nr6/LX6Q'
    'Z5zo4jKu6EKrdj9ZovNabqNpd/j+wv4Ega3YTAlYY0gP2hOhX10QDHcVMIU289xvEokSwA3OSweB+hJatUkTfUeB2sdpfSxucQbizuzKktVWwX'
    'slW8FVUfSMq03HAWehE9USm501qtqpNrCURjR0PNUfJi/ui1BxhSlI/oArF8vC65dySjmG3C5HeCfEmwO8UWlmM4I+reJFbHOwmjm8OyqlJEVg'
    '26SByy/w1KnGRXKPdrXfpa7mnO6E9ypMQAnt4pllT/KY2ioOOb94nhoG32sE+Mhu3TbjOL3qdT6LVcdrNIvkEr8bagt0lBX2zHbTZNnty89Brq'
    'txnp0gld4Ow7/u+rDdAGmS4hvYFN7+A5ZRJVKLGjo7yUcyix0HIk6l/fWrIYpeU8HrYHRB+bvXreUI4BboF9B4mPgxfAxIcs85rZVU+brPbIK6'
    'KNLjDkKzxGV6iDrSe76yU4OehROdXknIlytpt6EWnsI7v+KkSX/gb/TairMBcAAA=='
)
raw = gzip.decompress(base64.b64decode(data))
expected = 'db778e1569a2ba0daee46a0cc77b101129d6798f244636069d41f257b2bfd6e6'
actual = hashlib.sha256(raw).hexdigest()
if actual != expected:
    raise SystemExit(f'V16 patch SHA256 mismatch: {actual} != {expected}')
patch = pathlib.Path('v15-to-v16.patch')
patch.write_bytes(raw)
subprocess.run(['git', '-C', 'upstream', 'apply', '--check', str(patch.resolve())], check=True)
subprocess.run(['git', '-C', 'upstream', 'apply', str(patch.resolve())], check=True)
print('Installed V16 MMF event-queue backpressure retry fix')
