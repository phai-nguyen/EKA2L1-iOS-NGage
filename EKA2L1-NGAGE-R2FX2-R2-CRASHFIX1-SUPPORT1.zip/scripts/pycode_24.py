from pathlib import Path
data = Path("build-ios-device/src/emu/ios/eka2l1.app/eka2l1").read_bytes()
required = [
    "Ngôn ngữ ứng dụng",
    "Theo hệ thống",
    "Tiếng Việt",
    "Ngôn ngữ",
    "Tạo sao lưu (.zip)",
    "Đồng bộ và Sao lưu",
    "Đồng bộ và Sao lưu — Lỗi",
    "Đồng bộ và Sao lưu — Đã đồng bộ",
    "%@ — Ngôn ngữ",
    "Đang đổi ngôn ngữ…",
    "Đã đặt ngôn ngữ",
]
for text in required:
    if text.encode("utf-8") not in data and text.encode("utf-16le") not in data:
        raise SystemExit(f"ERROR: missing Unicode localization marker in binary: {text}")
    print(f"PASS Unicode: {text}")
print("V23 Vietnamese Unicode binary markers: PASS")
obsolete = [
    "Ngôn ngữ Nokia/Symbian",
    "Đồng bộ tiến trình",
    "Tải bản sao lưu (.zip)",
]
for text in obsolete:
    if text.encode("utf-8") in data or text.encode("utf-16le") in data:
        raise SystemExit(f"ERROR: obsolete Vietnamese wording remains in binary: {text}")
    print(f"PASS obsolete removed: {text}")
print("V23 Vietnamese FIXED2 obsolete-wording audit: PASS")
