from pathlib import Path

binary = Path("build-ios-device/src/emu/ios/eka2l1.app/eka2l1")
data = binary.read_bytes()

markers = [
    "NGAGE CLASSIC R1:",
    "Add Mode",
    "Thêm chế độ",
    "Symbian Device…",
    "N-Gage",
    "N-Gage ready",
    "N-Gage mode is ready.",
    "NEM-4",
    "assets/ngage/SYM.ROM",
    "NGAGE CLASSIC R2A FIX3 MULTIIMPORT:",
    "NGAGE CLASSIC R2A FIX4 DISPATCHER:",
    "NGAGE CLASSIC R2A BOOTREADY1:",
    "NGAGE CLASSIC R2A FINAL1:",
    "NGAGE CLASSIC R2B DEVICEPROFILES R1:",
    "NGAGE CLASSIC R2B MULTIFIRMWARE R2:",
    "NGAGE CLASSIC R2FX1 CLEANUP:",
    "NGAGE CLASSIC R2FX2 COMPATIBILITY R2 EXPORTMAP BATCH1:",
    "NGAGE CLASSIC R2FX2 R2 CRASHFIX1:",
    "com.eka2l1.ngage.lifecycle",
    "menu-touch enter gameRunning=",
    "exit bridge-return",
    "device-switch bridge-return",
    "export-map target ordinal=",
    "exact symbol/ABI required before HLE",
    "deferred known import ordinal=",
    "unresolved NEW guest ordinal=",
    "firmware-staging",
    ".r2b-multifirmware-r2",
    "firmware-profiles",
    ".r2b-deviceprofiles-r1",
    "N-Gage is ready.",
    "multiple Classic System/Apps trees",
    "Starting N-Gage…",
    "Choose SIS package",
    "multiple SIS candidates",
    "Installed %@ directly into the current N-Gage firmware.",
    "This is an N-Gage 2.0 package for Symbian OS 9.x.",
    "Password-protected or encrypted RAR archives are not supported.",
]
encodings = ("utf-8", "utf-16le", "utf-16be")

missing = []
for marker in markers:
    found = [enc for enc in encodings if marker.encode(enc) in data]
    if not found:
        missing.append(marker)
        print(f"ERROR: missing Mach-O marker: {marker!r}")
    else:
        print(f"PASS Mach-O: {marker} encoding={','.join(found)}")

if missing:
    raise SystemExit(
        "N-Gage Classic R2B DEVICEPROFILES R1 binary verification failed; "
        f"missing {len(missing)} marker(s)"
    )
