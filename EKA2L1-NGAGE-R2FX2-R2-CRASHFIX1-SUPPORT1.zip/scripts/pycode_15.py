from pathlib import Path
core = Path('upstream/src/emu/cpu/src/dyncom/arm_dyncom.cpp').read_text()
interp = Path('upstream/src/emu/cpu/src/dyncom/arm_dyncom_interpreter.cpp').read_text()

assert interp.count('NumInstrsToExecute.load(std::memory_order_relaxed)') == 4
assert interp.count('NumInstrsToExecute.store(') == 4

remaining = []
for label, source in (('core', core), ('interpreter', interp)):
    for lineno, line in enumerate(source.splitlines(), 1):
        if 'NumInstrsToExecute' not in line:
            continue
        if '.load(' in line or '.store(' in line:
            continue
        remaining.append((label, lineno, line.strip()))
assert not remaining, remaining
print('V19 FIXED1 atomic access audit: PASS (0 direct accesses)')
