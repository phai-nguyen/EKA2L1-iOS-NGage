import base64, gzip, hashlib, pathlib, subprocess
data = (
    'H4sIAAAAAAAC/+1YbW/iRhD+zq/Y3ico2ECAJJAcupfk2lPv1IrcnVRVlbW2x2EbY3O7awiq+O+d2TVgiA1RVZ364VCEs2ZmdnbmmWd3NhRRxB'
    'znXmjG20oGbZhl7VCoOdfB1LzgWShSN5jPmX9CoCaSEB4Z8Og84h3X7fdgCH6fdTud836/5jjOyTlqzWbz9DyvXjFncHnZOmdNelwyfJHwGaBw'
    'AAwe+FncHY02yuzvGiv7iCRCc+lsHoOGOszTYDQCKVPpJWkCjatyrQeQiTPOkjgNHuplQutas9Y8fClBZzJhWmZwoLJu7Y+VlsBnXgJL9x50vU'
    'FT1MLSLEmxAKnaIgniLITt2MSpHaq5Oy2G8rR0nr/Beb930cH8RWGvM4zCivw9w95BMp+hQZntD1oXrInfw4q8Wr1iWlHZ2wQu1SISAdciTbwQ'
    'E8lesq6VXFMoHfovUyK5r9QKeBz7PHhATaXD0SjKkoB+uF6kIqzTF/uxMb6yWW632cQmN+KxAracAuZ5CqxokgU8wTHzgYUQk/sQshVol92Z+d'
    'GbrTWaGZJQsRlfEW7k6qk5/OMs5hokM9FjG5dda+Zfrs9P07iwPlZqKlMgQ645altRiuoGulmgC7KYoqPI3VZ1O1902+hOOYbnkHGeqZJj+DIK'
    'O9AHxHB0OeAX/DiGTxotB/JJNUJzd9glONOjO3g2oA0/Raz+wyyV4En4moHSaBUegylP7qFOTNKy6ZsBCq28VIYgPR58RfG40ShjvSBNlLZKRF'
    '/efcZleG2NZBoex8y8qW8A4hmpMpIj34xrfhZFOO1Wg+Z1ynizVHrPxgZYNGGzzIR1n0BaqKKX/4VlE+qtTVpDqVheoV+6gxH7+PEd1gYo5PSV'
    'p1MTKqpLqlXaIyB22fvoSekeNVzGElLcTzWaWLbwy0/DFVuKODYFz5ZS4M7VYDo9bjYGLtkBkpC18DUSFnmoYpxWpdZbeNSWVU74mpMIUZTAOA'
    'hMDvCQpREijMsF0UaEc+Iy3GpLH379yfs0ef32tn4zef/lduK9/nzTYi8wxOzm7jc2uf00+X2Ec0SbRedz/gUBruKK5QuyK5B2SeGLqjxvgbiL'
    'g9I4rhvuLqun3GSVwXXt1KvCcF3OhgjOhQigyCezWdQOYXHAgccFc+Y76/rRsBe4bnDRGfb8QTnznTC1z3cnhInl8KDQ6l6yJj3Pzspo7pCP8t'
    '3EGUu4F5iJXe3Wn8Y0Z0ikyootrVDtLfaHngr1Z76RbWq/UXUMtMXqqRU6MWM/0pA2RlwzyGtcp4fr9OxwXG84YzyVeblO6hMMvXSZgKSzoFN9'
    'YNwcF0tRZGCXJQIxaXjkes+nsTFhybpu/MuBWmCeo8S2U3fRVeVZX46y3K4s724nX96/vfWQ76g0q1XoY+oWJYeDTeXOY74yJWuXxPxMra6Q3j'
    'BR7I3J16f0DbzD6j5RtrJwyKouxvIUIF19IHomeuMBIhlZm8hOKLbgUnA/hnKLqPgLwNwoIl2goFBTJOV8Mc4YcaIUncgs/RNluOUwe+7eS2iz'
    'Pm53X6eif8HcxlzpzS5XiXA7ve1zPErIXrOTIW3IKE6XVR3PmgEdbI8YD1PkyXkqt64gKn3wIpPVeqXdqnQdtljNI3go6ajKuir6JFkcz7U0DZ'
    'XhrN7AclbvO2d956wCZ0kIsJLp/HKUtG5ncy2+s9Y3YS2bkm/EW2AT+z8krvIDpM3r9l4lH+ZNSPEO6LjgwRHxhPD+EfGEMNHtRa/fGrImPbrn'
    'yLa1UqBbld1vhhBtPA8zaSjCoM19chm3ru2Cj+Z/ThHFG65W1KYhHceOFjPqf/B/um7JlGm9qK6o0LiZ2ifT2+uZ3Nz2jgeXTrcw29LC0iSuoO'
    'bqayaoffNXT5gSGzg93bN3yIzYSxnzN7C4SxHnh/1PoZ8y3TCpbmPULAFbIVQ72QI+6c6ymI7PBsLVCdlA/EhKSm5I17V/AEFRaj5uFgAA'
)
raw = gzip.decompress(base64.b64decode(data))
expected = '3b9f1d42eeaa0f7afe144b817a1220bf02021aa2f3b98485f3f72a27424bb77a'
actual = hashlib.sha256(raw).hexdigest()
if actual != expected:
    raise SystemExit(f'V15 FIXED2 patch SHA256 mismatch: {actual} != {expected}')
patch = pathlib.Path('v14-to-v15-fixed.patch')
patch.write_bytes(raw)
subprocess.run(['git', '-C', 'upstream', 'apply', '--check', str(patch.resolve())], check=True)
subprocess.run(['git', '-C', 'upstream', 'apply', str(patch.resolve())], check=True)
print('Installed V15 FIXED2 bool callback + kernel try_lock + rejected-refill retry')
