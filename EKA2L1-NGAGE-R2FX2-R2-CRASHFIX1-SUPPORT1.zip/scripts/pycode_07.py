import base64, gzip, hashlib, pathlib, subprocess
data = (
    'H4sIABcDlWoC/+1ZXXPaPBa+z6/Q270xxXwYSJqQhm2Skk5m2qZD0867VxrFlsET2+KVZUi3k/3teyTZRjIGmu17ub4IIB8d6TznOR9SOp0OIr'
    '2M+z2a5L2ARyvKs16U+nEe0Oo3yYOI9R6I/0jToBdkS5wtCKdBd3HUbrfRw+8oePcOdQYj9wS14e8b9O7dETpC/ygUoLc+SxKW9nyWChKllHcX'
    'ExBobwSIYEnkT8w5SS7okzWyor5gXM6Uy41G7hlqj45dz1PrlU8mgvE4i/5NsUBkNcchJwnFPstTgc/ltsrngbEYrSIuchLjTLDl+VHHepcwTj'
    'Gnf+U0EzQ4P2pbS+gtv5WSk18TNXY2QTHJBF7zSFCckWQZ02yzuyVnAmylwbimqDArZmu8JoJynBD+WM53WggAzsT5xsTCOm1OlMKMFGwNqM8C'
    '2G6eplE6xywXTmuzdv4QR/74qNPIKfl7Jw385XIHkw5Okw713kj+wF/NH/QakZilc7SOxAKJRZRJXObgzS66DVHKhIsyCrRYCLEc93rr9bo7T/'
    'Mu4/MeWEDTjGa9SVcq6tlkK9hI4jkD/BeJYuPW65jNay8Ox0HJzYHi5sDippQDqJe5ALJxSpJi1ni8641TLAgEkiti/RO9hl+tjY/H25od47WL'
    'QBw7ak7bGKxFhtO35phh4QieU+utzXYnJHEGAp292tFPc/kG9tdkPt59wLefb+6c97Pb79MZvvz23kWvvnsj9P7rFzSb3tx+/DgGRlDCE8SJT1'
    'EYPaE2mstNdR7yMASoYsYeyYKSABFfAHivWkVwPJd03+2V/+x0i9ynIqx3DFxte96pe2qlIPkAi8AssM8ncSy5gp1qKM8oD4gguGUlJBN0dIEk'
    '7EZKskGH9wp2I9XYAl3Qwqn2jauzR0JB5AdmPIDMwWlMnmjQMhQ0OKXQ0t+vwUyqCnjc5TSjRVpRUA37rjcErIYjdzDcAquctcyzhSORcZH6wD'
    'LhgVO9FuqhQcvIbNKBvw7NbssalvlFtF4MNyUQJYYJnIqcp4WbK6Pa9WS/m6H7y4AZTHrA1AoqgjWowaAEAKsHLCRff0HSlMaZ/D46368rDnEG'
    'RSWV2GeCiMgH2mfCqnhOCGBhIwnJ5zXS2RbQIk+2eLW+W/hl7x5U2OMi7C82WqPU1mov38SLmJHA2c0A1zTX5EPhTsMexwTZtbZYTnw+ah9tGo'
    '7drt5bu8HTlUVRiJyQ8YSADy8u0JfrT94Jvrn7NsPX1/j67v1USndMDIp9O2UMSqRA59sL5BxiRcu0f7+uXVytx3RdVRHJuj8ocsjpyPWOix6z'
    'fHo92RSIBUUkkXtFLERlEaChQNA9BJQmkB0EQw8UmqEM3kZ+REHWUd2FII80g0Lhl/P9nHP5WkGA9LBYEKUspTSgZhmWwO/10hbwcsYfdhaxKm'
    'BhFpS8MfJjEiXKvEIWZTET6Gp6czebyl4oCn/ASkpC8ayL7suvyCfpllaSZmvA5kpBdM+u6E0Ux4BO9iP1F5ylLM/iHyAVIBUeMqlAAuOZbsTC'
    'mMy7Wzq/UiHkJiJovENAQu2mLH9ozfI4QAw6GKVRI6mUqmUgbfAV3d5nHEOUSmWchrBFbWvkQ46BHFDbQwOiXfokKTunqotpyszE/0sGd8sKo4'
    'ZEEzOo4fMcQlpnFH0+QWrEqYq8kjJJbe5Nba2IjWpG47pVgalLWzqsPqL+PNtsk8/2yFblNKqREZZW1bUOBrCDFTTbZoufJGEvoKuG48ABYdU5'
    'n53Inkp+eAOrT4CCQhFdMh+gTyABQ5mheBkTyfvxATHB0iZZXWpVogXTq247pWtcpOKyoQ74yt0IqJZfzytOAU1jOAyTJZ23zm3YC6HOBBokDC'
    'eaJeUiglR42u9DmzWop9Rd4qqa0jRPwDgMHw+UO2bpNSBQuRZzAAKqKktD6M4kKK2Way+ll6tV7xyS2qmqx2pmlf+3cn/VsH+dzr7fXk/xp083'
    'smnfXkN18fD27Bh9vZ9NLz/dfr69H6ul6cXPZyRNk5/lWvD91YGtwiYnTkCzCKpl4fMm6/4W0FAdCasB1rVLVQI4nAit12KOVeHR64lTuLg7lx'
    '1zqzNZsThPqKM/ZKH1+lUjPRwMZXwMB+WZ4wDzOVQiHryI9lH6f9bvY33N2VCkZnQeZbJGlSe8quo1gt6Z8GJCldcd5dzjobpCOx713bOac21u'
    'F202hZYqVfdNmzKTRlXzKKCQ5/OFnuOYEP9arBpxCm3Gp0uI0ZDl3Pcv+k8/x/3TP5/R0k+8ExWf0D5xIDDWEjVN1jvZl1ak2m5Q0T+Rh8aoby'
    'OtSnuFn+5wHUvtdgGXVk5ns7tZ3Uz06oZEse4FgWDF9pCqSEjrljcF0iUn2iUno2F5LdXUrCqWSKfoDijrTNRI84kFqDUcYNn7yOazrOXqCHpR'
    '5BZjzL6zNNTkpR4ZE/LM+zeERpllTkba6uNRw80G0GJY0OL67vPN7YcxWsrYFzJnK0UJyR4VR/7cJHOaQksM2JTjRnIvGnWd5u32Szx1JtLF4C'
    'DIhYBWdVx3vCoTqzVdtZLbHMoSp9LUciOyQNR7PTPU3QZf/FYMabCuvt2MC9dL0zMaq5teHUPblNixC3T0S6mysVZZ4JYZy9H0oJwzjlNolwr+'
    'n50pJnj9/kmRk8yIfITjjnaQnI5lSENbDoeFyYWqRDAAOuHL2fFWdELevJdniSQHRj/olAkhqU8OBF3dX93IgxaH6RwAOtrqpv+Isk15q24+t4'
    '5Qpa/uZ5fX08PNSc1pH6b3ymMbhitETcY2qtjH3EFrl1frT8Cw9GohBnH9QHGoDmpOa1+Xro7L/eGJdt2xV4viwjVopc8QkDx2ObLGNDPtZPly'
    'CXQNyszVr//Xo5IszheHBf1Fnj5idfnZP7eZVm71bZ1Yoy1iKZ1sKQ+IJDbSHhwz8GItwcQrbyKTDmaxPPPs8FXIWQKTMp9HS8H4Tk2Qic4b2F'
    'no7y5IhlckzqnmpnbNqIiqE68hwT7XW4w61IXqzsSuE7WrGAv0aoo5Xp9j4F/Jl2O4ZqO6OivWN+XNcfNuB0H6of+LqwbaVdCd/q6rBtpV2gPH'
    'Q/kvGq//ZlBeJr3YBbCll7pATXmBC5T8C1yg5He5oLxdfkFGNDLhl4+X/3p/eX9p5sISFVX5tVXyq9yAPsDpjR9Om4cKvQW/ayHrWji41aK76r'
    'fRU+85lW3O/oDsb53nDA9slHYm+lptS7N5+pC6yvsfZVRnsmDSVDjoOa06KipX/xdBRU04CiAAAA=='
)
raw = gzip.decompress(base64.b64decode(data))
expected = 'c448e066660483afe5a0f4b1c077ed9cb5834e11c71a62f521421faa768fdae8'
actual = hashlib.sha256(raw).hexdigest()
if actual != expected:
    raise SystemExit(f'V14 patch SHA256 mismatch: {actual} != {expected}')
patch = pathlib.Path('v13-to-v14.patch')
patch.write_bytes(raw)
subprocess.run(['git', '-C', 'upstream', 'apply', '--check', str(patch.resolve())], check=True)
subprocess.run(['git', '-C', 'upstream', 'apply', str(patch.resolve())], check=True)
print('Installed V14 DevSound refill starvation/race fix and buffer diagnostics')
