from pathlib import Path

path = Path('upstream/src/emu/services/src/audio/mmf/dev.cpp')
text = path.read_text()
marker = 'V12 MMF95 PRIORITY: opcode=45 dispatch'

if marker in text:
    print('V12 MMF95 opcode 45 fix already present')
else:
    old = '''            case epoc::mmf_dev_newarch_samples_played:\n                samples_played(ctx);\n                break;\n\n            case epoc::mmf_dev_newarch_close:\n'''
    new = '''            case epoc::mmf_dev_newarch_samples_played:\n                samples_played(ctx);\n                break;\n\n            case epoc::mmf_dev_newarch_set_priority_settings:\n                LOG_INFO(SERVICE_MMFAUD, \"V12 MMF95 PRIORITY: opcode=45 dispatch\");\n                set_priority_settings(ctx);\n                break;\n\n            case epoc::mmf_dev_newarch_close:\n'''
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'V12 MMF95 patch anchor count={count}, expected 1')
    path.write_text(text.replace(old, new, 1))
    print('Installed V12 MMF95 opcode 45 priority settings dispatch')
