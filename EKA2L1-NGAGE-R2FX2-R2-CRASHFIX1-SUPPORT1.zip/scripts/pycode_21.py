from pathlib import Path
root = Path('upstream/src/emu/ios/app/RootViewController.mm').read_text()
begin = root.index('// ---- EKA2L1 frontend language')
end = root.index('// ---- Settings (N-Gage)', begin)
block = root[begin:end]
assert 'set_device_language' not in block
assert 'get_device_language' not in block
print('V23 VI18N app language is isolated from Nokia/Symbian firmware language: PASS')
