from pathlib import Path
import re

text = Path('upstream/src/emu/kernel/src/msgqueue.cpp').read_text()
matches = list(re.finditer(
    r'(?m)^[ \t]*bool[ \t]+msg_queue::send[ \t]*\(', text))
assert len(matches) == 1, len(matches)
start = matches[0].start()
p = text.index('msgs_.push(new_data);', start)
n = text.index('for (auto &notify : avail_notifies_)', start)
c = text.index('avail_callback_.first(avail_callback_.second)', start)
m = text.index(
    'V17 MSGQ ORDER: data queued before availability notification',
    start)
assert p < n and p < c and n < m, (p, n, c, m)
print('V17 FIXED3 publish-before-notify structural proof: PASS')
