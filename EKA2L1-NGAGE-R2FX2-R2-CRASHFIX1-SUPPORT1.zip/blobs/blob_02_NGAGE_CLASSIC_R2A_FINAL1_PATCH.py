from pathlib import Path

root = Path("upstream")
launcher = root / "src/emu/ios/src/launcher.cpp"
rootvc = root / "src/emu/ios/app/RootViewController.mm"
loc = root / "src/emu/ios/app/EKALocalization.mm"

for p in (launcher, rootvc, loc):
    if not p.is_file():
        raise SystemExit(f"FINAL1: missing source file: {p}")

lt = launcher.read_text(encoding="utf-8")
rt = rootvc.read_text(encoding="utf-8")
lc = loc.read_text(encoding="utf-8")

if "NGAGE CLASSIC R2A FIX4 DISPATCHER:" not in lt:
    raise SystemExit("FINAL1 requires FIX4 DISPATCHER baseline")
if "NGAGE CLASSIC R2A BOOTREADY1:" not in rt:
    raise SystemExit("FINAL1 requires BOOTREADY1 baseline")
if "NGAGE CLASSIC R2A FINAL1:" in lt or "NGAGE CLASSIC R2A FINAL1:" in rt:
    raise SystemExit("FINAL1 already installed")

old_poll = r'''- (void)pollForAppsWithAttemptsLeft:(int)attempts {
    if (self.gameRunning) return;
    std::vector<eka2l1::ios::bridge::app_entry> apps = eka2l1::ios::bridge::get_apps();
    if (!apps.empty()) {
        NSArray<NSString *> *args = [[NSProcessInfo processInfo] arguments];
        NSUInteger luidIdx = [args indexOfObject:@"--launchuid"];
        if (luidIdx != NSNotFound && luidIdx + 1 < args.count) {
            // Automation hook: launch a specific app by UID3 (hex, e.g. 0x20007B39 = Games).
            std::uint32_t target = (std::uint32_t)strtoul([args[luidIdx + 1] UTF8String], nullptr, 16);
            [self launchAppUid:target];
        } else if ([args containsObject:@"--launchfirst"]) {
            [self launchAppUid:apps[0].uid];
        } else if ([args containsObject:@"--gamesettings"]) {
            // Automation hook (like --launchfirst): open the first app's per-game settings.
            [self showAppsScreen];
            [self openGameSettingsForUid:apps[0].uid
                                    name:[NSString stringWithUTF8String:apps[0].name.c_str()]];
        } else if ([args containsObject:@"--sync"]) {
            [self showAppsScreen];
            [self openProgressSync];
        } else if ([args containsObject:@"--packages"]) {
            [self showAppsScreen];
            [self openPackages];
        } else if ([args containsObject:@"--hiddenapps"]) {
            // Automation hook: open Devices → Hidden Apps.
            [self showAppsScreen];
            [self openHiddenApps];
        } else if ([args containsObject:@"--hidefirstapp"]) {
            // Automation hook: hide the first app, then show the (filtered) home screen.
            [HiddenAppsViewController setUid:apps[0].uid hidden:YES];
            [self showAppsScreen];
        } else if ([args containsObject:@"--keybinds"]) {
            [self showAppsScreen];
            [self openGlobalKeybinds];
        } else if ([args containsObject:@"--layouteditor"]) {
            [self showAppsScreen];
            [self openLayoutEditorForUid:apps[0].uid
                                    name:[NSString stringWithUTF8String:apps[0].name.c_str()]];
        } else {
            [self showAppsScreen];
        }
        return;
    }
    if (attempts <= 0) {
        self.statusLabel.hidden = NO;
        self.statusLabel.text = EKAL(@"Device booted, but no apps were found.\nTap “Apps” to retry or install a game.");
        return;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self pollForAppsWithAttemptsLeft:attempts - 1];
    });
}'''

new_poll = r'''- (void)pollForAppsWithAttemptsLeft:(int)attempts {
    if (self.gameRunning) return;
    std::vector<eka2l1::ios::bridge::app_entry> apps = eka2l1::ios::bridge::get_apps();
    if (!apps.empty()) {
        NSArray<NSString *> *args = [[NSProcessInfo processInfo] arguments];
        NSUInteger luidIdx = [args indexOfObject:@"--launchuid"];
        if (luidIdx != NSNotFound && luidIdx + 1 < args.count) {
            std::uint32_t target = (std::uint32_t)strtoul([args[luidIdx + 1] UTF8String], nullptr, 16);
            [self launchAppUid:target];
        } else if ([args containsObject:@"--launchfirst"]) {
            [self launchAppUid:apps[0].uid];
        } else if ([args containsObject:@"--gamesettings"]) {
            [self showAppsScreen];
            [self openGameSettingsForUid:apps[0].uid
                                    name:[NSString stringWithUTF8String:apps[0].name.c_str()]];
        } else if ([args containsObject:@"--sync"]) {
            [self showAppsScreen];
            [self openProgressSync];
        } else if ([args containsObject:@"--packages"]) {
            [self showAppsScreen];
            [self openPackages];
        } else if ([args containsObject:@"--hiddenapps"]) {
            [self showAppsScreen];
            [self openHiddenApps];
        } else if ([args containsObject:@"--hidefirstapp"]) {
            [HiddenAppsViewController setUid:apps[0].uid hidden:YES];
            [self showAppsScreen];
        } else if ([args containsObject:@"--keybinds"]) {
            [self showAppsScreen];
            [self openGlobalKeybinds];
        } else if ([args containsObject:@"--layouteditor"]) {
            [self showAppsScreen];
            [self openLayoutEditorForUid:apps[0].uid
                                    name:[NSString stringWithUTF8String:apps[0].name.c_str()]];
        } else {
            [self showAppsScreen];
        }
        return;
    }

    // NGAGE CLASSIC R2A FINAL1: zero apps is not a boot failure. Show the
    // current device immediately while AppArc polling continues unobtrusively.
    if (attempts == 20 || attempts <= 0) {
        [self showAppsScreen];
    }
    if (attempts <= 0) {
        return;
    }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self pollForAppsWithAttemptsLeft:attempts - 1];
    });
}'''

if rt.count(old_poll) != 1:
    raise SystemExit(f"FINAL1: pollForApps anchor count={rt.count(old_poll)}")
rt = rt.replace(old_poll, new_poll, 1)

old_empty = r'''    if (list.count == 0) {
        self.statusLabel.text = (hidden.count > 0)
            ? EKAL(@"All apps are hidden.\nTap “Devices” → “Hidden Apps” to unhide one.")
            : EKAL(@"No apps found yet.\nTap “Apps” to refresh, or install a game.");
    }'''

new_empty = r'''    if (list.count == 0) {
        if (hidden.count > 0) {
            self.statusLabel.text = EKAL(@"All apps are hidden.\nTap “Devices” → “Hidden Apps” to unhide one.");
        } else if (EKAIsCurrentDeviceNEM4()) {
            self.statusLabel.text = EKAL(@"N-Gage is ready.\nNo games installed yet.\nTap “Install Game” to add one.");
        } else {
            self.statusLabel.text = EKAL(@"No apps found yet.\nTap “Apps” to refresh, or install a game.");
        }
    }'''

if rt.count(old_empty) != 1:
    raise SystemExit(f"FINAL1: empty state anchor count={rt.count(old_empty)}")
rt = rt.replace(old_empty, new_empty, 1)

old_name = r'''    [self beginProgress:EKAL(@"Importing N-Gage game…")];
    [self climbProgressToward:0.95f];   // the copy is quick; the reboot afterwards is the wait
    std::string src = [path UTF8String];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        std::string name;
        int result = eka2l1::ios::bridge::install_ngage_file(src, name);   // copies + reboots
        NSString *fileName = name.empty() ? @"The game file" : [NSString stringWithUTF8String:name.c_str()];'''

new_name = r'''    [self beginProgress:EKAL(@"Importing N-Gage game…")];
    [self climbProgressToward:0.95f];
    std::string src = [path UTF8String];
    NSString *selectedName = path.lastPathComponent.stringByDeletingPathExtension;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        std::string name;
        int result = eka2l1::ios::bridge::install_ngage_file(src, name);
        NSString *fileName = name.empty()
            ? (selectedName.length ? selectedName : EKAL(@"N-Gage game"))
            : [NSString stringWithUTF8String:name.c_str()];'''

if rt.count(old_name) != 1:
    raise SystemExit(f"FINAL1: import success-name anchor count={rt.count(old_name)}")
rt = rt.replace(old_name, new_name, 1)

scan_start = lt.find("            auto contains_system_apps = [](const std::filesystem::path &candidate) -> bool {")
scan_end = lt.find("\n            if (root_found) {", scan_start)
if scan_start < 0 or scan_end < 0:
    raise SystemExit("FINAL1: FIX4 root-scan block not found")

new_scan = r'''            auto system_has_apps = [](const std::filesystem::path &system_dir) -> bool {
                std::error_code ec;
                for (const auto &entry : std::filesystem::directory_iterator(system_dir,
                        std::filesystem::directory_options::skip_permission_denied, ec)) {
                    if (ec) return false;
                    if (!entry.is_directory(ec)) continue;
                    if (common::compare_ignore_case(
                            entry.path().filename().string().c_str(), "apps") == 0) {
                        return true;
                    }
                }
                return false;
            };

            std::vector<std::filesystem::path> candidate_roots;
            std::error_code scan_ec;
            std::size_t scanned_entries = 0;
            bool scan_limit_hit = false;

            std::filesystem::recursive_directory_iterator scan_it(
                temp_root, std::filesystem::directory_options::skip_permission_denied, scan_ec);
            const std::filesystem::recursive_directory_iterator scan_end_it;

            for (; !scan_ec && scan_it != scan_end_it; scan_it.increment(scan_ec)) {
                if (++scanned_entries > 20000) {
                    scan_limit_hit = true;
                    break;
                }

                std::error_code entry_ec;
                if (!scan_it->is_directory(entry_ec)) {
                    continue;
                }

                const int depth = scan_it.depth();
                const std::string dirname = scan_it->path().filename().string();
                if (common::compare_ignore_case(dirname.c_str(), "system") == 0 &&
                    system_has_apps(scan_it->path())) {
                    const std::filesystem::path candidate = scan_it->path().parent_path();
                    bool duplicate = false;
                    for (const auto &existing : candidate_roots) {
                        if (existing == candidate) {
                            duplicate = true;
                            break;
                        }
                    }
                    if (!duplicate) {
                        candidate_roots.push_back(candidate);
                    }
                }

                if (depth >= 8) {
                    scan_it.disable_recursion_pending();
                }
            }

            if (scan_ec || scan_limit_hit) {
                common::delete_folder(temp_root);
                LOG_ERROR(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FINAL1: archive tree scan failed/limited package='{}'",
                    src_path);
                return 109;
            }

            if (candidate_roots.size() > 1) {
                common::delete_folder(temp_root);
                LOG_INFO(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FINAL1: multiple Classic System/Apps trees={} package='{}'",
                    candidate_roots.size(), src_path);
                return 115;
            }

            const bool root_found = candidate_roots.size() == 1;
            std::filesystem::path game_root =
                root_found ? candidate_roots.front() : std::filesystem::path(temp_root);'''

lt = lt[:scan_start] + new_scan + lt[scan_end:]

old_canon = r'''                auto canonical_component = [](const std::string &name) -> std::string {
                    if (common::compare_ignore_case(name.c_str(), "system") == 0) return "system";
                    if (common::compare_ignore_case(name.c_str(), "apps") == 0) return "apps";
                    if (common::compare_ignore_case(name.c_str(), "libs") == 0) return "libs";
                    if (common::compare_ignore_case(name.c_str(), "programs") == 0) return "programs";
                    return name;
                };'''

new_canon = r'''                auto canonical_component = [](const std::string &name) -> std::string {
                    // Symbian's filesystem is case-insensitive. Canonicalize every path
                    // component so app folder "6R53" and registration "6R53.AIF"
                    // become the matching pair "6r53/6r53.aif" before core validation.
                    return common::lowercase_string(name);
                };'''

if lt.count(old_canon) != 1:
    raise SystemExit(f"FINAL1: canonical component anchor count={lt.count(old_canon)}")
lt = lt.replace(old_canon, new_canon, 1)

old_log = r'''                LOG_INFO(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FIX4 DISPATCHER: card result={} game='{}' package='{}' type={}",
                    classic_result, out_name, src_path, rar_signature ? "RAR" : "ZIP");'''

new_log = r'''                LOG_INFO(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FIX4 DISPATCHER: card result={} game='{}' package='{}' type={}",
                    classic_result, out_name, src_path, rar_signature ? "RAR" : "ZIP");
                LOG_INFO(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FINAL1: canonical card result={} root='{}' package='{}'",
                    classic_result, game_root.string(), src_path);'''

if lt.count(old_log) != 1:
    raise SystemExit(f"FINAL1: card result log anchor count={lt.count(old_log)}")
lt = lt.replace(old_log, new_log, 1)

old_range = "} else if ((result >= 101) && (result <= 114)) {"
if rt.count(old_range) != 1:
    raise SystemExit(f"FINAL1: result range anchor count={rt.count(old_range)}")
rt = rt.replace(old_range, "} else if ((result >= 101) && (result <= 115)) {", 1)

msg_anchor = r'''                } else if (result == 114) {
                    msg = EKAL(@"The archive was extracted, but it contains neither a Classic System/Apps tree nor a compatible Symbian 6.1 SIS package.");
                } else {
                    msg = EKAL(@"The N-Gage game archive could not be extracted.");
                }'''

msg_new = r'''                } else if (result == 114) {
                    msg = EKAL(@"The archive was extracted, but it contains neither a Classic System/Apps tree nor a compatible Symbian 6.1 SIS package.");
                } else if (result == 115) {
                    msg = EKAL(@"The archive contains more than one Classic System/Apps game tree. Keep one game tree per archive and try again.");
                } else {
                    msg = EKAL(@"The N-Gage game archive could not be extracted.");
                }'''

if rt.count(msg_anchor) != 1:
    raise SystemExit(f"FINAL1: result message anchor count={rt.count(msg_anchor)}")
rt = rt.replace(msg_anchor, msg_new, 1)

loc_anchor = '        @"The selected device did not reach the running state." : @"Thiết bị đã chọn chưa đạt trạng thái hoạt động.",'
if lc.count(loc_anchor) != 1:
    raise SystemExit(f"FINAL1: localization anchor count={lc.count(loc_anchor)}")

loc_extra = r'''
        @"N-Gage is ready.\nNo games installed yet.\nTap “Install Game” to add one." : @"N-Gage đã sẵn sàng.\nChưa cài trò chơi nào.\nChạm “Cài đặt trò chơi” để thêm game.",
        @"N-Gage game" : @"Trò chơi N-Gage",
        @"The archive contains more than one Classic System/Apps game tree. Keep one game tree per archive and try again." : @"Tệp nén chứa nhiều hơn một cây game Classic System/Apps. Hãy chỉ giữ một cây game trong mỗi tệp nén rồi thử lại.",'''
lc = lc.replace(loc_anchor, loc_anchor + loc_extra, 1)

for token in (
    "NGAGE CLASSIC R2A FINAL1:",
    "candidate_roots",
    "scanned_entries > 20000",
    "depth >= 8",
    "return 115;",
    "return common::lowercase_string(name);",
):
    if token not in lt:
        raise SystemExit("FINAL1 launcher audit missing: " + token)

for token in (
    "zero apps is not a boot failure",
    "N-Gage is ready.",
    "selectedName",
    "result <= 115",
):
    if token not in rt:
        raise SystemExit("FINAL1 UI audit missing: " + token)

if "if (s.progressValue >= target)" not in rt:
    raise SystemExit("FINAL1: BOOTREADY1 monotonic progress guard missing")
if "bridge::is_running()" not in rt or "bridge::has_device()" not in rt:
    raise SystemExit("FINAL1: BOOTREADY1 running-state guards missing")
if "Choose SIS package" not in rt or "MULTISIS" not in lt:
    raise SystemExit("FINAL1: FIX4 SIS dispatcher missing")
if "RAROpenArchiveEx" not in lt:
    raise SystemExit("FINAL1: FIX3 UnRAR path missing")

launcher.write_text(lt, encoding="utf-8")
rootvc.write_text(rt, encoding="utf-8")
loc.write_text(lc, encoding="utf-8")

print("NGAGE CLASSIC R2A FINAL1 patch: PASS")
print("Empty-device startup UX: PASS")
print("N-Gage empty-state wording: PASS")
print("Import success filename fallback: PASS")
print("Recursive System/Apps discovery depth<=8: PASS")
print("RAR/ZIP canonical filename casing: PASS")
print("Ambiguous multi-tree rejection: PASS")
print("BOOTREADY1 + FIX4 regression guards: PASS")
