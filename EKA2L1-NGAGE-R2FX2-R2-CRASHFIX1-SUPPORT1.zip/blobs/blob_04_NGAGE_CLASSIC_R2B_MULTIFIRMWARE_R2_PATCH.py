from pathlib import Path
root=Path('upstream')
paths={
'devh':root/'src/emu/system/include/system/devices.h',
'devc':root/'src/emu/system/src/devices.cpp',
'launchh':root/'src/emu/ios/include/ios/launcher.h',
'launch':root/'src/emu/ios/src/launcher.cpp',
'bridgeh':root/'src/emu/ios/include/ios/emu_bridge.h',
'bridge':root/'src/emu/ios/src/emu_bridge.mm',
'rootvc':root/'src/emu/ios/app/RootViewController.mm',
'rpkg':root/'src/emu/system/src/installation/rpkg.cpp',
'fw':root/'src/emu/system/src/installation/firmware.cpp',
}
for p in paths.values():
    if not p.is_file(): raise SystemExit(f'R2B R2: missing {p}')
t={k:p.read_text(encoding='utf-8') for k,p in paths.items()}
MARK='NGAGE CLASSIC R2B MULTIFIRMWARE R2:'
if any(MARK in v for v in t.values()): raise SystemExit('R2B R2 already installed')
if 'NGAGE CLASSIC R2B DEVICEPROFILES R1:' not in t['devc'] or 'NGAGE CLASSIC R2A FINAL1:' not in t['launch']:
    raise SystemExit('R2B R2 requires frozen R2B R1 + R2A FINAL1 baseline')

def rep(k,old,new,count=1):
    c=t[k].count(old)
    if c!=count: raise SystemExit(f'R2B R2 anchor {k} count={c} expected={count}: {old[:80]!r}')
    t[k]=t[k].replace(old,new,count)

# device metadata + profile-aware APIs
rep('devc','#include <algorithm>\n#include <fstream>','#include <algorithm>\n#include <array>\n#include <fstream>')

rep('devh','''        std::string profile_id;\n        std::string rom_fingerprint;\n        std::string manufacturer;''','''        std::string profile_id;\n        std::string rom_fingerprint;\n        // NGAGE CLASSIC R2B MULTIFIRMWARE R2: firmware revision is metadata, not identity.\n        std::string firmware_version;\n        std::string manufacturer;''')
rep('devh','''        // Recompute profile_id once the installed ROM is present on disk.\n        void refresh_profile_identity(device *dvc);''','''        // Recompute profile_id once the installed ROM is present on disk.\n        void refresh_profile_identity(device *dvc);\n        // Finalize one freshly-installed firmware from an isolated staging root.\n        bool finalize_staged_profile(device *dvc, const std::string &staging_root);\n        // Reload language/version metadata from this profile's private Z:.\n        void refresh_profile_runtime_metadata(device *dvc);''')
rep('devh','''        bool delete_device(const std::string &firmcode);''','''        // R2: identity is profile_id. A firmware code is accepted only when unique.\n        bool delete_device(const std::string &profile_or_unique_firmcode);''')
rep('devh','''        device *get(const std::string &firmcode);''','''        device *get(const std::string &profile_or_unique_firmcode);''')

# include chrono in launcher
rep('launch','#include <array>\n#include <cstring>','#include <array>\n#include <chrono>\n#include <cstring>')

# helpers in devices.cpp before legacy rom helper
anchor='''    static std::string r2b_legacy_rom_path(config::state *conf, const std::string &firmcode) {'''
helpers=r'''    // NGAGE CLASSIC R2B MULTIFIRMWARE R2: sanitize version text for a path component.
    static std::string r2b_version_component(std::string value) {
        value = common::lowercase_string(value);
        std::string out;
        bool sep = false;
        for (unsigned char c : value) {
            const bool ok = ((c >= 'a') && (c <= 'z')) || ((c >= '0') && (c <= '9')) || c == '.';
            if (ok) { out.push_back(static_cast<char>(c)); sep = false; }
            else if (!sep && !out.empty()) { out.push_back('-'); sep = true; }
        }
        while (!out.empty() && (out.back() == '-' || out.back() == '.')) out.pop_back();
        return out.empty() ? std::string("unknown") : out;
    }

    static std::string r2b_read_firmware_version(const std::string &z_product_root) {
        const std::array<std::string, 4> candidates = {
            add_path(z_product_root, "resource/versions/sw.txt"),
            add_path(z_product_root, "system/versions/sw.txt"),
            add_path(z_product_root, "resource\\versions\\sw.txt"),
            add_path(z_product_root, "system\\versions\\sw.txt")
        };
        for (const auto &path : candidates) {
            common::dynamic_ifile f(path);
            if (f.fail()) continue;
            std::string line;
            f.set_ucs2(0);
            f.getline(line);
            if (line.empty()) continue;
            for (char &c : line) if (c == '\r' || c == '\n' || c == '\t') c = ' ';
            while (!line.empty() && line.back() == ' ') line.pop_back();
            std::size_t start = line.find_first_not_of(' ');
            if (start != std::string::npos) line.erase(0, start);
            if (!line.empty()) return line;
        }
        return {};
    }

    static std::string r2b_profile_id_v2(const device &dvc) {
        return r2b_profile_component(dvc.firmware_code) + "__" +
            r2b_version_component(dvc.firmware_version) + "__" + dvc.rom_fingerprint;
    }

'''
if t['devc'].count(anchor)!=1: raise SystemExit('R2B R2 helper anchor invalid')
t['devc']=t['devc'].replace(anchor,helpers+anchor,1)

# profile marker accepts R2
rep('devc','''        const std::string marker = add_path(root, ".r2b-deviceprofiles-r1");\n        if (common::exists(marker)) {\n            return true;\n        }''','''        const std::string marker = add_path(root, ".r2b-deviceprofiles-r1");\n        const std::string marker_r2 = add_path(root, ".r2b-multifirmware-r2");\n        if (common::exists(marker) || common::exists(marker_r2)) {\n            return true;\n        }''')
# metadata save/load firmware-version
rep('devc','''        meta << YAML::Key << "rom-fingerprint" << YAML::Value << dvc.rom_fingerprint;\n        meta << YAML::Key << "model"''','''        meta << YAML::Key << "rom-fingerprint" << YAML::Value << dvc.rom_fingerprint;\n        meta << YAML::Key << "firmware-version" << YAML::Value << dvc.firmware_version;\n        meta << YAML::Key << "model"''')
rep('devc','''            emitter << YAML::Key << "rom-fingerprint" << YAML::Value << device.rom_fingerprint;\n            emitter << YAML::Key << "model"''','''            emitter << YAML::Key << "rom-fingerprint" << YAML::Value << device.rom_fingerprint;\n            emitter << YAML::Key << "firmware-version" << YAML::Value << device.firmware_version;\n            emitter << YAML::Key << "model"''')
# load uses latest, avoids duplicate ambiguity
rep('devc','''            if (device *added = get(firmcode)) {\n                added->language = chosen_language;''','''            // R2: add_new_device appends exactly one entry. Never resolve by product code here,\n            // because two revisions of the same product are now valid.\n            if (device *added = lastest()) {\n                added->language = chosen_language;''')
rep('devc','''                try {\n                    added->rom_fingerprint = device_node.second["rom-fingerprint"].as<std::string>();\n                } catch (YAML::Exception exception) {\n                }\n\n                // Older FINAL1 registries''','''                try {\n                    added->rom_fingerprint = device_node.second["rom-fingerprint"].as<std::string>();\n                } catch (YAML::Exception exception) {\n                }\n                try {\n                    added->firmware_version = device_node.second["firmware-version"].as<std::string>();\n                } catch (YAML::Exception exception) {\n                }\n\n                // Older FINAL1 registries''')
rep('devc','''                if (added->profile_id.empty() || added->rom_fingerprint.empty()) {\n                    refresh_profile_identity(added);\n                }''','''                if (added->profile_id.empty() || added->rom_fingerprint.empty()) {\n                    refresh_profile_identity(added);\n                }\n                refresh_profile_runtime_metadata(added);''')

# replace refresh implementation and add finalizer/runtime metadata
start=t['devc'].index('    void device_manager::refresh_profile_identity(device *dvc) {')
end=t['devc'].index('    device_manager::device_manager(config::state *conf)',start)
new_block=r'''    void device_manager::refresh_profile_runtime_metadata(device *dvc) {
        if (!dvc || dvc->profile_id.empty()) return;
        const std::string root = device_profile_root(conf, *dvc);
        const std::string firm_low = common::lowercase_string(dvc->firmware_code);
        const std::string z_product = add_path(root, add_path("drives/z", firm_low));
        if (dvc->firmware_version.empty()) {
            dvc->firmware_version = r2b_read_firmware_version(z_product);
        }
        const std::string lang_rel = (dvc->ver < epocver::eka2)
            ? "system/bootdata/languages.txt" : "resource/bootdata/languages.txt";
        common::dynamic_ifile ifile(add_path(z_product, lang_rel));
        if (!ifile.fail()) {
            std::vector<int> languages;
            int default_language = -1;
            ifile.set_ucs2(0);
            std::string line;
            while (ifile.getline(line)) {
                if (line.empty() || line[0] == '\0') break;
                if (line == "\r" || line == "\n" || line == "\r\n") continue;
                try {
                    const int code = std::stoi(line);
                    if (line.find_first_of(",d") != std::string::npos) default_language = code;
                    languages.push_back(code);
                } catch (...) {}
            }
            if (!languages.empty()) {
                dvc->languages = languages;
                dvc->default_language_code = (default_language == -1) ? languages[0] : default_language;
            }
        }
        LOG_INFO(SYSTEM, "NGAGE CLASSIC R2B MULTIFIRMWARE R2: metadata profile={} product={} version={}",
            dvc->profile_id, dvc->firmware_code, dvc->firmware_version);
    }

    void device_manager::refresh_profile_identity(device *dvc) {
        if (!dvc) return;
        // R1 migration path: preserve an existing profile id so upgrades are non-destructive.
        const std::string fingerprint = r2b_rom_fingerprint(r2b_legacy_rom_path(conf, dvc->firmware_code));
        if (!fingerprint.empty()) {
            dvc->rom_fingerprint = fingerprint;
            if (dvc->profile_id.empty()) {
                dvc->profile_id = r2b_profile_component(dvc->firmware_code) + "__" + fingerprint;
            }
        } else if (dvc->profile_id.empty()) {
            dvc->profile_id = r2b_profile_component(dvc->firmware_code) + "__pending";
        }
    }

    bool device_manager::finalize_staged_profile(device *dvc, const std::string &staging_root) {
        if (!dvc || staging_root.empty()) return false;
        const std::string firm_low = common::lowercase_string(dvc->firmware_code);
        const std::string staged_rom = add_path(staging_root, add_path("roms", add_path(firm_low, "SYM.ROM")));
        const std::string fp = r2b_rom_fingerprint(staged_rom);
        if (fp.empty()) {
            LOG_ERROR(SYSTEM, "NGAGE CLASSIC R2B MULTIFIRMWARE R2: staged ROM fingerprint failed product={}", dvc->firmware_code);
            return false;
        }
        dvc->rom_fingerprint = fp;
        dvc->firmware_version = r2b_read_firmware_version(add_path(staging_root, add_path("drives/z", firm_low)));
        dvc->profile_id = r2b_profile_id_v2(*dvc);
        const std::string root = device_profile_root(conf, *dvc);
        if (common::exists(root)) {
            LOG_ERROR(SYSTEM, "NGAGE CLASSIC R2B MULTIFIRMWARE R2: exact profile already installed id={}", dvc->profile_id);
            return false;
        }
        common::create_directories(root);
        const bool c_ok = r2b_copy_tree_if_present(add_path(staging_root, "drives/c"), add_path(root, "drives/c"));
        const bool e_ok = r2b_copy_tree_if_present(add_path(staging_root, "drives/e"), add_path(root, "drives/e"));
        const bool z_ok = r2b_copy_tree_if_present(add_path(staging_root, "drives/z"), add_path(root, "drives/z"));
        const bool r_ok = r2b_copy_tree_if_present(add_path(staging_root, "roms"), add_path(root, "roms"));
        if (!c_ok || !e_ok || !z_ok || !r_ok) {
            common::delete_folder(root);
            return false;
        }
        std::ofstream marker(add_path(root, ".r2b-multifirmware-r2"), std::ios::binary | std::ios::trunc);
        marker << "R2B MULTIFIRMWARE R2\nprofile=" << dvc->profile_id << "\nproduct=" << dvc->firmware_code
               << "\nversion=" << dvc->firmware_version << "\nrom-fingerprint=" << dvc->rom_fingerprint << "\n";
        marker.close();
        // R1 runtime checks remain valid for an R2-created profile.
        std::ofstream marker_r1(add_path(root, ".r2b-deviceprofiles-r1"), std::ios::binary | std::ios::trunc);
        marker_r1 << "R2B DEVICEPROFILES R1 compatible\n";
        marker_r1.close();
        refresh_profile_runtime_metadata(dvc);
        LOG_INFO(SYSTEM, "NGAGE CLASSIC R2B MULTIFIRMWARE R2: finalized profile={} product={} version={} fingerprint={}",
            dvc->profile_id, dvc->firmware_code, dvc->firmware_version, dvc->rom_fingerprint);
        return true;
    }

'''
t['devc']=t['devc'][:start]+new_block+t['devc'][end:]

# get/set/delete semantics profile-first and duplicate safe
start=t['devc'].index('    device *device_manager::get(const std::string &firmcode) {')
end=t['devc'].index('    device *device_manager::get(const std::uint8_t index)',start)
t['devc']=t['devc'][:start]+r'''    device *device_manager::get(const std::string &profile_or_unique_firmcode) {
        auto profile = std::find_if(devices.begin(), devices.end(), [&](const device &dvc) {
            return dvc.profile_id == profile_or_unique_firmcode;
        });
        if (profile != devices.end()) return &(*profile);
        device *match = nullptr;
        for (auto &dvc : devices) {
            if (dvc.firmware_code == profile_or_unique_firmcode) {
                if (match) {
                    LOG_WARN(SYSTEM, "NGAGE CLASSIC R2B MULTIFIRMWARE R2: ambiguous product lookup {}", profile_or_unique_firmcode);
                    return nullptr;
                }
                match = &dvc;
            }
        }
        return match;
    }

'''+t['devc'][end:]
start=t['devc'].index('    bool device_manager::set_current(const std::string &firmcode) {')
end=t['devc'].index('    bool device_manager::set_current(const std::uint8_t idx)',start)
t['devc']=t['devc'][:start]+r'''    bool device_manager::set_current(const std::string &profile_or_unique_firmcode) {
        const std::lock_guard<std::mutex> guard(lock);
        int found = -1;
        for (std::size_t i = 0; i < devices.size(); ++i) {
            if (devices[i].profile_id == profile_or_unique_firmcode) { found = static_cast<int>(i); break; }
        }
        if (found < 0) {
            for (std::size_t i = 0; i < devices.size(); ++i) {
                if (devices[i].firmware_code == profile_or_unique_firmcode) {
                    if (found >= 0) return false;
                    found = static_cast<int>(i);
                }
            }
        }
        if (found < 0) return false;
        current_index = found;
        return true;
    }

'''+t['devc'][end:]
# remove add_new_device duplicate guard + make language lookup best-effort only (finalizer corrects it)
rep('devc','''        if (get(firmcode)) {\n            LOG_ERROR(SYSTEM, "Device already installed ({})!", firmcode);\n            return add_device_existed;\n        }\n\n''','''        // R2: duplicate product codes are valid; exact duplicate revision is rejected\n        // only after ROM fingerprinting in finalize_staged_profile().\n''')
# replace delete function
start=t['devc'].index('    bool device_manager::delete_device(const std::string &firmcode) {')
end=t['devc'].index('\n}\n',start)
t['devc']=t['devc'][:start]+r'''    bool device_manager::delete_device(const std::string &profile_or_unique_firmcode) {
        const std::lock_guard<std::mutex> guard(lock);
        auto result = std::find_if(devices.begin(), devices.end(), [&](const device &dvc) {
            return dvc.profile_id == profile_or_unique_firmcode;
        });
        if (result == devices.end()) {
            device *unique = get(profile_or_unique_firmcode);
            if (!unique) return false;
            result = std::find_if(devices.begin(), devices.end(), [&](const device &dvc) { return &dvc == unique; });
        }
        const std::string root = device_profile_root(conf, *result);
        const auto removed_index = std::distance(devices.begin(), result);
        if (current_index > removed_index) current_index--;
        devices.erase(result);
        save_devices();
        if (!root.empty() && common::exists(root)) common::delete_folder(root);
        if (current_index >= static_cast<std::int32_t>(devices.size())) current_index = static_cast<std::int32_t>(devices.size()) - 1;
        LOG_INFO(SYSTEM, "NGAGE CLASSIC R2B MULTIFIRMWARE R2: deleted profile={} root={}", profile_or_unique_firmcode, root);
        return true;
    }
'''+t['devc'][end:]

# Core installers: isolated staging makes product path collisions impossible, so remove product duplicate guards.
for k in ('rpkg','fw'):
    block='''        if (dvcmngr->get(firmcode)) {\n            LOG_ERROR(SYSTEM, "The device already exists, revert all changes");'''
    if block in t[k]:
        # remove whole if by targeted known forms below
        pass
rep('rpkg','''        if (dvcmngr->get(firmcode)) {\n            LOG_ERROR(SYSTEM, "The device already exists, revert all changes");\n            eka2l1::common::delete_folder(temp_z_path);\n\n            return device_installation_already_exist;\n        }\n\n''','''        // NGAGE CLASSIC R2B MULTIFIRMWARE R2: duplicate product code allowed.\n''')
rep('rpkg','''        if (dvcmngr->get(firmcode)) {\n            LOG_ERROR(SYSTEM, "The device already exists, revert all changes");\n            common::delete_folder(folder_extracted);\n\n            return device_installation_already_exist;\n        }\n\n''','''        // NGAGE CLASSIC R2B MULTIFIRMWARE R2: duplicate product code allowed.\n''')
rep('fw','''        if (dvcmngr->get(firmcode)) {\n            LOG_ERROR(SYSTEM, "The device already exists, revert all changes");\n            eka2l1::common::delete_folder(drives_z_temp_path);\n            eka2l1::common::remove(current_temp_rom);\n\n            return device_installation_already_exist;\n        }\n\n''','''        // NGAGE CLASSIC R2B MULTIFIRMWARE R2: duplicate product code allowed.\n''')

# launcher install: use isolated staging and finalize profile
old='''        std::string root_c_path = add_path(conf->storage, "drives/c/");\n        std::string root_e_path = add_path(conf->storage, "drives/e/");\n        std::string root_z_path = add_path(conf->storage, "drives/z/");\n        std::string rom_resident_path = add_path(conf->storage, "roms/");\n\n        eka2l1::common::create_directories(rom_resident_path);'''
new='''        // NGAGE CLASSIC R2B MULTIFIRMWARE R2: every firmware install gets a private staging root.\n        // The core installer may still organize files by product code inside this root; because the\n        // root is unique, two RM-596 revisions cannot overwrite each other.\n        const auto install_nonce = std::chrono::steady_clock::now().time_since_epoch().count();\n        const std::string staging_root = add_path(conf->storage,\n            add_path("firmware-staging", "install-" + std::to_string(install_nonce)));\n        std::string root_c_path = add_path(staging_root, "drives/c/");\n        std::string root_e_path = add_path(staging_root, "drives/e/");\n        std::string root_z_path = add_path(staging_root, "drives/z/");\n        std::string rom_resident_path = add_path(staging_root, "roms/");\n        eka2l1::common::create_directories(root_c_path);\n        eka2l1::common::create_directories(root_e_path);\n        eka2l1::common::create_directories(root_z_path);\n        eka2l1::common::create_directories(rom_resident_path);\n        LOG_INFO(FRONTEND_CMDLINE, "NGAGE CLASSIC R2B MULTIFIRMWARE R2: install staging={}", staging_root);'''
rep('launch',old,new)
rep('launch','''        if (result != device_installation_none) {\n            return result;\n        }\n\n        dvc_mngr->save_devices();''','''        if (result != device_installation_none) {\n            common::delete_folder(staging_root);\n            return result;\n        }\n\n        dvc_mngr->save_devices();''')
rep('launch','''            const std::string rom_directory = add_path(conf->storage, add_path("roms", firmware_code + "\\\\"));''','''            const std::string rom_directory = add_path(rom_resident_path, firmware_code + "\\\\");''')
old='''        // The installer adds the device before all ROM paths are necessarily finalized.\n        // Recompute the stable profile identity now, then persist it before bridge reboot.\n        if (device *installed_profile = dvc_mngr->lastest()) {\n            dvc_mngr->refresh_profile_identity(installed_profile);\n            dvc_mngr->save_devices();\n            LOG_INFO(FRONTEND_CMDLINE,\n                "NGAGE CLASSIC R2B DEVICEPROFILES R1: installed product={} profile={} rom-fingerprint={}",\n                installed_profile->firmware_code, installed_profile->profile_id, installed_profile->rom_fingerprint);\n        }\n\n        return device_installation_none;'''
new='''        // Finalize by ROM fingerprint into firmware-profiles/<product__version__fingerprint>.\n        if (device *installed_profile = dvc_mngr->lastest()) {\n            if (!dvc_mngr->finalize_staged_profile(installed_profile, staging_root)) {\n                auto &installed_devices = dvc_mngr->get_devices();\n                if (!installed_devices.empty()) installed_devices.pop_back();\n                dvc_mngr->save_devices();\n                common::delete_folder(staging_root);\n                return device_installation_already_exist;\n            }\n            dvc_mngr->save_devices();\n            LOG_INFO(FRONTEND_CMDLINE,\n                "NGAGE CLASSIC R2B MULTIFIRMWARE R2: installed product={} version={} profile={}",\n                installed_profile->firmware_code, installed_profile->firmware_version, installed_profile->profile_id);\n        }\n        common::delete_folder(staging_root);\n        return device_installation_none;'''
rep('launch',old,new)
# deletion by profile id
rep('launch','''        const std::string firmcode = dvcs[index].firmware_code;\n        dvc_mngr->delete_device(firmcode);''','''        const std::string profile_id = dvcs[index].profile_id;\n        dvc_mngr->delete_device(profile_id);''')

# launcher getters for version/profile
rep('launchh','''        std::vector<std::string> get_device_firmware_codes();''','''        std::vector<std::string> get_device_firmware_codes();\n        std::vector<std::string> get_device_firmware_versions();\n        std::vector<std::string> get_device_profile_ids();''')
anchor='''    void launcher::set_language_to_property(const language new_one) {'''
extra=r'''    std::vector<std::string> launcher::get_device_firmware_versions() {
        device_manager *dvc_mngr = sys->get_device_manager();
        std::vector<std::string> info;
        for (auto &device : dvc_mngr->get_devices()) info.push_back(device.firmware_version);
        return info;
    }

    std::vector<std::string> launcher::get_device_profile_ids() {
        device_manager *dvc_mngr = sys->get_device_manager();
        std::vector<std::string> info;
        for (auto &device : dvc_mngr->get_devices()) info.push_back(device.profile_id);
        return info;
    }

'''
if t['launch'].count(anchor)!=1: raise SystemExit('launcher getter anchor')
t['launch']=t['launch'].replace(anchor,extra+anchor,1)
# bridge entry and fill
rep('bridgeh','''        std::string firmware;   // firmware code (stable id)''','''        std::string firmware;   // Nokia product code (not unique in R2)\n        std::string firmware_version;\n        std::string profile_id; // stable unique identity''')
rep('bridge','''        std::vector<std::string> firmwares = g_state->launcher_->get_device_firmware_codes();\n        for (std::size_t i = 0; i < models.size(); i++) {\n            device_entry entry;\n            entry.name = models[i];\n            entry.firmware = (i < firmwares.size()) ? firmwares[i] : std::string();\n            result.push_back(std::move(entry));\n        }''','''        std::vector<std::string> firmwares = g_state->launcher_->get_device_firmware_codes();\n        std::vector<std::string> versions = g_state->launcher_->get_device_firmware_versions();\n        std::vector<std::string> profiles = g_state->launcher_->get_device_profile_ids();\n        for (std::size_t i = 0; i < models.size(); i++) {\n            device_entry entry;\n            entry.name = models[i];\n            entry.firmware = (i < firmwares.size()) ? firmwares[i] : std::string();\n            entry.firmware_version = (i < versions.size()) ? versions[i] : std::string();\n            entry.profile_id = (i < profiles.size()) ? profiles[i] : std::string();\n            result.push_back(std::move(entry));\n        }''')
# UI device list shows product/version, but preserve name for actions
rep('rootvc','''        NSString *name = [NSString stringWithUTF8String:devices[i].name.c_str()];\n        NSString *title = (i == current) ? [name stringByAppendingString:@"  ✓"] : name;''','''        NSString *name = [NSString stringWithUTF8String:devices[i].name.c_str()];\n        NSString *product = [NSString stringWithUTF8String:devices[i].firmware.c_str()];\n        NSString *version = devices[i].firmware_version.empty() ? @"" : [NSString stringWithUTF8String:devices[i].firmware_version.c_str()];\n        NSString *detail = version.length ? [NSString stringWithFormat:@"%@ %@", product, version] : product;\n        NSString *baseTitle = detail.length ? [NSString stringWithFormat:@"%@ — %@", name, detail] : name;\n        NSString *title = (i == current) ? [baseTitle stringByAppendingString:@"  ✓"] : baseTitle;''')

# write files
for k,p in paths.items(): p.write_text(t[k],encoding='utf-8')

# audits
required=[
('devc','NGAGE CLASSIC R2B MULTIFIRMWARE R2:'),('devc','firmware-version'),('devc','finalize_staged_profile'),
('launch','firmware-staging'),('launch','finalize_staged_profile'),('bridgeh','profile_id'),('rootvc','firmware_version'),
('rpkg','duplicate product code allowed'),('fw','duplicate product code allowed'),
]
for k,s in required:
    if s not in t[k]: raise SystemExit(f'R2 audit missing {k}: {s}')
if 'NGAGE CLASSIC R2A FINAL1:' not in t['launch'] or 'NGAGE CLASSIC R2B DEVICEPROFILES R1:' not in t['devc']:
    raise SystemExit('R2 regression marker loss')
print('NGAGE CLASSIC R2B MULTIFIRMWARE R2 patch: PASS')
print('Duplicate product-code guard removal: PASS')
print('Per-install isolated firmware staging: PASS')
print('product__version__fingerprint profile finalization: PASS')
print('Profile-aware delete + ambiguous product lookup guard: PASS')
print('Firmware version metadata/display: PASS')
print('R2A FINAL1 + R2B R1 preservation: PASS')
