from pathlib import Path

root = Path('upstream')
devh = root / 'src/emu/system/include/system/devices.h'
devc = root / 'src/emu/system/src/devices.cpp'
state = root / 'src/emu/ios/src/state.cpp'
epoc = root / 'src/emu/system/src/epoc.cpp'
launcher = root / 'src/emu/ios/src/launcher.cpp'

for p in (devh, devc, state, epoc, launcher):
    if not p.is_file():
        raise SystemExit(f'R2B R1: missing source file: {p}')

ht = devh.read_text(encoding='utf-8')
dt = devc.read_text(encoding='utf-8')
st = state.read_text(encoding='utf-8')
et = epoc.read_text(encoding='utf-8')
lt = launcher.read_text(encoding='utf-8')

MARK = 'NGAGE CLASSIC R2B DEVICEPROFILES R1:'
if MARK in dt or MARK in st or MARK in et or MARK in lt:
    raise SystemExit('R2B R1 already installed')
if 'NGAGE CLASSIC R2A FINAL1:' not in lt:
    raise SystemExit('R2B R1 requires R2A FINAL1 baseline')

# ----------------------------------------------------------------------
# device metadata: persistent profile identity independent of display name.
# ----------------------------------------------------------------------
old = '''        std::string firmware_code;\n        std::string manufacturer;\n        std::string model;\n        std::vector<int> languages;'''
new = '''        std::string firmware_code;\n        // NGAGE CLASSIC R2B DEVICEPROFILES R1: stable host-storage namespace.\n        // firmware_code remains the Nokia product code (NEM-4, RM-596, ...);\n        // profile_id is the independent storage identity used for C:/E:/Z:/ROM.\n        std::string profile_id;\n        std::string rom_fingerprint;\n        std::string manufacturer;\n        std::string model;\n        std::vector<int> languages;'''
if ht.count(old) != 1:
    raise SystemExit('R2B R1: devices.h metadata anchor invalid')
ht = ht.replace(old, new, 1)

old = '''        void save_devices();\n        void load_devices();\n        void clear();'''
new = '''        void save_devices();\n        void load_devices();\n        void clear();\n\n        // Recompute profile_id once the installed ROM is present on disk.\n        void refresh_profile_identity(device *dvc);'''
if ht.count(old) != 1:
    raise SystemExit('R2B R1: devices.h manager anchor invalid')
ht = ht.replace(old, new, 1)

old = '''    };\n}\n'''
new = '''    };\n\n    // R2B profile storage helpers. Legacy storage remains untouched as a rollback source.\n    std::string device_profile_root(config::state *conf, const device &dvc);\n    bool ensure_device_profile_storage(config::state *conf, const device &dvc);\n}\n'''
if ht.count(old) != 1:
    raise SystemExit('R2B R1: devices.h footer anchor invalid')
ht = ht.replace(old, new, 1)

# ----------------------------------------------------------------------
# devices.cpp helpers: FNV-1a ROM fingerprint + profile migration/snapshot.
# ----------------------------------------------------------------------
anchor = 'namespace eka2l1 {\n    static std::map<std::string, std::uint32_t> DEVICE_UID_MAP = {'
if dt.count(anchor) != 1:
    raise SystemExit('R2B R1: devices.cpp namespace anchor invalid')
helpers = r'''namespace eka2l1 {
    // NGAGE CLASSIC R2B DEVICEPROFILES R1: profile identity is deliberately
    // separate from firmware_code. This first R2B slice keeps duplicate-product
    // installation guarded, but makes all runtime storage profile-addressable so
    // R2B R2 can safely allow multiple firmware revisions of the same product.
    static std::string r2b_profile_component(std::string value) {
        value = common::lowercase_string(value);
        std::string out;
        bool last_dash = false;
        for (unsigned char c : value) {
            const bool alnum = ((c >= 'a') && (c <= 'z')) || ((c >= '0') && (c <= '9'));
            if (alnum) {
                out.push_back(static_cast<char>(c));
                last_dash = false;
            } else if (!last_dash && !out.empty()) {
                out.push_back('-');
                last_dash = true;
            }
        }
        while (!out.empty() && out.back() == '-') {
            out.pop_back();
        }
        return out.empty() ? std::string("device") : out;
    }

    static std::string r2b_rom_fingerprint(const std::string &path) {
        std::ifstream in(path, std::ios::binary);
        if (!in) {
            return {};
        }

        // FNV-1a 64 is used as a stable namespace fingerprint, not as a security hash.
        std::uint64_t hash = 14695981039346656037ULL;
        char buffer[64 * 1024];
        while (in) {
            in.read(buffer, sizeof(buffer));
            const std::streamsize got = in.gcount();
            for (std::streamsize i = 0; i < got; ++i) {
                hash ^= static_cast<unsigned char>(buffer[i]);
                hash *= 1099511628211ULL;
            }
        }

        std::ostringstream out;
        out << std::hex << std::nouppercase;
        out.width(16);
        out.fill('0');
        out << hash;
        return out.str();
    }

    static std::string r2b_legacy_rom_path(config::state *conf, const std::string &firmcode) {
        return add_path(conf->storage,
            add_path("roms", add_path(common::lowercase_string(firmcode), "SYM.ROM")));
    }

    std::string device_profile_root(config::state *conf, const device &dvc) {
        if (!conf || dvc.profile_id.empty()) {
            return {};
        }
        return add_path(conf->storage, add_path("firmware-profiles", dvc.profile_id));
    }

    static bool r2b_copy_tree_if_present(const std::string &src, const std::string &dst) {
        if (!common::exists(src)) {
            return true;
        }
        common::create_directories(dst);
        return common::copy_folder(src, dst, common::FOLDER_COPY_FLAG_FILE_NO_OVERWRITE_IF_EXIST);
    }

    bool ensure_device_profile_storage(config::state *conf, const device &dvc) {
        const std::string root = device_profile_root(conf, dvc);
        if (root.empty()) {
            return false;
        }

        const std::string marker = add_path(root, ".r2b-deviceprofiles-r1");
        if (common::exists(marker)) {
            return true;
        }

        const std::string firm_low = common::lowercase_string(dvc.firmware_code);
        const std::string drives_root = add_path(root, "drives");
        const std::string c_root = add_path(drives_root, "c");
        const std::string e_root = add_path(drives_root, "e");
        const std::string z_root = add_path(drives_root, "z");
        const std::string roms_root = add_path(root, "roms");

        common::create_directories(c_root);
        common::create_directories(e_root);
        common::create_directories(add_path(z_root, firm_low));
        common::create_directories(add_path(roms_root, firm_low));

        // One-time, non-destructive migration from FINAL1's shared layout. Keeping the
        // legacy tree makes rollback to FINAL1 possible while R2B is under validation.
        const bool c_ok = r2b_copy_tree_if_present(add_path(conf->storage, "drives/c"), c_root);
        const bool e_ok = r2b_copy_tree_if_present(add_path(conf->storage, "drives/e"), e_root);
        const bool z_ok = r2b_copy_tree_if_present(add_path(conf->storage, add_path("drives/z", firm_low)),
            add_path(z_root, firm_low));
        const bool rom_ok = r2b_copy_tree_if_present(add_path(conf->storage, add_path("roms", firm_low)),
            add_path(roms_root, firm_low));
        if (!c_ok || !e_ok || !z_ok || !rom_ok) {
            LOG_ERROR(SYSTEM, "NGAGE CLASSIC R2B DEVICEPROFILES R1: migration failed for profile {}", dvc.profile_id);
            return false;
        }

        YAML::Emitter meta;
        meta << YAML::BeginMap;
        meta << YAML::Key << dvc.profile_id << YAML::Value << YAML::BeginMap;
        meta << YAML::Key << "firmcode" << YAML::Value << dvc.firmware_code;
        meta << YAML::Key << "profile-id" << YAML::Value << dvc.profile_id;
        meta << YAML::Key << "rom-fingerprint" << YAML::Value << dvc.rom_fingerprint;
        meta << YAML::Key << "model" << YAML::Value << dvc.model;
        meta << YAML::Key << "manufacturer" << YAML::Value << dvc.manufacturer;
        meta << YAML::Key << "platver" << YAML::Value << epocver_to_string(dvc.ver);
        meta << YAML::EndMap << YAML::EndMap;
        common::wo_std_file_stream profile_meta(add_path(root, "devices.yml"), true);
        profile_meta.write(meta.c_str(), meta.size());

        std::ofstream marker_out(marker, std::ios::binary | std::ios::trunc);
        marker_out << "R2B DEVICEPROFILES R1\n";
        marker_out << "profile=" << dvc.profile_id << "\n";
        marker_out << "firmcode=" << dvc.firmware_code << "\n";
        marker_out << "rom-fingerprint=" << dvc.rom_fingerprint << "\n";
        marker_out.close();

        LOG_INFO(SYSTEM,
            "NGAGE CLASSIC R2B DEVICEPROFILES R1: profile ready id={} product={} root={}",
            dvc.profile_id, dvc.firmware_code, root);
        return true;
    }

    static std::map<std::string, std::uint32_t> DEVICE_UID_MAP = {'''
dt = dt.replace(anchor, helpers, 1)

# load schema: map key becomes profile id; firmcode remains explicit field.
old = '''        for (auto device_node : devices_node) {\n            const std::string firmcode = device_node.first.as<std::string>();\n            const std::string manufacturer = device_node.second["manufacturer"].as<std::string>();'''
new = '''        for (auto device_node : devices_node) {\n            const std::string registry_key = device_node.first.as<std::string>();\n            std::string firmcode = registry_key;\n            try {\n                firmcode = device_node.second["firmcode"].as<std::string>();\n            } catch (YAML::Exception exception) {\n                // FINAL1/legacy devices.yml used the product code as the map key.\n            }\n            const std::string manufacturer = device_node.second["manufacturer"].as<std::string>();'''
if dt.count(old) != 1:
    raise SystemExit('R2B R1: load firmcode anchor invalid')
dt = dt.replace(old, new, 1)

old = '''            if (device *added = get(firmcode)) {\n                added->language = chosen_language;\n            }'''
new = '''            if (device *added = get(firmcode)) {\n                added->language = chosen_language;\n\n                try {\n                    const std::string loaded_profile = device_node.second["profile-id"].as<std::string>();\n                    if (!loaded_profile.empty()) {\n                        added->profile_id = loaded_profile;\n                    }\n                } catch (YAML::Exception exception) {\n                }\n                try {\n                    added->rom_fingerprint = device_node.second["rom-fingerprint"].as<std::string>();\n                } catch (YAML::Exception exception) {\n                }\n\n                // Older FINAL1 registries have no profile metadata. Compute it from the\n                // installed ROM and immediately persist the migrated schema.\n                if (added->profile_id.empty() || added->rom_fingerprint.empty()) {\n                    refresh_profile_identity(added);\n                }\n            }'''
if dt.count(old) != 1:
    raise SystemExit('R2B R1: load metadata anchor invalid')
dt = dt.replace(old, new, 1)

old = '''        for (const auto &device : devices) {\n            emitter << YAML::Key << device.firmware_code;\n            emitter << YAML::Value << YAML::BeginMap;\n\n            emitter << YAML::Key << "platver" << YAML::Value << epocver_to_string(device.ver);'''
new = '''        for (const auto &device : devices) {\n            emitter << YAML::Key << (device.profile_id.empty() ? device.firmware_code : device.profile_id);\n            emitter << YAML::Value << YAML::BeginMap;\n\n            emitter << YAML::Key << "platver" << YAML::Value << epocver_to_string(device.ver);'''
if dt.count(old) != 1:
    raise SystemExit('R2B R1: save key anchor invalid')
dt = dt.replace(old, new, 1)

old = '''            emitter << YAML::Key << "firmcode" << YAML::Value << device.firmware_code;\n            emitter << YAML::Key << "model" << YAML::Value << device.model;'''
new = '''            emitter << YAML::Key << "firmcode" << YAML::Value << device.firmware_code;\n            emitter << YAML::Key << "profile-id" << YAML::Value << device.profile_id;\n            emitter << YAML::Key << "rom-fingerprint" << YAML::Value << device.rom_fingerprint;\n            emitter << YAML::Key << "model" << YAML::Value << device.model;'''
if dt.count(old) != 1:
    raise SystemExit('R2B R1: save metadata anchor invalid')
dt = dt.replace(old, new, 1)

# Add refresh_profile_identity before constructor.
anchor = '''    device_manager::device_manager(config::state *conf)\n        : conf(conf)'''
if dt.count(anchor) != 1:
    raise SystemExit('R2B R1: constructor anchor invalid')
refresh = r'''    void device_manager::refresh_profile_identity(device *dvc) {
        if (!dvc) {
            return;
        }

        const std::string fingerprint = r2b_rom_fingerprint(r2b_legacy_rom_path(conf, dvc->firmware_code));
        if (!fingerprint.empty()) {
            dvc->rom_fingerprint = fingerprint;
            dvc->profile_id = r2b_profile_component(dvc->firmware_code) + "__" + fingerprint;
        } else if (dvc->profile_id.empty()) {
            dvc->profile_id = r2b_profile_component(dvc->firmware_code) + "__pending";
        }
    }

    device_manager::device_manager(config::state *conf)
        : conf(conf)'''
dt = dt.replace(anchor, refresh, 1)

old = '''        dvc.default_language_code = default_language;\n        dvc.machine_uid = machine_uid;\n\n        devices.push_back(dvc);'''
new = '''        dvc.default_language_code = default_language;\n        dvc.machine_uid = machine_uid;\n        refresh_profile_identity(&dvc);\n\n        devices.push_back(dvc);'''
if dt.count(old) != 1:
    raise SystemExit('R2B R1: add device anchor invalid')
dt = dt.replace(old, new, 1)

# ----------------------------------------------------------------------
# iOS boot: create profile snapshot before startup, mount C/E/Z from profile.
# ----------------------------------------------------------------------
old = '''            if (device *boot_dvc = dvcmngr->get(static_cast<std::uint8_t>(boot_index))) {\n                conf.language = (boot_dvc->language >= 0) ? boot_dvc->language : boot_dvc->default_language_code;\n            }\n\n            symsys->startup();'''
new = '''            if (device *boot_dvc = dvcmngr->get(static_cast<std::uint8_t>(boot_index))) {\n                conf.language = (boot_dvc->language >= 0) ? boot_dvc->language : boot_dvc->default_language_code;\n                if (!ensure_device_profile_storage(&conf, *boot_dvc)) {\n                    LOG_WARN(FRONTEND_CMDLINE,\n                        "NGAGE CLASSIC R2B DEVICEPROFILES R1: profile migration unavailable; legacy paths remain fallback");\n                }\n            }\n\n            symsys->startup();'''
if st.count(old) != 1:
    raise SystemExit('R2B R1: state pre-start anchor invalid')
st = st.replace(old, new, 1)

old = '''            symsys->mount(drive_c, drive_media::physical, eka2l1::add_path(conf.storage, "/drives/c/"), io_attrib_internal);\n            symsys->mount(drive_d, drive_media::physical, eka2l1::add_path(conf.storage, "/drives/d/"), io_attrib_internal);\n            symsys->mount(drive_e, drive_media::physical, eka2l1::add_path(conf.storage, "/drives/e/"), io_attrib_removeable);'''
new = '''            device *active_profile_device = dvcmngr->get_current();\n            std::string active_profile_root;\n            if (active_profile_device) {\n                active_profile_root = device_profile_root(&conf, *active_profile_device);\n            }\n            const bool profile_ready = !active_profile_root.empty() &&\n                common::exists(eka2l1::add_path(active_profile_root, ".r2b-deviceprofiles-r1"));\n\n            const std::string c_mount = profile_ready\n                ? eka2l1::add_path(active_profile_root, "drives/c/")\n                : eka2l1::add_path(conf.storage, "/drives/c/");\n            const std::string e_mount = profile_ready\n                ? eka2l1::add_path(active_profile_root, "drives/e/")\n                : eka2l1::add_path(conf.storage, "/drives/e/");\n\n            symsys->mount(drive_c, drive_media::physical, c_mount, io_attrib_internal);\n            symsys->mount(drive_d, drive_media::physical, eka2l1::add_path(conf.storage, "/drives/d/"), io_attrib_internal);\n            symsys->mount(drive_e, drive_media::physical, e_mount, io_attrib_removeable);\n\n            if (active_profile_device) {\n                LOG_INFO(FRONTEND_CMDLINE,\n                    "NGAGE CLASSIC R2B DEVICEPROFILES R1: active profile={} product={} C={} E={}",\n                    active_profile_device->profile_id, active_profile_device->firmware_code, c_mount, e_mount);\n            }'''
if st.count(old) != 1:
    raise SystemExit('R2B R1: C/E mount anchor invalid')
st = st.replace(old, new, 1)

old = '''            symsys->mount(drive_z, drive_media::rom,\n                eka2l1::add_path(conf.storage, "/drives/z/"), io_attrib_internal | io_attrib_write_protected);'''
new = '''            const std::string active_profile_root = device_profile_root(&conf, *dvc);\n            const bool profile_ready = !active_profile_root.empty() &&\n                common::exists(eka2l1::add_path(active_profile_root, ".r2b-deviceprofiles-r1"));\n            const std::string z_mount = profile_ready\n                ? eka2l1::add_path(active_profile_root, "drives/z/")\n                : eka2l1::add_path(conf.storage, "/drives/z/");\n\n            symsys->mount(drive_z, drive_media::rom, z_mount,\n                io_attrib_internal | io_attrib_write_protected);\n            LOG_INFO(FRONTEND_CMDLINE,\n                "NGAGE CLASSIC R2B DEVICEPROFILES R1: Z profile={} mount={}", dvc->profile_id, z_mount);'''
if st.count(old) != 1:
    raise SystemExit('R2B R1: Z mount anchor invalid')
st = st.replace(old, new, 1)

# ----------------------------------------------------------------------
# Core ROM load: prefer profile ROM, fallback to FINAL1 legacy tree.
# ----------------------------------------------------------------------
old = '''        // Load ROM\n        const std::string rom_path = add_path(conf_->storage, add_path(preset::ROM_FOLDER_PATH, add_path(common::lowercase_string(dvc->firmware_code), preset::ROM_FILENAME)));\n\n        if (!load_rom(rom_path)) {'''
new = '''        // Load ROM. R2B DEVICEPROFILES prefers the active profile copy; keeping\n        // the legacy ROM path as fallback makes the migration reversible during validation.\n        const std::string legacy_rom_path = add_path(conf_->storage,\n            add_path(preset::ROM_FOLDER_PATH, add_path(common::lowercase_string(dvc->firmware_code), preset::ROM_FILENAME)));\n        const std::string profile_root = device_profile_root(conf_, *dvc);\n        const std::string profile_rom_path = profile_root.empty() ? std::string() : add_path(profile_root,\n            add_path(preset::ROM_FOLDER_PATH, add_path(common::lowercase_string(dvc->firmware_code), preset::ROM_FILENAME)));\n        const std::string rom_path = (!profile_rom_path.empty() && common::exists(profile_rom_path))\n            ? profile_rom_path\n            : legacy_rom_path;\n\n        LOG_INFO(SYSTEM, "NGAGE CLASSIC R2B DEVICEPROFILES R1: ROM profile={} path={}",\n            dvc->profile_id, rom_path);\n\n        if (!load_rom(rom_path)) {'''
if et.count(old) != 1:
    raise SystemExit('R2B R1: ROM load anchor invalid')
et = et.replace(old, new, 1)

# ----------------------------------------------------------------------
# Installer: once ROM copy is complete, seal the final profile identity.
# ----------------------------------------------------------------------
old = '''        if (need_add_rpkg) {\n            const std::string rom_directory = add_path(conf->storage, add_path("roms", firmware_code + "\\\\"));\n            eka2l1::common::create_directories(rom_directory);\n            common::copy_file(rom_path, add_path(rom_directory, "SYM.ROM"), true);\n        }\n\n        return device_installation_none;'''
new = '''        if (need_add_rpkg) {\n            const std::string rom_directory = add_path(conf->storage, add_path("roms", firmware_code + "\\\\"));\n            eka2l1::common::create_directories(rom_directory);\n            common::copy_file(rom_path, add_path(rom_directory, "SYM.ROM"), true);\n        }\n\n        // The installer adds the device before all ROM paths are necessarily finalized.\n        // Recompute the stable profile identity now, then persist it before bridge reboot.\n        if (device *installed_profile = dvc_mngr->lastest()) {\n            dvc_mngr->refresh_profile_identity(installed_profile);\n            dvc_mngr->save_devices();\n            LOG_INFO(FRONTEND_CMDLINE,\n                "NGAGE CLASSIC R2B DEVICEPROFILES R1: installed product={} profile={} rom-fingerprint={}",\n                installed_profile->firmware_code, installed_profile->profile_id, installed_profile->rom_fingerprint);\n        }\n\n        return device_installation_none;'''
if lt.count(old) != 1:
    raise SystemExit('R2B R1: launcher install finalization anchor invalid')
lt = lt.replace(old, new, 1)

# Regression/audit markers.
for token, text in (
    ('devices.h profile_id', ht),
    ('devices.cpp marker', dt),
    ('state.cpp marker', st),
    ('epoc.cpp marker', et),
    ('launcher.cpp marker', lt),
):
    if 'profile_id' not in text and token == 'devices.h profile_id':
        raise SystemExit('R2B R1 audit failed: profile_id missing')

for token in (
    'NGAGE CLASSIC R2B DEVICEPROFILES R1:',
    'firmware-profiles',
    '.r2b-deviceprofiles-r1',
):
    if token not in (dt + st + et + lt):
        raise SystemExit('R2B R1 audit missing: ' + token)

if 'NGAGE CLASSIC R2A FINAL1:' not in lt:
    raise SystemExit('R2B R1 regression: FINAL1 marker lost')
if 'NGAGE CLASSIC R2A BOOTREADY1:' not in (lt + (root/'src/emu/ios/app/RootViewController.mm').read_text(encoding='utf-8')):
    raise SystemExit('R2B R1 regression: BOOTREADY1 marker lost')

# Commit writes only after every anchor/audit has passed.
devh.write_text(ht, encoding='utf-8')
devc.write_text(dt, encoding='utf-8')
state.write_text(st, encoding='utf-8')
epoc.write_text(et, encoding='utf-8')
launcher.write_text(lt, encoding='utf-8')

print('NGAGE CLASSIC R2B DEVICEPROFILES R1 patch: PASS')
print('Persistent profile-id + ROM fingerprint: PASS')
print('FINAL1 legacy storage snapshot/migration: PASS')
print('Per-profile C/E/Z mounts + ROM path: PASS')
print('R2A FINAL1 / BOOTREADY1 regression guards: PASS')
print('R2B R2 duplicate-product install intentionally deferred: PASS')
