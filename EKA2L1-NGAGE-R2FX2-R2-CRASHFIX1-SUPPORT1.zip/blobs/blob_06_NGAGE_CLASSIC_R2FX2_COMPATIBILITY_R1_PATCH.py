from pathlib import Path

root = Path('upstream')
p = root/'src/emu/kernel/src/codeseg.cpp'
if not p.is_file():
    raise SystemExit(f'R2FX2: missing {p}')
t = p.read_text(encoding='utf-8')

if 'NGAGE CLASSIC R2FX2 COMPATIBILITY R1:' in t:
    raise SystemExit('R2FX2 already installed')
if 'NGAGE CLASSIC R2FX1 CLEANUP:' not in t:
    raise SystemExit('R2FX2 requires frozen R2FX1 CLEANUP baseline')

old = r'''                        if (!addr) {
                            LOG_WARN(KERNEL,
                                "NGAGE CLASSIC R2FX1 CLEANUP: unresolved guest ordinal={} dependency={} requester={}",
                                ord, dependency.dep_->name(), name());
                        }
'''
new = r'''                        if (!addr) {
                            // NGAGE CLASSIC R2FX2 COMPATIBILITY R1:
                            // The exact import family below is a known EKA1/legacy-ROM version-skew pattern.
                            // It is also present in upstream EKA2L1 RH-29 traces.  These imports come from
                            // later multimedia/camera plug-ins being inspected against older EKA1 system DLL
                            // export tables.  Do NOT fabricate an export address: a wrong shim is less safe
                            // than leaving the relocation unresolved.  Classify only the evidence-proven set
                            // as trace-level compatibility noise; any new ordinal/dependency/requester remains
                            // a warning and therefore cannot be silently hidden by this patch.
                            const std::string dep_name = dependency.dep_->name();
                            const std::string requester_name = name();
                            const bool known_requester =
                                requester_name == "mediaclientvideo_v100.dll" ||
                                requester_name == "postingsurfacefactory_general.dll" ||
                                requester_name == "audiooutputrouting_general.dll" ||
                                requester_name == "ecam_general.dll";
                            const bool known_euser = dep_name == "euser.dll" &&
                                (ord == 1702 || ord == 1719 || ord == 1901 || ord == 1953 ||
                                 ord == 2060 || ord == 2061 || ord == 2082 || ord == 2123 ||
                                 ord == 2126 || ord == 2128 || ord == 2132);
                            const bool known_efsrv = dep_name == "efsrv.dll" && ord == 305;
                            const bool known_hal = dep_name == "hal.dll" && ord == 4;
                            const bool known_fbscli = dep_name == "fbscli.dll" && (ord == 249 || ord == 250);
                            const bool known_ws32 = dep_name == "ws32.dll" && ord == 392;
                            const bool known_legacy_version_skew = known_requester &&
                                (known_euser || known_efsrv || known_hal || known_fbscli || known_ws32);

                            if (known_legacy_version_skew) {
                                LOG_TRACE(KERNEL,
                                    "NGAGE CLASSIC R2FX2 COMPATIBILITY R1: known EKA1 version-skew import ordinal={} dependency={} requester={}; no unsafe shim installed",
                                    ord, dep_name, requester_name);
                            } else {
                                LOG_WARN(KERNEL,
                                    "NGAGE CLASSIC R2FX2 COMPATIBILITY R1: unresolved NEW guest ordinal={} dependency={} requester={}",
                                    ord, dep_name, requester_name);
                            }
                        }
'''
count = t.count(old)
if count != 1:
    raise SystemExit(f'R2FX2 codeseg anchor count={count}, expected=1')
t = t.replace(old,new,1)
p.write_text(t,encoding='utf-8')

# Audits: ensure exact evidence-proven set and safety invariant are present.
out = p.read_text(encoding='utf-8')
required = [
    'NGAGE CLASSIC R2FX2 COMPATIBILITY R1:',
    'known EKA1 version-skew import ordinal=',
    'unresolved NEW guest ordinal=',
    'no unsafe shim installed',
    'ord == 305', 'ord == 4', 'ord == 249', 'ord == 250', 'ord == 392',
    'ord == 1702', 'ord == 1719', 'ord == 1901', 'ord == 1953',
    'ord == 2060', 'ord == 2061', 'ord == 2082', 'ord == 2123',
    'ord == 2126', 'ord == 2128', 'ord == 2132',
    'mediaclientvideo_v100.dll', 'postingsurfacefactory_general.dll',
    'audiooutputrouting_general.dll', 'ecam_general.dll',
]
for s in required:
    if s not in out:
        raise SystemExit('R2FX2 audit missing: '+s)
if 'NGAGE CLASSIC R2FX1 CLEANUP: unresolved guest ordinal=' in out:
    raise SystemExit('R2FX2 audit: old R2FX1 ordinal warning remained')
print('NGAGE CLASSIC R2FX2 COMPATIBILITY R1 patch: PASS')
print('Evidence-proven EKA1 version-skew import family classified: PASS')
print('Unknown ordinals remain warning-visible: PASS')
print('No fabricated export address / unsafe shim: PASS')
