from pathlib import Path

root = Path("upstream")
rootvc = root / "src/emu/ios/app/RootViewController.mm"

if not rootvc.is_file():
    raise SystemExit("BOOTREADY1: RootViewController.mm missing")

rt = rootvc.read_text(encoding="utf-8")

if "NGAGE CLASSIC R2A FIX4 DISPATCHER:" not in (root / "src/emu/ios/src/launcher.cpp").read_text(encoding="utf-8"):
    raise SystemExit("BOOTREADY1 requires FIX4 DISPATCHER baseline")
if "NGAGE CLASSIC R2A BOOTREADY1:" in rt:
    raise SystemExit("BOOTREADY1 already installed")

old_climb = r'''- (void)climbProgressToward:(float)target {
    [self.progressTimer invalidate];
    __weak RootViewController *weakSelf = self;
    self.progressTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 repeats:YES block:^(NSTimer *t) {
        RootViewController *s = weakSelf;
        if (!s) { [t invalidate]; return; }
        [s setProgressFraction:s.progressValue + (target - s.progressValue) * 0.05f];
    }];
}'''

new_climb = r'''- (void)climbProgressToward:(float)target {
    [self.progressTimer invalidate];
    __weak RootViewController *weakSelf = self;
    self.progressTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 repeats:YES block:^(NSTimer *t) {
        RootViewController *s = weakSelf;
        if (!s) { [t invalidate]; return; }

        // NGAGE CLASSIC R2A BOOTREADY1: progress is monotonic. A synthetic
        // boot timer must never drag a real progress value backwards.
        if (s.progressValue >= target) {
            [t invalidate];
            return;
        }

        float next = s.progressValue + (target - s.progressValue) * 0.05f;
        if (next > s.progressValue) {
            [s setProgressFraction:next];
        }
    }];
}'''

if rt.count(old_climb) != 1:
    raise SystemExit(f"BOOTREADY1: climbProgressToward anchor count={rt.count(old_climb)}")
rt = rt.replace(old_climb, new_climb, 1)

old_install = r'''    NSLog(@"NGAGE CLASSIC R1: installing bundled NEM-4 ROM path=%@ bytes=%llu",
          romPath, bytes);
    [self beginProgress:EKAL(@"Installing N-Gage…")];
    [self climbProgressToward:0.92f];

    std::string rom([romPath UTF8String]);
    __weak RootViewController *weakSelf = self;
    auto progress = [weakSelf](int pct) {
        dispatch_async(dispatch_get_main_queue(), ^{
            RootViewController *s = weakSelf;
            if (s) [s setProgressFraction:(float)pct / 100.0f];
        });
    };

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        // S60v1/N-Gage uses ROM-only installation. Passing an empty RPKG is safe
        // because the normal EKA2L1 installer only asks for RPKG when the ROM says
        // one is required; NEM-4 does not.
        int result = eka2l1::ios::bridge::install_device(std::string(), rom, true, progress);
        if (result == 0) {
            int installed = eka2l1::ios::bridge::get_current_device();
            if (installed >= 0) {
                eka2l1::ios::bridge::rename_device(installed, "N-Gage");
            }
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            RootViewController *s = weakSelf;
            if (!s) return;
            if (result != 0) {
                [s endProgress];
                [s showAlert:EKAL(@"N-Gage installation failed")
                        message:[NSString stringWithFormat:
                            EKAL(@"Could not install N-Gage firmware (error %d)."), result]];
                return;
            }

            NSLog(@"NGAGE CLASSIC R1: bundled NEM-4 installation complete");
            [s updateChrome];
            [s refreshDeviceButton];
            [s pollUntilAppsThen:^(BOOL found) {
                [s endProgress];
                [s showAppsScreen];
                [s showAlert:EKAL(@"N-Gage ready") message:EKAL(@"N-Gage mode is ready.")];
            } attemptsLeft:30];
        });
    });'''

new_install = r'''    NSLog(@"NGAGE CLASSIC R1: installing bundled NEM-4 ROM path=%@ bytes=%llu",
          romPath, bytes);
    [self beginProgress:EKAL(@"Installing N-Gage…")];

    // BOOTREADY1: only a small synthetic movement is used before the ROM
    // installer starts reporting real extraction progress.
    [self climbProgressToward:0.12f];

    std::string rom([romPath UTF8String]);
    __weak RootViewController *weakSelf = self;
    auto progress = [weakSelf](int pct) {
        dispatch_async(dispatch_get_main_queue(), ^{
            RootViewController *s = weakSelf;
            if (!s) return;

            if (pct >= 100) {
                // The ROM payload is complete; bridge::install_device() still has
                // to restart the emulator. Do not show 100% until that succeeds.
                s.statusLabel.text = EKAL(@"Starting N-Gage…");
                if (s.progressValue < 0.90f) {
                    [s setProgressFraction:0.90f];
                }
                [s climbProgressToward:0.98f];
            } else {
                float mapped = ((float)pct / 100.0f) * 0.90f;
                if (mapped > s.progressValue) {
                    [s setProgressFraction:mapped];
                }
            }
        });
    };

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        // S60v1/N-Gage uses ROM-only installation. Passing an empty RPKG is safe
        // because the normal EKA2L1 installer only asks for RPKG when the ROM says
        // one is required; NEM-4 does not.
        int result = eka2l1::ios::bridge::install_device(std::string(), rom, true, progress);

        int installed = -1;
        BOOL ready = NO;
        if (result == 0) {
            installed = eka2l1::ios::bridge::get_current_device();
            if (installed >= 0) {
                eka2l1::ios::bridge::rename_device(installed, "N-Gage");
            }

            // NGAGE CLASSIC R2A BOOTREADY1: "running device" is the completion
            // condition. AppArc may legitimately contain zero games on a fresh ROM.
            ready = eka2l1::ios::bridge::is_running() &&
                    eka2l1::ios::bridge::has_device() &&
                    installed >= 0 &&
                    eka2l1::ios::bridge::get_current_device() == installed;
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            RootViewController *s = weakSelf;
            if (!s) return;
            if (result != 0) {
                [s endProgress];
                [s showAlert:EKAL(@"N-Gage installation failed")
                        message:[NSString stringWithFormat:
                            EKAL(@"Could not install N-Gage firmware (error %d)."), result]];
                return;
            }
            if (!ready) {
                [s endProgress];
                [s refreshDeviceButton];
                [s showAlert:EKAL(@"N-Gage installation failed")
                        message:EKAL(@"N-Gage firmware was installed, but the emulator did not reach the running state.")];
                return;
            }

            NSLog(@"NGAGE CLASSIC R2A BOOTREADY1: bundled NEM-4 running index=%d", installed);
            [s updateChrome];
            [s refreshDeviceButton];

            // No app-count polling: an empty game/app list is valid on a fresh N-Gage.
            [s endProgress];
            [s showAppsScreen];
            [s showAlert:EKAL(@"N-Gage ready") message:EKAL(@"N-Gage mode is ready.")];
        });
    });'''

if rt.count(old_install) != 1:
    raise SystemExit(f"BOOTREADY1: bundled install anchor count={rt.count(old_install)}")
rt = rt.replace(old_install, new_install, 1)

old_switch = r'''- (void)switchToDevice:(int)index {
    [self beginProgress:EKAL(@"Switching device…")];
    [self climbProgressToward:0.95f];   // reboot has no granular metric
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        // set_current_device returns once the new instance's threads are spawned; the guest
        // then boots asynchronously, so keep the bar climbing until its apps appear.
        eka2l1::ios::bridge::set_current_device(index);
        dispatch_async(dispatch_get_main_queue(), ^{
            [self updateChrome];
            [self pollUntilAppsThen:^(BOOL found) {
                [self endProgress];
                [self showAppsScreen];
            } attemptsLeft:30];
        });
    });
}'''

new_switch = r'''- (void)switchToDevice:(int)index {
    [self beginProgress:EKAL(@"Switching device…")];
    [self climbProgressToward:0.98f];

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        // NGAGE CLASSIC R2A BOOTREADY1: the bridge restarts the selected
        // device synchronously. Apps are optional data, not a boot signal.
        eka2l1::ios::bridge::set_current_device(index);

        BOOL ready = eka2l1::ios::bridge::is_running() &&
                     eka2l1::ios::bridge::has_device() &&
                     eka2l1::ios::bridge::get_current_device() == index;

        dispatch_async(dispatch_get_main_queue(), ^{
            [self updateChrome];
            [self refreshDeviceButton];
            [self endProgress];
            [self showAppsScreen];

            if (!ready) {
                [self showAlert:EKAL(@"Device switch failed")
                        message:EKAL(@"The selected device did not reach the running state.")];
            }
        });
    });
}'''

if rt.count(old_switch) != 1:
    raise SystemExit(f"BOOTREADY1: switchToDevice anchor count={rt.count(old_switch)}")
rt = rt.replace(old_switch, new_switch, 1)

loc = root / "src/emu/ios/app/EKALocalization.mm"
lc = loc.read_text(encoding="utf-8")
loc_anchor = '        @"N-Gage mode is ready." : @"Chế độ N-Gage đã sẵn sàng.",'
if lc.count(loc_anchor) != 1:
    raise SystemExit(f"BOOTREADY1: localization anchor count={lc.count(loc_anchor)}")

loc_extra = r'''
        @"Starting N-Gage…" : @"Đang khởi động N-Gage…",
        @"N-Gage firmware was installed, but the emulator did not reach the running state." : @"Firmware N-Gage đã được cài nhưng trình giả lập chưa đạt trạng thái hoạt động.",
        @"Device switch failed" : @"Chuyển thiết bị thất bại",
        @"The selected device did not reach the running state." : @"Thiết bị đã chọn chưa đạt trạng thái hoạt động.",'''
lc = lc.replace(loc_anchor, loc_anchor + loc_extra, 1)

for token in (
    "NGAGE CLASSIC R2A BOOTREADY1:",
    "bridge::is_running()",
    "bridge::has_device()",
    "empty game/app list is valid",
    "progress is monotonic",
):
    if token not in rt:
        raise SystemExit("BOOTREADY1 RootViewController audit missing: " + token)

install_pos = rt.find("- (void)installBundledNGageMode")
install_end = rt.find("// ---- Devices manager", install_pos)
switch_pos = rt.find("- (void)switchToDevice")
switch_end = rt.find("- (void)confirmDeleteDevice", switch_pos)
if "pollUntilAppsThen" in rt[install_pos:install_end]:
    raise SystemExit("BOOTREADY1: N-Gage install still depends on app polling")
if "pollUntilAppsThen" in rt[switch_pos:switch_end]:
    raise SystemExit("BOOTREADY1: device switch still depends on app polling")

rootvc.write_text(rt, encoding="utf-8")
loc.write_text(lc, encoding="utf-8")

print("NGAGE CLASSIC R2A BOOTREADY1 patch: PASS")
print("N-Gage install readiness = bridge running/current device: PASS")
print("Device switch readiness = bridge running/current device: PASS")
print("Fresh device may have zero apps: PASS")
print("Progress monotonic / no 100->92 regression: PASS")
