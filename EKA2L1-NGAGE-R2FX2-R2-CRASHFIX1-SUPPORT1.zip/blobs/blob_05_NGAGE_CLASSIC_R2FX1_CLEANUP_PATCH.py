from pathlib import Path

root = Path('upstream')
paths = {
    'devc': root/'src/emu/system/src/devices.cpp',
    'rootvc': root/'src/emu/ios/app/RootViewController.mm',
    'ogl': root/'src/emu/drivers/src/graphics/backend/ogl/graphics_ogl.cpp',
    'fb': root/'src/emu/drivers/src/graphics/backend/ogl/fb_ogl.cpp',
    'codeseg': root/'src/emu/kernel/src/codeseg.cpp',
}
for p in paths.values():
    if not p.is_file():
        raise SystemExit(f'R2FX1: missing {p}')
t = {k:p.read_text(encoding='utf-8') for k,p in paths.items()}
MARK='NGAGE CLASSIC R2FX1 CLEANUP:'
if any(MARK in x for x in t.values()):
    raise SystemExit('R2FX1 already installed')
if 'NGAGE CLASSIC R2B MULTIFIRMWARE R2:' not in t['devc']:
    raise SystemExit('R2FX1 requires R2B MULTIFIRMWARE R2 baseline')

def rep(k, old, new, count=1):
    c=t[k].count(old)
    if c != count:
        raise SystemExit(f'R2FX1 anchor {k} count={c} expected={count}: {old[:120]!r}')
    t[k]=t[k].replace(old,new,count)

# 1) Canonical firmware SW version. sw.txt on some firmware is returned as a single
# escaped/multiline string by dynamic_ifile. Keep only the first semantic line.
old=r'''    static std::string r2b_read_firmware_version(const std::string &z_product_root) {
        const std::array<std::string, 4> candidates = {
            add_path(z_product_root, "resource/versions/sw.txt"),
            add_path(z_product_root, "system/versions/sw.txt"),
            add_path(z_product_root, "resource\\versions\\sw.txt"),
            add_path(z_product_root, "system\\versions\\sw.txt")
        };
        for (const auto &path : candidates) {
            common::dynamic_ifile f(path);
            if (f.fail()) continue;
            std::string line;
            f.set_ucs2(0);
            f.getline(line);
            if (line.empty()) continue;
            for (char &c : line) if (c == '\r' || c == '\n' || c == '\t') c = ' ';
            while (!line.empty() && line.back() == ' ') line.pop_back();
            std::size_t start = line.find_first_not_of(' ');
            if (start != std::string::npos) line.erase(0, start);
            if (!line.empty()) return line;
        }
        return {};
    }
'''
new=r'''    static std::string r2b_read_firmware_version(const std::string &z_product_root) {
        const std::array<std::string, 4> candidates = {
            add_path(z_product_root, "resource/versions/sw.txt"),
            add_path(z_product_root, "system/versions/sw.txt"),
            add_path(z_product_root, "resource\\versions\\sw.txt"),
            add_path(z_product_root, "system\\versions\\sw.txt")
        };
        for (const auto &path : candidates) {
            common::dynamic_ifile f(path);
            if (f.fail()) continue;
            std::string value;
            f.set_ucs2(0);
            f.getline(value);
            if (value.empty()) continue;

            // NGAGE CLASSIC R2FX1 CLEANUP: SW identity is the first line only.
            // Handle both real control characters and literal "\\n" sequences seen
            // in some Nokia sw.txt extractions. Do not fold date/product/copyright
            // lines into firmware-version or the profile path.
            std::size_t cut = value.find_first_of("\r\n\t");
            const std::size_t escaped_n = value.find("\\n");
            const std::size_t escaped_r = value.find("\\r");
            if (escaped_n != std::string::npos && (cut == std::string::npos || escaped_n < cut)) cut = escaped_n;
            if (escaped_r != std::string::npos && (cut == std::string::npos || escaped_r < cut)) cut = escaped_r;
            if (cut != std::string::npos) value.resize(cut);
            std::size_t start = value.find_first_not_of(" ");
            if (start == std::string::npos) continue;
            value.erase(0, start);
            while (!value.empty() && value.back() == ' ') value.pop_back();
            if (!value.empty()) {
                LOG_INFO(SYSTEM, "NGAGE CLASSIC R2FX1 CLEANUP: canonical SW version={} source={}", value, path);
                return value;
            }
        }
        return {};
    }
'''
rep('devc',old,new)

# Always refresh version from private profile Z, including migrated R1/R2 entries that
# already persisted a malformed multiline value.
rep('devc',r'''        if (dvc->firmware_version.empty()) {
            dvc->firmware_version = r2b_read_firmware_version(z_product);
        }
''',r'''        const std::string canonical_version = r2b_read_firmware_version(z_product);
        if (!canonical_version.empty() && canonical_version != dvc->firmware_version) {
            LOG_INFO(SYSTEM, "NGAGE CLASSIC R2FX1 CLEANUP: corrected firmware version profile={} old={} new={}",
                dvc->profile_id, dvc->firmware_version, canonical_version);
            dvc->firmware_version = canonical_version;
        }
''')

# 2) Remove the legacy global-Z language probe from add_new_device. In R2, the
# profile id is only known after loading/finalization, at which point
# refresh_profile_runtime_metadata() reads languages.txt from private profile Z.
start=t['devc'].index('        std::vector<int> languages;\n        int default_language = -1;\n', t['devc'].index('add_device_error device_manager::add_new_device'))
end=t['devc'].index('        device dvc(ver, firmcode, manufacturer, model);', start)
old_block=t['devc'][start:end]
new_block=r'''        // NGAGE CLASSIC R2FX1 CLEANUP: do not probe the legacy global Z: here.
        // During registry load / staged install the profile identity is not available yet.
        // Start safely with English and replace it from the private profile Z: immediately
        // after profile metadata is restored/finalized.
        std::vector<int> languages { static_cast<int>(language::en) };
        int default_language = static_cast<int>(language::en);
'''
t['devc']=t['devc'][:start]+new_block+t['devc'][end:]
if 'Fail to load languages.txt file!' in t['devc']:
    raise SystemExit('R2FX1: legacy language error path still present in devices.cpp')

# 3) Device menu: make canonical SW metadata authoritative and remove misleading
# numeric variant suffix from model display (e.g. "(05.01)" / "(17.01)").
old=r'''        NSString *name = [NSString stringWithUTF8String:devices[i].name.c_str()];
        NSString *product = [NSString stringWithUTF8String:devices[i].firmware.c_str()];
        NSString *version = devices[i].firmware_version.empty() ? @"" : [NSString stringWithUTF8String:devices[i].firmware_version.c_str()];
        NSString *detail = version.length ? [NSString stringWithFormat:@"%@ %@", product, version] : product;
        NSString *baseTitle = detail.length ? [NSString stringWithFormat:@"%@ — %@", name, detail] : name;
        NSString *title = (i == current) ? [baseTitle stringByAppendingString:@"  ✓"] : baseTitle;'''
new=r'''        NSString *name = [NSString stringWithUTF8String:devices[i].name.c_str()];
        NSString *product = [NSString stringWithUTF8String:devices[i].firmware.c_str()];
        NSString *version = devices[i].firmware_version.empty() ? @"" : [NSString stringWithUTF8String:devices[i].firmware_version.c_str()];

        // NGAGE CLASSIC R2FX1 CLEANUP: old VPL/model metadata can carry a numeric
        // variant suffix such as (05.01)/(17.01). It is not the firmware SW version.
        // Hide only a terminal digits-and-dots parenthesis when canonical SW metadata exists.
        NSString *displayName = name;
        if (version.length && [name hasSuffix:@")"]) {
            NSRange open = [name rangeOfString:@"(" options:NSBackwardsSearch];
            if (open.location != NSNotFound && open.location > 0) {
                NSString *inside = [name substringWithRange:NSMakeRange(open.location + 1, name.length - open.location - 2)];
                NSCharacterSet *nonVersion = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789."] invertedSet];
                if (inside.length && [inside rangeOfCharacterFromSet:nonVersion].location == NSNotFound) {
                    displayName = [[name substringToIndex:open.location] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
                }
            }
        }
        NSString *detail = version.length ? [NSString stringWithFormat:@"%@ • SW %@", product, version] : product;
        NSString *baseTitle = detail.length ? [NSString stringWithFormat:@"%@ — %@", displayName, detail] : displayName;
        NSString *title = (i == current) ? [baseTitle stringByAppendingString:@"  ✓"] : baseTitle;'''
rep('rootvc',old,new)

# 4) Expected graphics queue abort is not corruption. This candidate patch is backed
# by repeated N-Gage/QD logs where the message occurs exactly during device/game teardown.
rep('ogl',r'''            if (!list) {
                LOG_ERROR(DRIVER_GRAPHICS, "Corrupted graphics command list! Emulation halt.");
                break;
            }
''',r'''            if (!list) {
                // NGAGE CLASSIC R2FX1 CLEANUP: request_queue::pop() returns nullopt
                // when abort() wakes the render thread. That is normal teardown.
                if (should_stop.load()) {
                    LOG_INFO(DRIVER_GRAPHICS, "NGAGE CLASSIC R2FX1 CLEANUP: graphics queue stopped cleanly");
                    break;
                }
                LOG_ERROR(DRIVER_GRAPHICS, "Corrupted graphics command list! Emulation halt.");
                break;
            }
''')
rep('ogl',r'''    void ogl_graphics_driver::abort() {
        list_queue.abort();
        should_stop = true;

        cond_.notify_all();
    }
''',r'''    void ogl_graphics_driver::abort() {
        // Publish stop before waking pop(), otherwise the render thread can misclassify
        // an intentional queue abort as a corrupt command list.
        should_stop.store(true);
        list_queue.abort();

        cond_.notify_all();
    }
''')

# 5) GL_INVALID_FRAMEBUFFER_OPERATION (1286): glClear on an incomplete bound FBO can
# never succeed. Skip that no-op/error and log the framebuffer status instead.
rep('ogl',r'''        glClear(gl_flags);
    }

    void ogl_graphics_driver::set_point_size''',r'''        if (gl_flags == 0) return;
        const GLenum fb_status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
        if (fb_status != GL_FRAMEBUFFER_COMPLETE) {
            LOG_WARN(DRIVER_GRAPHICS,
                "NGAGE CLASSIC R2FX1 CLEANUP: skipped clear on incomplete framebuffer status={}", fb_status);
            return;
        }
        glClear(gl_flags);
    }

    void ogl_graphics_driver::set_point_size''')
rep('fb',r'''        if (framebuffer_status != GL_FRAMEBUFFER_COMPLETE) {
            LOG_ERROR(DRIVER_GRAPHICS, "Framebuffer not complete! Reason {}", framebuffer_status);
        }

        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);''',r'''        if (framebuffer_status != GL_FRAMEBUFFER_COMPLETE) {
            LOG_WARN(DRIVER_GRAPHICS,
                "NGAGE CLASSIC R2FX1 CLEANUP: framebuffer incomplete status={}; initial clear skipped",
                framebuffer_status);
            unbind(nullptr);
            return;
        }

        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);''')

# 6) Stale bitmap handles are already safely ignored by the renderer. Avoid reporting
# teardown races as hard errors; preserve a warning with the exact handle for real runtime cases.
rep('ogl',r'''            if (!draw_texture) {
                LOG_ERROR(DRIVER_GRAPHICS, "Invalid bitmap handle to draw");
                return;
            }
''',r'''            if (!draw_texture) {
                if (should_stop.load()) return;
                LOG_WARN(DRIVER_GRAPHICS,
                    "NGAGE CLASSIC R2FX1 CLEANUP: invalid bitmap handle to draw handle={}", to_draw);
                return;
            }
''')

# 7) Keep unresolved guest ordinal misses visible but correctly classified as guest
# compatibility diagnostics rather than host-fatal errors. Do not fabricate an address.
rep('codeseg',r'''                        if (!addr) {
                            LOG_ERROR(KERNEL, "Invalid ordinal {}, requested from {}", ord, dependency.dep_->name());
                        }
''',r'''                        if (!addr) {
                            LOG_WARN(KERNEL,
                                "NGAGE CLASSIC R2FX1 CLEANUP: unresolved guest ordinal={} dependency={} requester={}",
                                ord, dependency.dep_->name(), name());
                        }
''')

# Write only after every anchor succeeded.
for k,p in paths.items():
    p.write_text(t[k],encoding='utf-8')

# Audits
joined='\n'.join(t.values())
for required in (
    'NGAGE CLASSIC R2FX1 CLEANUP:',
    'canonical SW version=',
    'graphics queue stopped cleanly',
    'skipped clear on incomplete framebuffer',
    'invalid bitmap handle to draw handle=',
    'unresolved guest ordinal=',
    'NGAGE CLASSIC R2B MULTIFIRMWARE R2:',
):
    if required not in joined:
        raise SystemExit('R2FX1 audit missing: '+required)
if 'Fail to load languages.txt file!' in t['devc']:
    raise SystemExit('R2FX1 audit: legacy language error remained')
print('NGAGE CLASSIC R2FX1 CLEANUP patch: PASS')
print('Canonical firmware SW version + truthful device label: PASS')
print('Profile-aware language lookup (legacy probe removed): PASS')
print('Graphics queue teardown race fix: PASS')
print('Incomplete-FBO clear guard for GL 1286: PASS')
print('Bitmap-handle teardown classification + handle diagnostics: PASS')
print('Guest ordinal misses retained as non-fatal compatibility diagnostics: PASS')
