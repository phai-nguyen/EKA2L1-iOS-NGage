from pathlib import Path

root = Path('upstream')
p = root/'src/emu/kernel/src/codeseg.cpp'
if not p.is_file():
    raise SystemExit(f'R2FX2 R2: missing {p}')
t = p.read_text(encoding='utf-8')

if 'NGAGE CLASSIC R2FX2 COMPATIBILITY R2 EXPORTMAP BATCH1:' in t:
    raise SystemExit('R2FX2 R2 already installed')
if 'NGAGE CLASSIC R2FX2 COMPATIBILITY R1:' not in t:
    raise SystemExit('R2FX2 R2 requires frozen R2FX2 COMPATIBILITY R1 baseline')

old = r'''                            if (known_legacy_version_skew) {
                                LOG_TRACE(KERNEL,
                                    "NGAGE CLASSIC R2FX2 COMPATIBILITY R1: known EKA1 version-skew import ordinal={} dependency={} requester={}; no unsafe shim installed",
                                    ord, dep_name, requester_name);
                            } else {
                                LOG_WARN(KERNEL,
                                    "NGAGE CLASSIC R2FX2 COMPATIBILITY R1: unresolved NEW guest ordinal={} dependency={} requester={}",
                                    ord, dep_name, requester_name);
                            }
'''
new = r'''                            if (known_legacy_version_skew) {
                                // NGAGE CLASSIC R2FX2 COMPATIBILITY R2 EXPORTMAP BATCH1:
                                // R1 proved a stable 53-import family with zero NEW tuples.  Batch 1 now
                                // isolates the two highest-value dependency families (EUSER/EFSRV) for
                                // symbol/ABI recovery.  This is intentionally NOT a guessed HLE shim:
                                // ordinal numbers alone are insufficient to prove the callee prototype or
                                // semantics.  A wrong forwarding target would corrupt guest state silently.
                                const bool batch1_export_target = known_euser || known_efsrv;
                                if (batch1_export_target) {
                                    LOG_INFO(KERNEL,
                                        "NGAGE CLASSIC R2FX2 COMPATIBILITY R2 EXPORTMAP BATCH1: export-map target ordinal={} dependency={} requester={}; exact symbol/ABI required before HLE",
                                        ord, dep_name, requester_name);
                                } else {
                                    LOG_TRACE(KERNEL,
                                        "NGAGE CLASSIC R2FX2 COMPATIBILITY R2 EXPORTMAP BATCH1: deferred known import ordinal={} dependency={} requester={}",
                                        ord, dep_name, requester_name);
                                }
                            } else {
                                LOG_WARN(KERNEL,
                                    "NGAGE CLASSIC R2FX2 COMPATIBILITY R2 EXPORTMAP BATCH1: unresolved NEW guest ordinal={} dependency={} requester={}",
                                    ord, dep_name, requester_name);
                            }
'''
count = t.count(old)
if count != 1:
    raise SystemExit(f'R2FX2 R2 anchor count={count}, expected=1')
t = t.replace(old, new, 1)
p.write_text(t, encoding='utf-8')

out = p.read_text(encoding='utf-8')
required = [
    'NGAGE CLASSIC R2FX2 COMPATIBILITY R2 EXPORTMAP BATCH1:',
    'export-map target ordinal=',
    'exact symbol/ABI required before HLE',
    'deferred known import ordinal=',
    'unresolved NEW guest ordinal=',
    'const bool batch1_export_target = known_euser || known_efsrv;',
    'ord == 305', 'ord == 2123', 'ord == 2128', 'ord == 2132',
]
for s in required:
    if s not in out:
        raise SystemExit('R2FX2 R2 audit missing: '+s)
if 'known EKA1 version-skew import ordinal=' in out:
    raise SystemExit('R2FX2 R2 audit: old R1 runtime marker remained')
print('NGAGE CLASSIC R2FX2 COMPATIBILITY R2 EXPORTMAP BATCH1 patch: PASS')
print('EUSER/EFSRV export-map target isolated: PASS')
print('HAL/FBSCLI/WS32 retained as deferred known imports: PASS')
print('Unknown tuples remain warning-visible: PASS')
print('No guessed HLE/export forwarding introduced: PASS')
