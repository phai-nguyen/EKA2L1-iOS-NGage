from pathlib import Path
import re

root = Path("upstream")
launcher = root / "src/emu/ios/src/launcher.cpp"
rootvc = root / "src/emu/ios/app/RootViewController.mm"
loc = root / "src/emu/ios/app/EKALocalization.mm"
cmake = root / "src/emu/ios/CMakeLists.txt"

lt = launcher.read_text(encoding="utf-8")
rt = rootvc.read_text(encoding="utf-8")
lc = loc.read_text(encoding="utf-8")
ct = cmake.read_text(encoding="utf-8")

MARK = "NGAGE CLASSIC R2A FIX1 CLASSICIMPORT:"

if MARK in lt:
    raise SystemExit("R2A patch already installed")

inc_anchor = "#include <lunasvg.h>\n\n#include <algorithm>"
if lt.count(inc_anchor) != 1:
    raise SystemExit("R2A: launcher include anchor invalid")
lt = lt.replace(
    inc_anchor,
    "#include <lunasvg.h>\n#include <miniz.h>\n\n#include <algorithm>\n#include <cstring>",
    1
)


# R2A FIX1: launcher.cpp now calls mz_zip_* directly. The EKA2L1 source tree
# already builds src/external/miniz as target "miniz", so link that target into
# the iOS bridge instead of relying on the header alone.
link_anchor = """    glad
    lunasvg
    sqlite3
    yaml-cpp)"""
if ct.count(link_anchor) != 1:
    raise SystemExit("R2A FIX1: iOS CMake link anchor invalid")
ct = ct.replace(
    link_anchor,
    """    glad
    lunasvg
    miniz
    sqlite3
    yaml-cpp)""",
    1
)

start = lt.find("    int launcher::install_ngage_file(const std::string &src_path, std::string &out_name) {")
end = lt.find("\n    std::uint32_t launcher::get_current_device()", start)
if start < 0 or end < 0:
    raise SystemExit("R2A: install_ngage_file function not found")

new_func = r'''    int launcher::install_ngage_file(const std::string &src_path, std::string &out_name) {
        device *current_device = sys->get_device_manager()->get_current();
        const bool ngage_classic = current_device &&
            common::compare_ignore_case(current_device->firmware_code.c_str(), "NEM-4") == 0;

        if (ngage_classic) {
            const std::string temp_root = eka2l1::add_path(conf->storage, "imports/ngage-classic-r2a/");
            common::delete_folder(temp_root);
            common::create_directories(temp_root);

            mz_zip_archive zip;
            std::memset(&zip, 0, sizeof(zip));
            if (!mz_zip_reader_init_file(&zip, src_path.c_str(), 0)) {
                common::delete_folder(temp_root);
                LOG_ERROR(FRONTEND_CMDLINE, "NGAGE CLASSIC R2A FIX1 CLASSICIMPORT: archive open failed '{}'", src_path);
                return 105;
            }

            bool extract_ok = true;
            const mz_uint count = mz_zip_reader_get_num_files(&zip);
            for (mz_uint i = 0; i < count; ++i) {
                mz_zip_archive_file_stat st;
                if (!mz_zip_reader_file_stat(&zip, i, &st) || !st.m_filename) {
                    extract_ok = false;
                    break;
                }

                std::string rel = st.m_filename;
                std::replace(rel.begin(), rel.end(), '\\', '/');

                if (rel.empty() || rel.front() == '/' || rel.find(':') != std::string::npos ||
                    rel == ".." || rel.rfind("../", 0) == 0 || rel.find("/../") != std::string::npos ||
                    (rel.size() >= 3 && rel.compare(rel.size() - 3, 3, "/..") == 0)) {
                    extract_ok = false;
                    LOG_ERROR(FRONTEND_CMDLINE,
                        "NGAGE CLASSIC R2A FIX1 CLASSICIMPORT: rejected unsafe archive path '{}'", rel);
                    break;
                }

                const std::string dest = eka2l1::add_path(temp_root, rel);
                if (mz_zip_reader_is_file_a_directory(&zip, i)) {
                    common::create_directories(dest);
                    continue;
                }

                common::create_directories(eka2l1::file_directory(dest));
                if (!mz_zip_reader_extract_to_file(&zip, i, dest.c_str(), 0)) {
                    extract_ok = false;
                    LOG_ERROR(FRONTEND_CMDLINE,
                        "NGAGE CLASSIC R2A FIX1 CLASSICIMPORT: extraction failed '{}'", rel);
                    break;
                }
            }
            mz_zip_reader_end(&zip);

            if (!extract_ok) {
                common::delete_folder(temp_root);
                return 105;
            }

            const int classic_result = install_ngage_game(temp_root, out_name);
            common::delete_folder(temp_root);

            LOG_INFO(FRONTEND_CMDLINE,
                "NGAGE CLASSIC R2A FIX1 CLASSICIMPORT: direct install result={} game='{}' package='{}'",
                classic_result, out_name, src_path);

            return 100 + classic_result;
        }

        io_system *io = sys->get_io_system();
        auto drive_entry = io->get_drive_entry(drive_e);
        if (!drive_entry) {
            return -1;
        }

        std::string current_dir;
        common::get_current_directory(current_dir);
        const std::string e_root = eka2l1::absolute_path(drive_entry->real_path, current_dir);
        const std::string ngage_dir = eka2l1::add_path(e_root, "n-gage");
        eka2l1::common::create_directories(ngage_dir);

        const std::string base = eka2l1::filename(src_path);
        if (base.empty()) {
            return -2;
        }

        const std::string dest_name = common::is_platform_case_sensitive() ? common::lowercase_string(base) : base;
        if (dest_name != base) {
            common::remove(eka2l1::add_path(ngage_dir, base));
        }

        const std::string dest = eka2l1::add_path(ngage_dir, dest_name);
        if (!eka2l1::common::copy_file(src_path, dest, true)) {
            return -2;
        }

        out_name = base;
        LOG_INFO(FRONTEND_CMDLINE, "Copied N-Gage package '{}' to '{}'", src_path, dest);
        return 0;
    }
'''
lt = lt[:start] + new_func + lt[end:]

old_block = r'''            if (result == 0) {
                // Reboot in progress; finish once the guest's apps reload.
                [self pollUntilAppsThen:^(BOOL found) {
                    [self endProgress];
                    [self showAppsScreen];
                    [self showAlert:EKAL(@"N-Gage file added")
                            message:[NSString stringWithFormat:EKAL(@"%@ was placed in drives/e/n-gage. Open the N-Gage app — it will detect and install the game."), fileName]];
                } attemptsLeft:30];
            } else {
                [self endProgress];
                [self showAppsScreen];
                [self showAlert:EKAL(@"Install failed")
                        message:EKAL(@"Couldn't copy the .n-gage file into the device’s storage.")];
            }'''
new_block = r'''            if (result == 100) {
                [self endProgress];
                [self showAppsScreen];
                [self showAlert:EKAL(@"N-Gage game installed")
                        message:[NSString stringWithFormat:EKAL(@"Installed %@ directly into the current N-Gage firmware. It now appears in the apps list."), fileName]];
            } else if ((result >= 101) && (result <= 105)) {
                [self endProgress];
                [self showAppsScreen];
                NSString *msg = (result == 105)
                    ? EKAL(@"The .n-gage archive could not be extracted safely.")
                    : [self ngageErrorMessage:(result - 100)];
                [self showAlert:EKAL(@"Install failed") message:msg];
            } else if (result == 0) {
                [self pollUntilAppsThen:^(BOOL found) {
                    [self endProgress];
                    [self showAppsScreen];
                    [self showAlert:EKAL(@"N-Gage file added")
                            message:[NSString stringWithFormat:EKAL(@"%@ was placed in drives/e/n-gage. Open the N-Gage app — it will detect and install the game."), fileName]];
                } attemptsLeft:30];
            } else {
                [self endProgress];
                [self showAppsScreen];
                [self showAlert:EKAL(@"Install failed")
                        message:EKAL(@"Couldn't copy the .n-gage file into the device’s storage.")];
            }'''

if rt.count(old_block) != 1:
    raise SystemExit("R2A: RootViewController result block anchor invalid")
rt = rt.replace(old_block, new_block, 1)

m = re.search(r'(?m)^(\s*@"N-Gage game installed"\s*:\s*@".*?",)$', lc)
if not m:
    raise SystemExit("R2A: localization anchor not found")
extra = '''
        @"Installed %@ directly into the current N-Gage firmware. It now appears in the apps list." : @"Đã cài %@ trực tiếp vào firmware N-Gage hiện tại. Trò chơi đã xuất hiện trong danh sách ứng dụng.",
        @"The .n-gage archive could not be extracted safely." : @"Không thể giải nén tệp .n-gage một cách an toàn.",'''
lc = lc[:m.end()] + extra + lc[m.end():]

for token in (
    "NGAGE CLASSIC R2A FIX1 CLASSICIMPORT:",
    'common::compare_ignore_case(current_device->firmware_code.c_str(), "NEM-4")',
    "mz_zip_reader_init_file",
    "return 100 + classic_result;",
):
    if token not in lt:
        raise SystemExit("R2A launcher audit missing: " + token)


if lt.count("std::uint32_t launcher::get_current_device()") != 1:
    raise SystemExit("R2A FIX1: launcher::get_current_device was not preserved")
if lt.count("bool launcher::does_rom_need_rpkg(const std::string &rom_path)") != 1:
    raise SystemExit("R2A FIX1: launcher::does_rom_need_rpkg was not preserved")
if not re.search(r'(?s)target_link_libraries\(eka2l1_ios_bridge PUBLIC.*?\n\s+miniz\n', ct):
    raise SystemExit("R2A FIX1: miniz is not linked into eka2l1_ios_bridge")

launcher.write_text(lt, encoding="utf-8")
rootvc.write_text(rt, encoding="utf-8")
loc.write_text(lc, encoding="utf-8")
cmake.write_text(ct, encoding="utf-8")
print("NGAGE CLASSIC R2A FIX1 CLASSICIMPORT patch: PASS")
print("launcher helper preservation: PASS")
print("miniz link dependency: PASS")
