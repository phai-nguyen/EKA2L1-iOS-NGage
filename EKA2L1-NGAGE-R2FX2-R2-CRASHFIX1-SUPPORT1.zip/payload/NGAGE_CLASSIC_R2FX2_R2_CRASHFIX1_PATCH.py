from pathlib import Path
import re

root = Path('upstream')
rv = root / 'src/emu/ios/app/RootViewController.mm'
codeseg = root / 'src/emu/kernel/src/codeseg.cpp'
devices = root / 'src/emu/system/src/devices.cpp'

for p in (rv, codeseg, devices):
    if not p.is_file():
        raise SystemExit(f'CRASHFIX1: missing {p}')

r = rv.read_text(encoding='utf-8')
c = codeseg.read_text(encoding='utf-8')
d = devices.read_text(encoding='utf-8')
MARK = 'NGAGE CLASSIC R2FX2 R2 CRASHFIX1:'
if MARK in r:
    raise SystemExit('CRASHFIX1 already installed')
if 'NGAGE CLASSIC R2FX2 COMPATIBILITY R2 EXPORTMAP BATCH1:' not in c:
    raise SystemExit('CRASHFIX1 requires R2FX2 R2 EXPORTMAP BATCH1 baseline')
if 'NGAGE CLASSIC R2FX1 CLEANUP:' not in d:
    raise SystemExit('CRASHFIX1 requires frozen R2FX1 CLEANUP baseline')
if 'NGAGE CLASSIC R2A BOOTREADY1:' not in r:
    raise SystemExit('CRASHFIX1 requires BOOTREADY1 iOS lifecycle baseline')

# Lexical brace matcher for Objective-C++ method bodies.
def find_method_span(text: str, sig: str):
    start = text.find(sig)
    if start < 0:
        raise SystemExit(f'CRASHFIX1 missing method: {sig}')
    brace = text.find('{', start)
    if brace < 0:
        raise SystemExit(f'CRASHFIX1 missing opening brace: {sig}')
    i = brace
    depth = 0
    state = 'code'
    while i < len(text):
        ch = text[i]
        nx = text[i+1] if i + 1 < len(text) else ''
        if state == 'code':
            if ch == '/' and nx == '/':
                state = 'line'; i += 2; continue
            if ch == '/' and nx == '*':
                state = 'block'; i += 2; continue
            if ch == '"':
                state = 'string'; i += 1; continue
            if ch == "'":
                state = 'char'; i += 1; continue
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    return start, i + 1, brace
            i += 1
        elif state == 'line':
            if ch == '\n': state = 'code'
            i += 1
        elif state == 'block':
            if ch == '*' and nx == '/': state = 'code'; i += 2
            else: i += 1
        elif state in ('string', 'char'):
            quote = '"' if state == 'string' else "'"
            if ch == '\\': i += 2
            elif ch == quote: state = 'code'; i += 1
            else: i += 1
    raise SystemExit(f'CRASHFIX1 unterminated method: {sig}')

# 1) One serial queue for destructive emulator lifecycle operations. exit_game() and
# set_current_device() were previously launched on independent global concurrent queues.
impl = '@implementation RootViewController'
pos = r.find(impl)
if pos < 0:
    raise SystemExit('CRASHFIX1 missing RootViewController implementation anchor')
queue_code = r'''// NGAGE CLASSIC R2FX2 R2 CRASHFIX1: serialize destructive emulator lifecycle work.
// Game exit and device switching both stop/restart core-owned graphics/audio/kernel state;
// they must not overlap on unrelated global worker threads.
static dispatch_queue_t EKANgageLifecycleQueue(void) {
    static dispatch_queue_t queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        queue = dispatch_queue_create("com.eka2l1.ngage.lifecycle", DISPATCH_QUEUE_SERIAL);
    });
    return queue;
}

'''
r = r[:pos] + queue_code + r[pos:]

# 2) Touch three-dot menu: eliminate the separate UIAlertController/action-sheet path.
# Reuse the already-existing GameMenuView/controller path, which centralizes activeMenu and
# inputManager.menuShown state and avoids presenting a second UIKit controller over live GL/video.
s, e, _ = find_method_span(r, '- (void)onMenuTouch')
old_touch = r[s:e]
if 'presentViewController' not in old_touch or 'UIAlertController' not in old_touch:
    raise SystemExit('CRASHFIX1 onMenuTouch no longer matches expected UIAlertController path')
new_touch = r'''- (void)onMenuTouch {
    if (![NSThread isMainThread]) {
        NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: menu-touch marshal-main");
        dispatch_async(dispatch_get_main_queue(), ^{
            [self onMenuTouch];
        });
        return;
    }
    NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: menu-touch enter gameRunning=%d", (int)[self gameRunning]);
    if (![self gameRunning]) return;

    // Use the same GameMenuView path as controller input. This avoids the independent
    // UIAlertController/action-sheet presentation path observed at the crash trigger.
    [self onMenuController];
}'''
r = r[:s] + new_touch + r[e:]

# Helpers after method replacement.
def inject_head(text: str, sig: str, code: str):
    s, e, brace = find_method_span(text, sig)
    return text[:brace+1] + '\n' + code + text[brace+1:]

def replace_lifecycle_queue(text: str, sig: str, label: str):
    s, e, _ = find_method_span(text, sig)
    body = text[s:e]
    pat = re.compile(r'dispatch_async\s*\(\s*dispatch_get_global_queue\s*\(\s*QOS_CLASS_USER_INITIATED\s*,\s*0\s*\)\s*,\s*\^\s*\{')
    matches = list(pat.finditer(body))
    if len(matches) != 1:
        raise SystemExit(f'CRASHFIX1 {sig}: global lifecycle dispatch count={len(matches)}, expected=1')
    repl = ('dispatch_async(EKANgageLifecycleQueue(), ^{\n'
            f'        NSLog(@"{MARK} {label} lifecycle-begin");')
    body2 = pat.sub(repl, body, count=1)
    return text[:s] + body2 + text[e:]

# 3) Controller menu may be triggered from an input callback. Marshal all menu construction/UI
# presentation to UIKit's main thread before touching GameMenuView.
r = inject_head(r, '- (void)onMenuController', r'''    if (![NSThread isMainThread]) {
        NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: menu-controller marshal-main");
        dispatch_async(dispatch_get_main_queue(), ^{
            [self onMenuController];
        });
        return;
    }
    NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: menu-controller enter gameRunning=%d", (int)[self gameRunning]);''')

# 4) exitGame UI state belongs on main; bridge::exit_game remains asynchronous to UI but is
# serialized against device switching. The existing bridge call and main completion are preserved.
r = inject_head(r, '- (void)exitGame', r'''    if (![NSThread isMainThread]) {
        NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: exit marshal-main");
        dispatch_async(dispatch_get_main_queue(), ^{
            [self exitGame];
        });
        return;
    }
    NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: exit request gameRunning=%d", (int)[self gameRunning]);''')
r = replace_lifecycle_queue(r, '- (void)exitGame', 'exit')

# Add before/after bridge diagnostics without changing bridge semantics.
s, e, _ = find_method_span(r, '- (void)exitGame')
body = r[s:e]
needle = 'eka2l1::ios::bridge::exit_game();'
if body.count(needle) != 1:
    raise SystemExit(f'CRASHFIX1 exit bridge call count={body.count(needle)}, expected=1')
body = body.replace(needle,
    'NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: exit bridge-call");\n'
    '        eka2l1::ios::bridge::exit_game();\n'
    '        NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: exit bridge-return");', 1)
r = r[:s] + body + r[e:]

# 5) Device switch: same main-thread entry rule and same serial lifecycle queue. This makes a
# switch wait until an in-flight game exit has returned from bridge::exit_game().
r = inject_head(r, '- (void)switchToDevice:', r'''    if (![NSThread isMainThread]) {
        NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: device-switch marshal-main index=%d", index);
        dispatch_async(dispatch_get_main_queue(), ^{
            [self switchToDevice:index];
        });
        return;
    }
    NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: device-switch request index=%d", index);''')
r = replace_lifecycle_queue(r, '- (void)switchToDevice:', 'device-switch')

s, e, _ = find_method_span(r, '- (void)switchToDevice:')
body = r[s:e]
needle = 'eka2l1::ios::bridge::set_current_device(index);'
if body.count(needle) != 1:
    raise SystemExit(f'CRASHFIX1 switch bridge call count={body.count(needle)}, expected=1')
body = body.replace(needle,
    'NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: device-switch bridge-call index=%d", index);\n'
    '        eka2l1::ios::bridge::set_current_device(index);\n'
    '        NSLog(@"NGAGE CLASSIC R2FX2 R2 CRASHFIX1: device-switch bridge-return index=%d", index);', 1)
r = r[:s] + body + r[e:]

# Final source audits. Keep gamecomms 61/63 as NEW compatibility evidence: this patch never
# touches codeseg.cpp and therefore cannot silently allowlist or shim those imports.
required = [
    MARK,
    'com.eka2l1.ngage.lifecycle',
    'dispatch_async(EKANgageLifecycleQueue(), ^{',
    'menu-touch enter gameRunning=',
    '[self onMenuController];',
    'menu-controller marshal-main',
    'exit lifecycle-begin',
    'exit bridge-call',
    'exit bridge-return',
    'device-switch lifecycle-begin',
    'device-switch bridge-call',
    'device-switch bridge-return',
]
for x in required:
    if x not in r:
        raise SystemExit('CRASHFIX1 audit missing: ' + x)
if r.count('dispatch_async(EKANgageLifecycleQueue(), ^{') != 2:
    raise SystemExit('CRASHFIX1 audit: expected exactly 2 serialized lifecycle dispatches')
ts, te, _ = find_method_span(r, '- (void)onMenuTouch')
if 'alertControllerWithTitle:' in r[ts:te] or '[self presentViewController:' in r[ts:te]:
    raise SystemExit('CRASHFIX1 audit: touch menu still uses direct UIKit presentation path')
if 'unresolved NEW guest ordinal=' not in c:
    raise SystemExit('CRASHFIX1 audit: R2 NEW-ordinal diagnostic was lost')
if 'gamecomms.dll' in c and ('ord == 61' in c or 'ord == 63' in c):
    raise SystemExit('CRASHFIX1 audit: gamecomms 61/63 must not be silently allowlisted')

rv.write_text(r, encoding='utf-8')
print('NGAGE CLASSIC R2FX2 R2 CRASHFIX1 patch: PASS')
print('Touch menu unified onto GameMenuView/controller path: PASS')
print('Controller/menu and lifecycle UI main-thread guards: PASS')
print('exit_game + set_current_device serialized on one queue: PASS')
print('R2 export-map behavior and NEW ordinal diagnostics preserved: PASS')
