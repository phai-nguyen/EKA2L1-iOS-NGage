from pathlib import Path
import hashlib
import subprocess

ROOT = Path('upstream')
IOS = ROOT / 'src/emu/ios'
APP = IOS / 'app'
ROOTVC = APP / 'RootViewController.mm'
LOC = APP / 'EKALocalization.mm'
CMAKE = IOS / 'CMakeLists.txt'
for p in (ROOTVC, LOC, CMAKE):
    if not p.exists():
        raise SystemExit(f'NGAGE CLASSIC R1: required file missing: {p}')

root = ROOTVC.read_text(encoding='utf-8')
loc = LOC.read_text(encoding='utf-8')
cmake = CMAKE.read_text(encoding='utf-8')

if 'NGAGE CLASSIC R1:' in root or 'activateBundledNGageMode' in root:
    raise SystemExit('NGAGE CLASSIC R1: patch already installed')
if 'V23 VI18N:' not in loc:
    raise SystemExit('NGAGE CLASSIC R1: V23 VI FIXED2 localization baseline missing')
if 'app/EKALocalization.mm' not in cmake:
    raise SystemExit('NGAGE CLASSIC R1: localized iOS CMake baseline missing')

# ---------------------------------------------------------------------------
# 1) Change the no-device entry point from "Install Device" to "Add Mode".
#    Keep "Devices" when at least one device is installed.
# ---------------------------------------------------------------------------
replacements = [
    ('NSArray<NSString *> *titles = @[EKAL(@"Install Device"), EKAL(@"Install Game"), EKAL(@"Settings"), EKAL(@"Apps")];',
     'NSArray<NSString *> *titles = @[EKAL(@"Add Mode"), EKAL(@"Install Game"), EKAL(@"Settings"), EKAL(@"Apps")];'),
    ('NSArray<NSString *> *titles = @[@"Install Device", @"Install Game", @"Settings", @"Apps"];',
     'NSArray<NSString *> *titles = @[EKAL(@"Add Mode"), EKAL(@"Install Game"), EKAL(@"Settings"), EKAL(@"Apps")];'),
]
changed_toolbar = False
for old, new in replacements:
    if old in root:
        root = root.replace(old, new, 1)
        changed_toolbar = True
        break
if not changed_toolbar:
    raise SystemExit('NGAGE CLASSIC R1: setupToolbar title anchor not found')

# V23 refreshLocalizedChrome has a second toolbar title list, formatted across lines.
old = '''    NSArray<NSString *> *titles = @[
        EKAL(@"Install Device"), EKAL(@"Install Game"),
        EKAL(@"Settings"), EKAL(@"Apps")
    ];'''
new = '''    NSArray<NSString *> *titles = @[
        EKAL(@"Add Mode"), EKAL(@"Install Game"),
        EKAL(@"Settings"), EKAL(@"Apps")
    ];'''
if old not in root:
    raise SystemExit('NGAGE CLASSIC R1: refreshLocalizedChrome title anchor not found')
root = root.replace(old, new, 1)

for old in (
    '[self.deviceButton setTitle:(hasDevice ? EKAL(@"Devices") : EKAL(@"Install Device")) forState:UIControlStateNormal];',
    '[self.deviceButton setTitle:(hasDevice ? @"Devices" : @"Install Device") forState:UIControlStateNormal];',
):
    if old in root:
        root = root.replace(old,
            '[self.deviceButton setTitle:(hasDevice ? EKAL(@"Devices") : EKAL(@"Add Mode")) forState:UIControlStateNormal];', 1)
        break
else:
    raise SystemExit('NGAGE CLASSIC R1: refreshDeviceButton anchor not found')

# ---------------------------------------------------------------------------
# 2) Add Add Mode -> N-Gage / Symbian Device menu and bundled NEM-4 install.
# ---------------------------------------------------------------------------
on_device_old = '''- (void)onDeviceButton {
    if (!eka2l1::ios::bridge::has_device()) {
        [self onInstallDevice];
        return;
    }
    [self showDevicesMenu];
}'''
on_device_new = '''- (void)onDeviceButton {
    if (!eka2l1::ios::bridge::has_device()) {
        [self showAddModeMenu];
        return;
    }
    [self showDevicesMenu];
}'''
if on_device_old not in root:
    raise SystemExit('NGAGE CLASSIC R1: onDeviceButton anchor not found')
root = root.replace(on_device_old, on_device_new, 1)

# Keep the empty-device guidance consistent with the new entry point.
for old, new in (
    ('No Symbian device installed.\n\nTap “Install Device” to add one.',
     'No Symbian device installed.\n\nTap “Add Mode” to add one.'),
    ('No Symbian device installed.\n\nTap “Install Device” to try again.',
     'No Symbian device installed.\n\nTap “Add Mode” to try again.'),
):
    root = root.replace(old, new)

methods_anchor = '// ---- Devices manager ------------------------------------------------------'
if root.count(methods_anchor) != 1:
    raise SystemExit(f'NGAGE CLASSIC R1: devices-manager anchor count={root.count(methods_anchor)}')

mode_methods = r'''// ---- N-Gage Classic bundled mode -----------------------------------------
// NGAGE CLASSIC R1: bundle the user-provided NEM-4 V4.03 ROM and expose it as
// a one-tap mode. This uses EKA2L1's normal ROM installer; it does not modify
// guest DRM/licence checks or patch game executables.
- (void)showAddModeMenu {
    UIAlertController *sheet = [UIAlertController
        alertControllerWithTitle:EKAL(@"Add Mode")
        message:nil
        preferredStyle:UIAlertControllerStyleActionSheet];

    [sheet addAction:[UIAlertAction actionWithTitle:EKAL(@"N-Gage")
        style:UIAlertActionStyleDefault
        handler:^(UIAlertAction *a) { [self activateBundledNGageMode]; }]];

    [sheet addAction:[UIAlertAction actionWithTitle:EKAL(@"Symbian Device…")
        style:UIAlertActionStyleDefault
        handler:^(UIAlertAction *a) { [self onInstallDevice]; }]];

    [sheet addAction:[UIAlertAction actionWithTitle:EKAL(@"Cancel")
        style:UIAlertActionStyleCancel handler:nil]];

    sheet.popoverPresentationController.sourceView = self.deviceButton;
    sheet.popoverPresentationController.sourceRect = self.deviceButton.bounds;
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)activateBundledNGageMode {
    // Reuse an already-installed NEM-4 instead of creating duplicates.
    std::vector<eka2l1::ios::bridge::device_entry> devices = eka2l1::ios::bridge::get_devices();
    int current = eka2l1::ios::bridge::get_current_device();
    for (int i = 0; i < (int)devices.size(); ++i) {
        const std::string &firmware = devices[i].firmware;
        const std::string &name = devices[i].name;
        const bool isNgage = (firmware == "NEM-4") ||
            (firmware.find("NEM-4") != std::string::npos) ||
            (name == "N-Gage");
        if (!isNgage) continue;

        eka2l1::ios::bridge::rename_device(i, "N-Gage");
        NSLog(@"NGAGE CLASSIC R1: reusing installed NEM-4 device index=%d firmware=%s",
              i, firmware.c_str());
        if (i != current) {
            [self switchToDevice:i];
        } else {
            [self refreshDeviceButton];
            [self showAppsScreen];
        }
        return;
    }

    [self installBundledNGageMode];
}

- (void)installBundledNGageMode {
    NSString *romPath = [[[NSBundle mainBundle] resourcePath]
        stringByAppendingPathComponent:@"assets/ngage/SYM.ROM"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:romPath]) {
        [self showAlert:EKAL(@"N-Gage firmware missing")
                message:EKAL(@"Bundled N-Gage firmware was not found.")];
        return;
    }

    NSDictionary *attrs = [[NSFileManager defaultManager] attributesOfItemAtPath:romPath error:nil];
    unsigned long long bytes = [attrs fileSize];
    if (bytes != 18612224ULL) {
        [self showAlert:EKAL(@"N-Gage firmware invalid")
                message:EKAL(@"Bundled N-Gage firmware has an unexpected size.")];
        return;
    }

    NSLog(@"NGAGE CLASSIC R1: installing bundled NEM-4 ROM path=%@ bytes=%llu",
          romPath, bytes);
    [self beginProgress:EKAL(@"Installing N-Gage…")];
    [self climbProgressToward:0.92f];

    std::string rom([romPath UTF8String]);
    __weak RootViewController *weakSelf = self;
    auto progress = [weakSelf](int pct) {
        dispatch_async(dispatch_get_main_queue(), ^{
            RootViewController *s = weakSelf;
            if (s) [s setProgressFraction:(float)pct / 100.0f];
        });
    };

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        // S60v1/N-Gage uses ROM-only installation. Passing an empty RPKG is safe
        // because the normal EKA2L1 installer only asks for RPKG when the ROM says
        // one is required; NEM-4 does not.
        int result = eka2l1::ios::bridge::install_device(std::string(), rom, true, progress);
        if (result == 0) {
            int installed = eka2l1::ios::bridge::get_current_device();
            if (installed >= 0) {
                eka2l1::ios::bridge::rename_device(installed, "N-Gage");
            }
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            RootViewController *s = weakSelf;
            if (!s) return;
            if (result != 0) {
                [s endProgress];
                [s showAlert:EKAL(@"N-Gage installation failed")
                        message:[NSString stringWithFormat:
                            EKAL(@"Could not install N-Gage firmware (error %d)."), result]];
                return;
            }

            NSLog(@"NGAGE CLASSIC R1: bundled NEM-4 installation complete");
            [s updateChrome];
            [s refreshDeviceButton];
            [s pollUntilAppsThen:^(BOOL found) {
                [s endProgress];
                [s showAppsScreen];
                [s showAlert:EKAL(@"N-Gage ready") message:EKAL(@"N-Gage mode is ready.")];
            } attemptsLeft:30];
        });
    });
}

'''
root = root.replace(methods_anchor, mode_methods + methods_anchor, 1)

# From Devices, adding another target should return to the same mode chooser.
old_candidates = [
    '''    [sheet addAction:[UIAlertAction actionWithTitle:EKAL(@"Install Another Device…") style:UIAlertActionStyleDefault
        handler:^(UIAlertAction *a) { [self onInstallDevice]; }]];''',
    '''    [sheet addAction:[UIAlertAction actionWithTitle:@"Install Another Device…" style:UIAlertActionStyleDefault
        handler:^(UIAlertAction *a) { [self onInstallDevice]; }]];''',
]
for old in old_candidates:
    if old in root:
        root = root.replace(old, '''    [sheet addAction:[UIAlertAction actionWithTitle:EKAL(@"Add Mode…") style:UIAlertActionStyleDefault
        handler:^(UIAlertAction *a) { [self showAddModeMenu]; }]];''', 1)
        break
else:
    raise SystemExit('NGAGE CLASSIC R1: Devices add-another anchor not found')

# ---------------------------------------------------------------------------
# 3) Add Vietnamese strings to the generated V23 localization table.
# ---------------------------------------------------------------------------
translations = {
    'Add Mode': 'Thêm chế độ',
    'Add Mode…': 'Thêm chế độ…',
    'No Symbian device installed.\n\nTap “Add Mode” to add one.': 'Chưa cài thiết bị Symbian.\n\nChạm “Thêm chế độ” để thêm.',
    'No Symbian device installed.\n\nTap “Add Mode” to try again.': 'Chưa cài thiết bị Symbian.\n\nChạm “Thêm chế độ” để thử lại.',
    'Symbian Device…': 'Thiết bị Symbian…',
    'Installing N-Gage…': 'Đang cài N-Gage…',
    'N-Gage firmware missing': 'Thiếu firmware N-Gage',
    'Bundled N-Gage firmware was not found.': 'Không tìm thấy firmware N-Gage được tích hợp trong ứng dụng.',
    'N-Gage firmware invalid': 'Firmware N-Gage không hợp lệ',
    'Bundled N-Gage firmware has an unexpected size.': 'Firmware N-Gage tích hợp có kích thước không đúng.',
    'N-Gage installation failed': 'Cài N-Gage thất bại',
    'Could not install N-Gage firmware (error %d).': 'Không thể cài firmware N-Gage (lỗi %d).',
    'N-Gage ready': 'N-Gage đã sẵn sàng',
    'N-Gage mode is ready.': 'Chế độ N-Gage đã sẵn sàng.',
}

def objc_escape(s: str) -> str:
    return s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')

loc_anchor = '''        table = @{\n'''
if loc.count(loc_anchor) < 1:
    raise SystemExit('NGAGE CLASSIC R1: localization dictionary anchor missing')
rows = ''.join(f'            @"{objc_escape(k)}" : @"{objc_escape(v)}",\n' for k, v in translations.items())
# Insert only into the first table (Vietnamese), not English overrides.
loc = loc.replace(loc_anchor, loc_anchor + rows, 1)

# ---------------------------------------------------------------------------
# 4) Ship the verified NEM-4 ROM inside the .app bundle.
# ---------------------------------------------------------------------------
cmake_anchor = '    COMMAND ${CMAKE_COMMAND} -E copy_directory "${CMAKE_BINARY_DIR}/bin/patch" "${EKA2L1_ASSETS_DIR}/patch"\n'
if cmake.count(cmake_anchor) != 1:
    raise SystemExit(f'NGAGE CLASSIC R1: CMake asset anchor count={cmake.count(cmake_anchor)}')
cmake_add = '''    # NGAGE CLASSIC R1: user-provided Nokia N-Gage NEM-4 V4.03 ROM.\n    COMMAND ${CMAKE_COMMAND} -E make_directory "${EKA2L1_ASSETS_DIR}/ngage"\n    COMMAND ${CMAKE_COMMAND} -E copy_if_different "${CMAKE_CURRENT_SOURCE_DIR}/ngage/SYM.ROM" "${EKA2L1_ASSETS_DIR}/ngage/SYM.ROM"\n'''
cmake = cmake.replace(cmake_anchor, cmake_anchor + cmake_add, 1)

ROOTVC.write_text(root, encoding='utf-8')
LOC.write_text(loc, encoding='utf-8')
CMAKE.write_text(cmake, encoding='utf-8')

# ---------------------------------------------------------------------------
# Strict source audits.
# ---------------------------------------------------------------------------
root2 = ROOTVC.read_text(encoding='utf-8')
loc2 = LOC.read_text(encoding='utf-8')
cmake2 = CMAKE.read_text(encoding='utf-8')
for token in (
    'NGAGE CLASSIC R1:',
    'showAddModeMenu',
    'activateBundledNGageMode',
    'installBundledNGageMode',
    'assets/ngage/SYM.ROM',
    'firmware == "NEM-4"',
    'rename_device(installed, "N-Gage")',
    'EKAL(@"Add Mode")',
    'EKAL(@"Symbian Device…")',
):
    if token not in root2:
        raise SystemExit('NGAGE CLASSIC R1: Root marker missing: ' + token)
for token in ('@"Add Mode" : @"Thêm chế độ"', '@"N-Gage ready" : @"N-Gage đã sẵn sàng"'):
    if token not in loc2:
        raise SystemExit('NGAGE CLASSIC R1: localization marker missing: ' + token)
for token in ('EKA2L1_ASSETS_DIR}/ngage', 'ngage/SYM.ROM'):
    if token not in cmake2:
        raise SystemExit('NGAGE CLASSIC R1: CMake marker missing: ' + token)

# Ensure the old no-device path is gone from refreshDeviceButton.
if 'hasDevice ? EKAL(@"Devices") : EKAL(@"Install Device")' in root2:
    raise SystemExit('NGAGE CLASSIC R1: old no-device toolbar label remains')

print('NGAGE CLASSIC R1 source bootstrap (NO bundled ROM): PASS')
print('ROM payload intentionally omitted; manual firmware install will be enabled after dependent patches.')
print('Upstream HEAD:', subprocess.check_output(['git','-C','upstream','rev-parse','HEAD'], text=True).strip())
