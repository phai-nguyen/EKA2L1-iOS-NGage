from pathlib import Path
import re

root = Path("upstream")
launcher = root / "src/emu/ios/src/launcher.cpp"
rootvc = root / "src/emu/ios/app/RootViewController.mm"
loc = root / "src/emu/ios/app/EKALocalization.mm"

for p in (launcher, rootvc, loc):
    if not p.is_file():
        raise SystemExit(f"FIX4: missing source file: {p}")

lt = launcher.read_text(encoding="utf-8")
rt = rootvc.read_text(encoding="utf-8")
lc = loc.read_text(encoding="utf-8")

if "NGAGE CLASSIC R2A FIX3 MULTIIMPORT:" not in lt:
    raise SystemExit("FIX4 requires FIX3 BUILD-FIX1 baseline")
if "NGAGE CLASSIC R2A FIX4 DISPATCHER:" in lt:
    raise SystemExit("FIX4 already installed")

# -------------------------------------------------------------------------
# Replace FIX3's post-extraction System-tree-only dispatch with a true
# archive dispatcher:
#   1) System/Apps tree -> canonicalize host path casing -> Classic installer
#   2) one compatible SIS -> native Symbian SIS installer
#   3) multiple compatible SIS -> return a candidate list to UIKit
#   4) only SISX/EKA2 -> incompatible with NEM-4
# -------------------------------------------------------------------------
start = lt.find("            // Accept both true card roots")
end_token = "            return 100 + classic_result;"
end = lt.find(end_token, start)
if start < 0 or end < 0:
    raise SystemExit("FIX4: FIX3 dispatcher block anchor missing")
end += len(end_token)

new_dispatch = r'''            // FIX4 DISPATCHER: first look for a Classic System/Apps tree.
            // Scene releases frequently use uppercase "SYSTEM" or mixed-case "Apps";
            // the host filesystem can be case-sensitive while the Symbian guest is not.
            auto contains_system_apps = [](const std::filesystem::path &candidate) -> bool {
                std::error_code ec;
                for (const auto &entry : std::filesystem::directory_iterator(candidate,
                        std::filesystem::directory_options::skip_permission_denied, ec)) {
                    if (ec) return false;
                    if (!entry.is_directory(ec)) continue;
                    const std::string name = entry.path().filename().string();
                    if (common::compare_ignore_case(name.c_str(), "system") != 0) continue;
                    for (const auto &sub : std::filesystem::directory_iterator(entry.path(),
                            std::filesystem::directory_options::skip_permission_denied, ec)) {
                        if (ec) return false;
                        if (!sub.is_directory(ec)) continue;
                        const std::string subname = sub.path().filename().string();
                        if (common::compare_ignore_case(subname.c_str(), "apps") == 0) return true;
                    }
                }
                return false;
            };

            std::filesystem::path game_root(temp_root);
            bool root_found = contains_system_apps(game_root);
            std::error_code scan_ec;
            if (!root_found) {
                for (const auto &level1 : std::filesystem::directory_iterator(game_root,
                        std::filesystem::directory_options::skip_permission_denied, scan_ec)) {
                    if (scan_ec) break;
                    if (!level1.is_directory(scan_ec)) continue;
                    if (contains_system_apps(level1.path())) {
                        game_root = level1.path();
                        root_found = true;
                        break;
                    }
                    for (const auto &level2 : std::filesystem::directory_iterator(level1.path(),
                            std::filesystem::directory_options::skip_permission_denied, scan_ec)) {
                        if (scan_ec) break;
                        if (!level2.is_directory(scan_ec)) continue;
                        if (contains_system_apps(level2.path())) {
                            game_root = level2.path();
                            root_found = true;
                            break;
                        }
                    }
                    if (root_found) break;
                }
            }

            if (root_found) {
                // Canonical staging solves archives such as FIFA 2005.rar whose card tree is
                // "SYSTEM/Apps/..." instead of lower-case "system/apps/...". Only known
                // Symbian directory components are normalized; filenames/assets are preserved.
                const std::string canonical_root_str =
                    eka2l1::add_path(conf->storage, "imports/ngage-classic-r2a-fix4-card/");
                common::delete_folder(canonical_root_str);
                std::filesystem::path canonical_root(canonical_root_str);
                std::error_code copy_ec;
                std::filesystem::create_directories(canonical_root, copy_ec);
                bool copy_ok = !copy_ec;

                auto canonical_component = [](const std::string &name) -> std::string {
                    if (common::compare_ignore_case(name.c_str(), "system") == 0) return "system";
                    if (common::compare_ignore_case(name.c_str(), "apps") == 0) return "apps";
                    if (common::compare_ignore_case(name.c_str(), "libs") == 0) return "libs";
                    if (common::compare_ignore_case(name.c_str(), "programs") == 0) return "programs";
                    return name;
                };

                if (copy_ok) {
                    for (const auto &entry : std::filesystem::recursive_directory_iterator(
                            game_root, std::filesystem::directory_options::skip_permission_denied, copy_ec)) {
                        if (copy_ec) {
                            copy_ok = false;
                            break;
                        }
                        if (entry.is_symlink(copy_ec)) {
                            copy_ok = false;
                            break;
                        }

                        const std::filesystem::path rel = entry.path().lexically_relative(game_root);
                        std::filesystem::path dest = canonical_root;
                        for (const auto &part : rel) {
                            dest /= canonical_component(part.string());
                        }

                        if (entry.is_directory(copy_ec)) {
                            std::filesystem::create_directories(dest, copy_ec);
                            if (copy_ec) {
                                copy_ok = false;
                                break;
                            }
                        } else if (entry.is_regular_file(copy_ec)) {
                            std::filesystem::create_directories(dest.parent_path(), copy_ec);
                            if (copy_ec) {
                                copy_ok = false;
                                break;
                            }
                            std::filesystem::copy_file(entry.path(), dest,
                                std::filesystem::copy_options::overwrite_existing, copy_ec);
                            if (copy_ec) {
                                copy_ok = false;
                                break;
                            }
                        }
                    }
                }

                if (!copy_ok) {
                    common::delete_folder(canonical_root_str);
                    common::delete_folder(temp_root);
                    LOG_ERROR(FRONTEND_CMDLINE,
                        "NGAGE CLASSIC R2A FIX4 DISPATCHER: canonical card staging failed package='{}'",
                        src_path);
                    return 109;
                }

                const int classic_result = install_ngage_game(canonical_root.string(), out_name);
                common::delete_folder(canonical_root_str);
                common::delete_folder(temp_root);

                LOG_INFO(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FIX4 DISPATCHER: card result={} game='{}' package='{}' type={}",
                    classic_result, out_name, src_path, rar_signature ? "RAR" : "ZIP");
                return 100 + classic_result;
            }

            // No card tree. Dispatch archive-contained SIS/SISX packages.
            std::vector<std::filesystem::path> compatible_sis;
            std::vector<std::filesystem::path> eka2_sis;

            auto sis_is_eka2 = [](const std::filesystem::path &p) -> bool {
                const std::string ext =
                    common::lowercase_string(p.extension().string());
                if (ext == ".sisx") return true;
                if (ext != ".sis") return false;

                std::ifstream in(p, std::ios::binary);
                std::array<unsigned char, 4> uid{};
                if (!in.read(reinterpret_cast<char *>(uid.data()), 4)) return false;
                const std::uint32_t uid1 =
                    static_cast<std::uint32_t>(uid[0]) |
                    (static_cast<std::uint32_t>(uid[1]) << 8) |
                    (static_cast<std::uint32_t>(uid[2]) << 16) |
                    (static_cast<std::uint32_t>(uid[3]) << 24);
                return uid1 == 0x10201A7A;
            };

            std::error_code sis_ec;
            for (const auto &entry : std::filesystem::recursive_directory_iterator(
                    temp_root, std::filesystem::directory_options::skip_permission_denied, sis_ec)) {
                if (sis_ec) break;
                if (!entry.is_regular_file(sis_ec)) continue;

                const std::string ext =
                    common::lowercase_string(entry.path().extension().string());
                if (ext != ".sis" && ext != ".sisx") continue;

                if (sis_is_eka2(entry.path())) {
                    eka2_sis.push_back(entry.path());
                } else {
                    compatible_sis.push_back(entry.path());
                }
            }

            if (compatible_sis.size() == 1) {
                std::string sis_path = compatible_sis.front().string();
                const int sis_result = static_cast<int>(install_app(sis_path));
                if (sis_result == 0) {
                    out_name = eka2l1::filename(sis_path);
                    common::delete_folder(temp_root);
                    LOG_INFO(FRONTEND_CMDLINE,
                        "NGAGE CLASSIC R2A FIX4 DISPATCHER: single SIS installed package='{}' sis='{}'",
                        src_path, sis_path);
                    return 100;
                }

                common::delete_folder(temp_root);
                LOG_ERROR(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FIX4 DISPATCHER: single SIS install failed result={} package='{}' sis='{}'",
                    sis_result, src_path, sis_path);
                return 111;
            }

            if (compatible_sis.size() > 1) {
                // Keep the extraction tree alive until UIKit lets the user choose one package.
                // Protocol:
                // MULTISIS\n<cleanup-root>\n<candidate-1>\n<candidate-2>...
                out_name = "MULTISIS\n" + temp_root;
                for (const auto &candidate : compatible_sis) {
                    out_name += "\n" + candidate.string();
                }
                LOG_INFO(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FIX4 DISPATCHER: multiple SIS candidates={} package='{}'",
                    compatible_sis.size(), src_path);
                return 110;
            }

            if (!eka2_sis.empty()) {
                common::delete_folder(temp_root);
                LOG_INFO(FRONTEND_CMDLINE,
                    "NGAGE CLASSIC R2A FIX4 DISPATCHER: archive contains only EKA2 SISX package='{}'",
                    src_path);
                return 106;
            }

            common::delete_folder(temp_root);
            LOG_INFO(FRONTEND_CMDLINE,
                "NGAGE CLASSIC R2A FIX4 DISPATCHER: no supported content package='{}'",
                src_path);
            return 114;'''
lt = lt[:start] + new_dispatch + lt[end:]

# -------------------------------------------------------------------------
# UIKit: result 110 presents compatible SIS candidates; 111/114 get precise
# messages. Existing result 106 continues to identify EKA2/N-Gage 2.0.
# -------------------------------------------------------------------------
branch_anchor = '''            } else if ((result >= 101) && (result <= 109)) {
                [self endProgress];
                [self showAppsScreen];
                NSString *msg = nil;'''
if rt.count(branch_anchor) != 1:
    raise SystemExit("FIX4: FIX3 result branch anchor invalid")

multi_branch = r'''            } else if (result == 110) {
                [self endProgress];
                [self showAppsScreen];

                NSString *payload = name.empty() ? @"" : [NSString stringWithUTF8String:name.c_str()];
                NSArray<NSString *> *parts = [payload componentsSeparatedByString:@"\n"];
                if (parts.count < 4 || ![parts[0] isEqualToString:@"MULTISIS"]) {
                    [self showAlert:EKAL(@"Install failed")
                            message:EKAL(@"The archive contains multiple SIS packages, but the candidate list is invalid.")];
                    return;
                }

                NSString *cleanupRoot = parts[1];
                UIAlertController *sheet = [UIAlertController
                    alertControllerWithTitle:EKAL(@"Choose SIS package")
                    message:EKAL(@"This archive contains multiple compatible SIS packages. Choose the one you want to install.")
                    preferredStyle:UIAlertControllerStyleActionSheet];

                for (NSUInteger i = 2; i < parts.count; ++i) {
                    NSString *candidate = parts[i];
                    if (candidate.length == 0) continue;
                    NSString *title = candidate.lastPathComponent;
                    [sheet addAction:[UIAlertAction actionWithTitle:title
                        style:UIAlertActionStyleDefault
                        handler:^(UIAlertAction *a) {
                            [self beginProgress:EKAL(@"Installing SIS package…")];
                            [self climbProgressToward:0.95f];
                            std::string packagePath = [candidate UTF8String];

                            dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
                                int sisResult = eka2l1::ios::bridge::install_app(packagePath);
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    [[NSFileManager defaultManager] removeItemAtPath:cleanupRoot error:nil];
                                    [self endProgress];
                                    [self showAppsScreen];
                                    if (sisResult == 0) {
                                        [self showAlert:EKAL(@"Game installed")
                                                message:[NSString stringWithFormat:EKAL(@"Installed %@. It now appears in the apps list."), title]];
                                    } else {
                                        [self showAlert:EKAL(@"Install failed")
                                                message:[NSString stringWithFormat:EKAL(@"Could not install the selected SIS package (error %d)."), sisResult]];
                                    }
                                });
                            });
                        }]];
                }

                [sheet addAction:[UIAlertAction actionWithTitle:EKAL(@"Cancel")
                    style:UIAlertActionStyleCancel
                    handler:^(UIAlertAction *a) {
                        [[NSFileManager defaultManager] removeItemAtPath:cleanupRoot error:nil];
                    }]];
                UIView *anchor = self.toolbar ?: self.view;
                sheet.popoverPresentationController.sourceView = anchor;
                sheet.popoverPresentationController.sourceRect = anchor.bounds;
                [self presentViewController:sheet animated:YES completion:nil];
            } else if ((result >= 101) && (result <= 114)) {
                [self endProgress];
                [self showAppsScreen];
                NSString *msg = nil;'''
rt = rt.replace(branch_anchor, multi_branch, 1)

message_anchor = '''                } else if (result == 108) {
                    msg = EKAL(@"Password-protected or encrypted RAR archives are not supported.");
                } else {
                    msg = EKAL(@"The N-Gage game archive could not be extracted.");
                }'''
if rt.count(message_anchor) != 1:
    raise SystemExit("FIX4: FIX3 message switch anchor invalid")
rt = rt.replace(
    message_anchor,
    '''                } else if (result == 108) {
                    msg = EKAL(@"Password-protected or encrypted RAR archives are not supported.");
                } else if (result == 111) {
                    msg = EKAL(@"A compatible SIS package was found in the archive, but the Symbian installer rejected it.");
                } else if (result == 114) {
                    msg = EKAL(@"The archive was extracted, but it contains neither a Classic System/Apps tree nor a compatible Symbian 6.1 SIS package.");
                } else {
                    msg = EKAL(@"The N-Gage game archive could not be extracted.");
                }''',
    1,
)

# -------------------------------------------------------------------------
# Localization additions.
# -------------------------------------------------------------------------
loc_anchor = '        @"The N-Gage game archive could not be extracted." : @"Không thể giải nén gói trò chơi N-Gage.",'
if lc.count(loc_anchor) != 1:
    raise SystemExit("FIX4: localization anchor invalid")
loc_extra = r'''
        @"Choose SIS package" : @"Chọn gói SIS",
        @"This archive contains multiple compatible SIS packages. Choose the one you want to install." : @"Tệp nén chứa nhiều gói SIS tương thích. Hãy chọn gói bạn muốn cài.",
        @"Installing SIS package…" : @"Đang cài gói SIS…",
        @"Installed %@. It now appears in the apps list." : @"Đã cài %@. Ứng dụng đã xuất hiện trong danh sách.",
        @"Could not install the selected SIS package (error %d)." : @"Không thể cài gói SIS đã chọn (lỗi %d).",
        @"The archive contains multiple SIS packages, but the candidate list is invalid." : @"Tệp nén chứa nhiều gói SIS nhưng danh sách lựa chọn không hợp lệ.",
        @"A compatible SIS package was found in the archive, but the Symbian installer rejected it." : @"Đã tìm thấy gói SIS tương thích trong tệp nén nhưng trình cài Symbian đã từ chối gói này.",
        @"The archive was extracted, but it contains neither a Classic System/Apps tree nor a compatible Symbian 6.1 SIS package." : @"Đã giải nén tệp nhưng không tìm thấy cây System/Apps của N-Gage Classic hoặc gói SIS Symbian 6.1 tương thích.",'''
lc = lc.replace(loc_anchor, loc_anchor + loc_extra, 1)

# Strict guards.
for token in (
    "NGAGE CLASSIC R2A FIX4 DISPATCHER:",
    "MULTISIS\\n",
    "canonical_component",
    "single SIS installed",
    "multiple SIS candidates",
):
    if token not in lt:
        raise SystemExit("FIX4 launcher audit missing: " + token)

for token in (
    "Choose SIS package",
    "result == 110",
    "Could not install the selected SIS package",
):
    if token not in rt:
        raise SystemExit("FIX4 UI audit missing: " + token)

if lt.count("std::uint32_t launcher::get_current_device()") != 1:
    raise SystemExit("FIX4: get_current_device preservation failed")
if lt.count("bool launcher::does_rom_need_rpkg") != 1:
    raise SystemExit("FIX4: does_rom_need_rpkg preservation failed")

launcher.write_text(lt, encoding="utf-8")
rootvc.write_text(rt, encoding="utf-8")
loc.write_text(lc, encoding="utf-8")

print("NGAGE CLASSIC R2A FIX4 DISPATCHER patch: PASS")
print("Classic card case-normalization: PASS")
print("Single SIS auto-dispatch: PASS")
print("Multiple SIS chooser protocol: PASS")
print("EKA2-only archive rejection: PASS")
