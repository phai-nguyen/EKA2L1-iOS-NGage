# R2FX2 R2 CRASHFIX1 — GitHub build packet

Place these files in the canonical repository:

1. `.github/workflows/build-ios-ngage-classic-r2fx2-R2-CRASHFIX1-NEM4-VI.yml`
2. repository root: `NGAGE_CLASSIC_R2FX2_R2_CRASHFIX1_PATCH.py`
3. repository root: `NGAGE-CLASSIC-R2A-FIX4-DISPATCHER-PAYLOAD.zip` (keep the existing copy if its SHA-256 matches)

The workflow includes `workflow_dispatch` and a `push` trigger for the workflow/patch/payload paths.

Expected artifact:
`EKA2L1-iOS-NGage-Classic-R2FX2-R2-CRASHFIX1-NEM4-unsigned.ipa`

Do not use the older EXPORTMAP BUILDFIX1 IPA for further decisive crash testing once CRASHFIX1 is available.
