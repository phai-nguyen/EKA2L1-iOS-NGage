# EKA2L1 iOS N-Gage Classic — R2FX2 R2 CRASHFIX1

Checkpoint: 2026-09-05

## Frozen baselines
- R2A FINAL1 — FROZEN/PASS
- R2B DEVICEPROFILES R1 — FROZEN/PASS
- R2B MULTIFIRMWARE R2 — FROZEN/PASS
- R2FX1 CLEANUP — FROZEN/PASS
- R2FX2 COMPATIBILITY R1 — FROZEN/PASS

## Parent candidate
R2FX2 R2 EXPORTMAP BATCH1 BUILDFIX1:
- static PASS;
- runtime FAIL for host stability;
- export classification itself remained non-HLE/non-forwarding.

Observed crash triggers:
1. Bomberman: touch `...` around game exit/menu path -> host app crash.
2. N-Gage -> RM-409 device switch -> host app crash in earlier run.
3. Asphalt 2: after N-Gage/Gameloft startup, touch `...` -> immediate host app crash.

Latest Asphalt crash evidence ended abruptly after opening `E:\\System\\Apps\\6rbc\\videos\\bg_136x64.mpg`; no clean graphics teardown marker followed.

Additional evidence in the crash run:
- NEW unresolved `gamecomms.dll` ordinals 61 and 63 requested by `main.dll`;
- `invalid bitmap handle to draw handle=0` appeared;
- no basis yet to claim either diagnostic is the native crash instruction.

## CRASHFIX1 design
Evidence from the built R2 binary shows:
- touch `onMenuTouch` uses a direct `UIAlertController` action-sheet path;
- controller `onMenuController` uses `GameMenuView` / `presentGameMenu`;
- `GameMenuView` contains an `onTap:` path, so it supports touch interaction;
- `exitGame` launches synchronous `bridge::exit_game()` on a global concurrent queue;
- `switchToDevice:` launches `bridge::set_current_device()` on a global concurrent queue.

CRASHFIX1 therefore:
1. routes touch `...` through the existing GameMenuView/controller menu path;
2. marshals menu/lifecycle entry points to the UIKit main thread;
3. serializes `exit_game()` and `set_current_device()` on `com.eka2l1.ngage.lifecycle`;
4. adds phase diagnostics around the two bridge calls;
5. leaves R2 export-map classification and NEW ordinal diagnostics untouched;
6. does not add gamecomms 61/63 to an allowlist and does not invent HLE semantics.

## Status
Source patch + GitHub workflow generated and offline-preflighted. Not yet GitHub-built/runtime-tested.
