# R2FX2 R2 CRASHFIX1 — Runtime Test Plan

## Scope
CRASHFIX1 is a host-stability fix on top of R2FX2 R2 EXPORTMAP BATCH1 BUILDFIX1. It does **not** add HLE/export shims and does **not** allowlist `gamecomms.dll` ordinals 61/63.

It targets the two observed host-app crash paths:
1. N-Gage game -> touch `...` while the guest is live (Bomberman/Asphalt 2).
2. N-Gage -> Nokia 5320/RM-409 device switch after game activity/exit.

Changes:
- touch `...` uses the existing `GameMenuView` path instead of a separate `UIAlertController` action sheet;
- menu construction is marshalled to the iOS main thread;
- `bridge::exit_game()` and `bridge::set_current_device()` run on one serial lifecycle queue rather than unrelated global concurrent queues;
- phase markers are logged before/after destructive bridge calls.

## Install
Install over the current R2FX2 R2 data. Do not delete profiles, game data, or saves.

## Gate A — direct crash trigger first
1. Start screen recording before launching the game.
2. Launch **Asphalt 2**.
3. Wait until the Gameloft/game startup screen is visible.
4. Tap `...` once.
5. PASS: EKA2L1 stays alive and the game menu appears.
6. Choose Exit Game once.
7. PASS: returns to the game list without leaving EKA2L1.

If the app crashes at any point: **stop testing immediately** and send that video plus both EKA2L1 logs from that run.

## Gate B — Bomberman
1. Launch Bomberman.
2. Enter gameplay or wait until the game is fully live.
3. Tap `...` once, then Exit Game.
4. PASS: no host-app crash.

If it crashes: stop immediately and send video + both logs.

## Gate C — serialized device switching
Only if A and B pass:
1. N-Gage -> Nokia 5320d-1 / RM-409.
2. Wait for the 5320 profile to finish switching/booting.
3. RM-409 -> N-Gage.
4. Repeat once.
5. PASS: no host-app crash and profiles/data remain isolated.

## Gate D — persistence/regression
1. Confirm N-Gage still contains Bomberman, FIFA 2005, Asphalt 2 and SanGo.
2. Force-close EKA2L1 normally.
3. Relaunch once and confirm the same profile/data state.

## Expected CRASHFIX1 markers
Look for:
- `NGAGE CLASSIC R2FX2 R2 CRASHFIX1: menu-touch enter`
- `... menu-controller enter`
- `... exit lifecycle-begin`
- `... exit bridge-call`
- `... exit bridge-return`
- `... device-switch lifecycle-begin`
- `... device-switch bridge-call`
- `... device-switch bridge-return`

`gamecomms.dll` ordinal 61/63 may still appear as `unresolved NEW guest ordinal=`. That is expected compatibility evidence for a later batch and is not silently patched here.

## Regression blockers
The following should remain absent during a clean run:
- `Corrupted graphics command list! Emulation halt.`
- `glClear encounters error 1286`
- profile/migration failure

`invalid bitmap handle to draw handle=0` should be counted if it appears; do not suppress it.
